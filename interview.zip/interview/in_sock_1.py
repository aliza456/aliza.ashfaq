# app.py
import os, sys, json, time, asyncio, base64, uuid, re
from typing import Dict, Any, Optional, List

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi import Request
from interview_final import *
import numpy as np
import soundfile as sf
import torch
from transformers import WhisperProcessor, WhisperForConditionalGeneration
import edge_tts
import requests
from interview_final import *

GROQ_API_KEY = "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"
# ======= IMPORTANT: NEVER hardcode keys in code =======
#GROQ_API_KEY = os.getenv("GROQ_API_KEY")  # set in environment
GROQ_MODEL   = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")

SAMPLE_RATE = 16000

processor = WhisperProcessor.from_pretrained("openai/whisper-small")
whisper_model = WhisperForConditionalGeneration.from_pretrained("openai/whisper-small")

interview_prompt_en = """You are a technical interviewer... (YOUR TEXT HERE trimmed)"""
interview_prompt_ur = """آپ ایک ... (YOUR URDU TEXT HERE trimmed)"""

# ----------------- FastAPI Setup -----------------
app = FastAPI(title="Interview Agent - WS")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:8000",
        "http://127.0.0.1:8000"],  # tighten in prod
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
templates = Jinja2Templates(directory="templates")
app.mount("/static", StaticFiles(directory="static"), name="static") 
@app.get("/")
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

# ----------------- Audio / AI utils -----------------
def pcm16_bytes_to_float32(arr: bytes) -> np.ndarray:
    # int16 -> float32 [-1, 1]
    a = np.frombuffer(arr, dtype=np.int16).astype(np.float32) / 32768.0
    return a

def transcribe_float(audio_f32: np.ndarray, language="en") -> str:
    inputs = processor(audio_f32, sampling_rate=SAMPLE_RATE,
                       return_tensors="pt", return_attention_mask=True)
    try:
        ids = whisper_model.generate(
            inputs.input_features, attention_mask=inputs.attention_mask,
            task="transcribe", language=language
        )
    except:
        fids = processor.get_decoder_prompt_ids(language=language, task="transcribe")
        ids = whisper_model.generate(
            inputs.input_features, attention_mask=inputs.attention_mask,
            forced_decoder_ids=fids
        )
    return processor.batch_decode(ids, skip_special_tokens=True)[0].strip()

def query_groq(messages: List[Dict[str, str]], max_tokens=512, temperature=0.2) -> str:
    url = "https://api.groq.com/openai/v1/chat/completions"
    headers = {"Authorization": f"Bearer {GROQ_API_KEY}", "Content-Type": "application/json"}
    payload = {
        "model": GROQ_MODEL,
        "messages": messages,
        "max_tokens": max_tokens,
        "temperature": temperature,
        "stream": False,
    }
    r = requests.post(url, headers=headers, json=payload, timeout=60)
    r.raise_for_status()
    return r.json()["choices"][0]["message"]["content"].strip()

async def tts_mp3_bytes(text: str, voice: str) -> bytes:
    # edge-tts streams to a file path; to keep it simple, write->read then remove.
    fn = f"tts_{uuid.uuid4().hex}.mp3"
    try:
        communicate = edge_tts.Communicate(text=text, voice=voice)
        await communicate.save(fn)
        with open(fn, "rb") as f:
            return f.read()
    finally:
        try:
            os.remove(fn)
        except:
            pass

# ----------------- WebSocket Session -----------------
class Session:
    def __init__(self, language: str):
        self.id = uuid.uuid4().hex
        self.lang = "en" if language.lower().startswith("en") else "ur"
        self.voice = "en-US-SteffanNeural" if self.lang == "en" else "ur-PK-UzmaNeural"
        self.system_prompt = interview_prompt_en if self.lang == "en" else interview_prompt_ur
        self.messages = [{"role": "system", "content": self.system_prompt}]
        self.buffer = []  # list[np.ndarray float32], each ~20-40ms
        self.utterance_active = False

    def reset_utterance(self):
        self.buffer.clear()
        self.utterance_active = False

    def push_pcm(self, f32: np.ndarray):
        self.buffer.append(f32)

    def current_audio(self) -> Optional[np.ndarray]:
        if not self.buffer:
            return None
        return np.concatenate(self.buffer)

# ----------------- WS Protocol -----------------
# Client sends JSON messages and binary frames:
# 1) {"type":"start","language":"en"|"ur"}
# 2) {"type":"utterance_start"}
# 3) (binary) PCM16@16k mono frames repeatedly
# 4) {"type":"utterance_end"} -> server STT -> LLM -> TTS -> send back
#
# Server sends:
# - {"type":"status","message":"..."}
# - {"type":"stt","text":"..."}
# - {"type":"ai_text","text":"..."}
# - binary audio with header {"type":"audio","mime":"audio/mpeg","size":...} followed by raw bytes

@app.websocket("/ws")
async def ws_handler(ws: WebSocket):
    await ws.accept()
    sess: Optional[Session] = None

    try:
        while True:
            msg = await ws.receive()  # can be {"text":..} or {"bytes":..}

            # --------- Text messages (JSON) ----------
            if "text" in msg and msg["text"] is not None:
                try:
                    data = json.loads(msg["text"])
                except json.JSONDecodeError:
                    await ws.send_text(json.dumps({"type": "status", "level":"err", "message":"Invalid JSON"}))
                    continue

                typ = data.get("type")
                if typ == "start":
                    lang = (data.get("language") or "en").lower()
                    sess = Session(lang)
                    await ws.send_text(json.dumps({"type":"status","level":"ok","message":f"session started ({sess.lang})"}))

                    # Optional: greet
                    if sess.lang == 'en':
                       voice = "en-US-SteffanNeural"
                       greeting_file = "greeting_english.mp3"
                    if sess.lang == "ur":
                       voice = "ur-PK-UzmaNeural"
                       greeting_file = "greetings.mp3"

                    #greet = "Hello! Let's begin your interview." if sess.lang=="en" else "السلام علیکم! ہم انٹرویو شروع کرتے ہیں۔"
                    sess.messages.append({"role":"assistant","content":greet})
                    await ws.send_text(json.dumps({"type":"ai_text","text":greet}))
                    # Also TTS greet
                    audio_bytes = await tts_mp3_bytes(greet, sess.voice)
                    await ws.send_text(json.dumps({"type":"audio","mime":"audio/mpeg","size":len(audio_bytes)}))
                    await ws.send_bytes(audio_bytes)

                elif typ == "utterance_start":
                    if not sess:
                        await ws.send_text(json.dumps({"type":"status","level":"err","message":"no session"}))
                        continue
                    sess.reset_utterance()
                    sess.utterance_active = True
                    await ws.send_text(json.dumps({"type":"status","level":"info","message":"listening"}))

                elif typ == "utterance_end":
                    if not sess:
                        await ws.send_text(json.dumps({"type":"status","level":"err","message":"no session"}))
                        continue
                    sess.utterance_active = False
                    audio = sess.current_audio()
                    sess.reset_utterance()

                    if audio is None or audio.size == 0:
                        await ws.send_text(json.dumps({"type":"status","level":"warn","message":"no audio received"}))
                        continue

                    # 1) STT
                    lang_code = "en" if sess.lang=="en" else "ur"
                    text = transcribe_float(audio, language=lang_code)
                    await ws.send_text(json.dumps({"type":"stt","text":text}))

                    if not text or len(text.strip()) < 2:
                        await ws.send_text(json.dumps({"type":"status","level":"warn","message":"empty transcript"}))
                        continue

                    # 2) LLM
                    sess.messages.append({"role":"user","content":text})
                    ai = query_groq(sess.messages)
                    sess.messages.append({"role":"assistant","content":ai})
                    await ws.send_text(json.dumps({"type":"ai_text","text":ai}))

                    # 3) TTS -> send mp3 bytes
                    audio_bytes = await tts_mp3_bytes(ai, sess.voice)
                    await ws.send_text(json.dumps({"type":"audio","mime":"audio/mpeg","size":len(audio_bytes)}))
                    await ws.send_bytes(audio_bytes)

                elif typ == "stop":
                    await ws.send_text(json.dumps({"type":"status","level":"ok","message":"session closed"}))
                    break

                else:
                    
                    await ws.send_text(json.dumps({"type":"status","level":"err","message":f"unknown type {typ}"}))

            # --------- Binary messages (PCM16 frames) ----------
            elif "bytes" in msg and msg["bytes"] is not None:
                if not sess or not sess.utterance_active:
                    # discard if not in an utterance
                    continue
                f32 = pcm16_bytes_to_float32(msg["bytes"])
                # (optional) light DC offset clamp
                if f32.size:
                    f32 = np.clip(f32, -1.0, 1.0)
                sess.push_pcm(f32)

    except WebSocketDisconnect:
        pass
    except Exception as e:
        try:
            await ws.send_text(json.dumps({"type":"status","level":"err","message":f"server error: {e}"}))
        except:
            pass
    finally:
        try:
            await ws.close()
        except:
            pass
