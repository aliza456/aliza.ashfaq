from __future__ import print_function
import random
from datetime import datetime
from pathlib import Path
import smtplib
from email.message import EmailMessage
import os, base64, mimetypes
from email.message import EmailMessage
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from google.auth.transport.requests import Request
import json
import uuid
import email
import sqlite3
import hashlib

db_path = '/home/aliza-ashfaq/Desktop/interview/Database.db'
def init_database():
    """Initialize the database with required tables"""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Create candidates table if it doesn't exist
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS candidates (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            candidate_id TEXT UNIQUE NOT NULL,
            email_address TEXT NOT NULL,
            sender TEXT,
            subject TEXT,
            resume_filename TEXT, 
            resume_filepath TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    conn.commit()
    conn.close()
    print("✅ Database initialized")

def generate_candidate_id(email_address):
    """Generate a unique candidate ID based on email"""
    # Create a short hash from email
    email_hash = hashlib.md5(email_address.lower().encode()).hexdigest()[:8]
    return f"cand_{email_hash}"

def extract_email_from_sender(sender):
    """Extract email address from sender field (e.g., 'John Doe <john@example.com>')"""
    import re
    email_match = re.search(r'<(.+?)>', sender)
    if email_match:
        return email_match.group(1)
    elif '@' in sender:
        return sender.strip()
    else:
        return sender

def save_candidate_to_db(email_data):
    """Save candidate information to database"""
    try:
        conn = sqlite3.connect('Database.db')
        cursor = conn.cursor()
        
        # Extract email from sender
        sender_email = extract_email_from_sender(email_data['sender'])
        candidate_id = generate_candidate_id(sender_email)
        
        # Check if candidate already exists
        cursor.execute('SELECT candidate_id FROM candidates WHERE email_address = ?', (sender_email,))
        existing = cursor.fetchone()
        
        if existing:
            print(f"⚠️ Candidate with email {sender_email} already exists (ID: {existing[0]})")
            conn.close()
            return existing[0]
        
        # Find resume attachment and convert to absolute path
        resume_info = None
        for attachment in email_data.get('attachments', []):
            filename = attachment['filename'].lower()
            if any(ext in filename for ext in ['.pdf', '.doc', '.docx']):
                # Convert relative path to absolute path
                relative_path = attachment['filepath']
                absolute_path = os.path.abspath(relative_path)
                
                resume_info = {
                    'filename': attachment['filename'],
                    'filepath': absolute_path,  # Store absolute path
                    'size': attachment.get('size', 0)
                }
                break
        
        # Insert new candidate
        cursor.execute('''
            INSERT INTO candidates 
            (candidate_id, email_address, sender, subject,
             resume_filename, resume_filepath, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (
            candidate_id,
            sender_email,
            email_data['sender'],
            email_data['subject'],
            resume_info['filename'] if resume_info else None,
            resume_info['filepath'] if resume_info else None,  # Absolute path stored here
            email_data.get('created_at', datetime.now().isoformat())
        ))
        
        conn.commit()
        conn.close()
        
        print(f"✅ Saved candidate: {candidate_id} ({sender_email})")
        if resume_info:
            print(f"📄 Resume: {resume_info['filename']}")
            print(f"📁 Path: {resume_info['filepath']}")  # Show absolute path
        
        return candidate_id
        
    except Exception as e:
        print(f"❌ Error saving to database: {e}")
        return None

def get_all_candidates():
    """Retrieve all candidates from database"""
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT candidate_id, email_address, sender, subject,
                   resume_filename, resume_filepath, created_at
            FROM candidates
            ORDER BY created_at DESC
        ''')
        
        candidates = cursor.fetchall()
        conn.close()
        
        return candidates
        
    except Exception as e:
        print(f"❌ Error retrieving candidates: {e}")
        return []

def search_candidate_by_email(email):
    """Search for candidate by email address"""
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT * FROM candidates WHERE email_address = ?
        ''', (email,))
        
        candidate = cursor.fetchone()
        conn.close()
        
        return candidate
        
    except Exception as e:
        print(f"❌ Error searching candidate: {e}")
        return None

def authenticate_gmail():
    """Authenticate and return Gmail service object"""
    SCOPES = ["https://www.googleapis.com/auth/forms.responses.readonly","https://www.googleapis.com/auth/gmail.readonly","https://www.googleapis.com/auth/gmail.send"]

    creds = None
    
    # The file token.json stores the user's access and refresh tokens.
    if os.path.exists('token.json'):
        creds = Credentials.from_authorized_user_file('token.json', SCOPES)
    
    # If there are no (valid) credentials available, let the user log in.
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file("client_secret_993249251770-39ot8taj89kdptcqqgdii5pjerprid2u.apps.googleusercontent.com.json", SCOPES)
            creds = flow.run_local_server(port=0)
        
        # Save the credentials for the next run
        with open('token.json', 'w') as token:
            token.write(creds.to_json())
    
    service = build('gmail', 'v1', credentials=creds)
    return service

#total number of messages in one page
def get_messages_list(service, user_id):
  try:
    return service.users().messages().list(userId=user_id).execute()
  except Exception as error:
    print('An error occurred: %s' % error)


def get_message(service, user_id, msg_id):
  try:
    return service.users().messages().get(userId=user_id, id=msg_id, format='raw').execute()
  except Exception as error:
    print('An error occurred: %s' % error)

def get_attachments(service, user_id, msg_id, store_dir="./attachments/"):
    """Download all attachments from a message"""
    try:
        os.makedirs(store_dir, exist_ok=True)
        message = service.users().messages().get(userId=user_id, id=msg_id).execute()
        attachments = []
        
        def process_parts(parts):
            for part in parts:
                if part.get('filename'):
                    if 'data' in part['body']:
                        # Attachment data is directly in the body
                        attachment_data = base64.urlsafe_b64decode(part['body']['data'])
                    elif 'attachmentId' in part['body']:
                        # Attachment data needs to be fetched separately
                        attachment = service.users().messages().attachments().get(
                            id=part['body']['attachmentId'], 
                            userId=user_id, 
                            messageId=msg_id
                        ).execute()
                        attachment_data = base64.urlsafe_b64decode(attachment['data'])
                    else:
                        continue
                    
                    # Save the attachment
                    filename = part['filename']
                    filepath = os.path.join(store_dir, filename)
                    
                    with open(filepath, 'wb') as f:
                        f.write(attachment_data)
                    
                    attachments.append({
                        'filename': filename,
                        'filepath': filepath,
                        'size': len(attachment_data)
                    })
                    print(f"✅ Downloaded: {filename} ({len(attachment_data)} bytes)")
                
                # Check for nested parts
                if 'parts' in part:
                    process_parts(part['parts'])
        
        # Process message parts
        if 'parts' in message['payload']:
            process_parts(message['payload']['parts'])
        
        return attachments
        
    except Exception as error:
        print(f'Error downloading attachments: {error}')
        return []

def get_mime_message(service, user_id, msg_id, download_attachments=True):
    try:
        message = service.users().messages().get(userId=user_id, id=msg_id, format='full').execute()
        
        # Get headers (subject, sender, etc.)
        headers = message['payload']['headers']
        subject = next((h['value'] for h in headers if h['name'] == 'Subject'), "No Subject")
        sender = next((h['value'] for h in headers if h['name'] == 'From'), "Unknown Sender")
        date = next((h['value'] for h in headers if h['name'] == 'Date'), "Unknown Date")
        
        print(f"Subject: {subject}")
        print(f"Sender: {sender}")
        print(f"Date: {date}")
        
        # Get email body
        body = get_email_body(message['payload'])
        print(f"Body Preview: {body[:200]}..." if len(body) > 200 else f"Body: {body}")
        
        # Download attachments if requested
        attachments = []
        if download_attachments:
            attachments = get_attachments(service, user_id, msg_id)
            if attachments:
                print(f"📎 Downloaded {len(attachments)} attachment(s)")
        
        return {
            'subject': subject,
            'sender': sender,
            'date': date,
            'body': body,
            'attachments': attachments
        }
        
    except Exception as error:
        print(f'An error occurred: {error}')
        return None

def search_emails_by_subject(service, user_id, subject_filter):
    """Search for emails containing specific subject text"""
    try:
        # Gmail search query
        query = f'subject:"{subject_filter}"'
        result = service.users().messages().list(userId=user_id, q=query).execute()
        
        messages = result.get('messages', [])
        print(f"Found {len(messages)} emails with subject containing: '{subject_filter}'")
        
        return messages
        
    except Exception as error:
        print(f'Error searching emails: {error}')
        return []

def get_email_body(payload):
    """Extract email body from message payload"""
    body = ""
    
    def extract_text_from_parts(parts):
        text = ""
        for part in parts:
            if part['mimeType'] == 'text/plain':
                if 'data' in part['body']:
                    text = base64.urlsafe_b64decode(part['body']['data']).decode('utf-8')
                    break
            elif part['mimeType'] == 'text/html':
                if 'data' in part['body']:
                    text = base64.urlsafe_b64decode(part['body']['data']).decode('utf-8')
            elif 'parts' in part:
                # Recursively check nested parts
                nested_text = extract_text_from_parts(part['parts'])
                if nested_text:
                    text = nested_text
        return text
    
    if 'parts' in payload:
        body = extract_text_from_parts(payload['parts'])
    else:
        # Single part message
        if payload['mimeType'] == 'text/plain' or payload['mimeType'] == 'text/html':
            if 'data' in payload['body']:
                body = base64.urlsafe_b64decode(payload['body']['data']).decode('utf-8')
    
    return body

if __name__ == '__main__':
    try:
        # Initialize database
        init_database()
        
        # Authenticate and get Gmail service
        service = authenticate_gmail()
        print("✅ Gmail authentication successful!")
        
        user_id = 'me'  # 'me' refers to the authenticated user
        
        # Get subject filter from user
        subject_filter = input("Enter subject to search for (or press Enter for all emails): ").strip()
        
        if subject_filter:
            # Search for specific emails
            messages = search_emails_by_subject(service, user_id, subject_filter)
        else:
            # Get all messages
            result = get_messages_list(service, user_id)
            messages = result.get('messages', []) if result else []

        if messages:
            print(f"\nProcessing {len(messages)} message(s)...")
            
            # Process each message
            all_email_data = []
            candidate_ids = []
            
            for i, msg in enumerate(messages):
                msg_id = msg['id']
                print(f"\n{'='*60}")
                print(f"Email {i+1}/{len(messages)} (ID: {msg_id})")
                print('='*60)
                
                # Get message details and download attachments
                email_data = get_mime_message(service, user_id, msg_id, download_attachments=True)
                
                if email_data:
                    all_email_data.append(email_data)
                    
                    # Save to database and get candidate ID
                    candidate_id = save_candidate_to_db(email_data)
                    if candidate_id:
                        candidate_ids.append(candidate_id)
            
            # Save summary to JSON file
            summary = {
                'search_query': subject_filter if subject_filter else 'All emails',
                'total_emails': len(all_email_data),
                'candidate_ids': candidate_ids,
                'emails': all_email_data,
                'extracted_at': datetime.now().isoformat()
            }
            
            with open('email_extraction_summary.json', 'w', encoding='utf-8') as f:
                json.dump(summary, f, indent=2, ensure_ascii=False)
            
            print(f"\nSummary:")
            print(f"- Processed: {len(all_email_data)} emails")
            print(f"- Candidates saved: {len(candidate_ids)}")
            print(f"- Total attachments: {sum(len(email['attachments']) for email in all_email_data)}")
            print(f"- Summary saved to: email_extraction_summary.json")
            
            # Show all candidates in database
            print(f"\n📋 All Candidates in Database:")
            candidates = get_all_candidates()
            for candidate in candidates:
                print(f"  {candidate[0]} | {candidate[1]} | {candidate[2]} | {candidate[4] or 'No resume'}")
            
        else:
            print("No messages found")
            
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()