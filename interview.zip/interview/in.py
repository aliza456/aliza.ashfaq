# app.py
import os, sys, json, time, asyncio, base64, uuid, re, io
from typing import Dict, Any, Optional, List
from collections import deque

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi import Request

import numpy as np
import torch
from transformers import WhisperProcessor, WhisperForConditionalGeneration
import edge_tts
from pydub import AudioSegment

# ---- bring your helpers / constants from interview_final.py
from interview_final import (
    interview_prompt_en, interview_prompt_ur,
    parse_pdf, build_faiss_index_with_metadata, save_index_and_metadata, query_faiss,
    save_conversation_to_json, start_new_interview,
    detect_speech_in_frame, detect_speech_with_ai_rejection,
    FRAME_DURATION, FRAME_SIZE, SILENCE_DURATION, MIN_SPEECH_DURATION,
    query_groq, pdf_path, index_path, json_path
)

# ======= IMPORTANT: NEVER hardcode keys in code =======
GROQ_API_KEY = "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"
GROQ_MODEL   = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")

SAMPLE_RATE = 16000

processor = WhisperProcessor.from_pretrained("openai/whisper-small")
whisper_model = WhisperForConditionalGeneration.from_pretrained("openai/whisper-small")

# ----------------- FastAPI Setup -----------------
app = FastAPI(title="Interview Agent - WS")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:8000","http://127.0.0.1:8000"],  # tighten in prod
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
templates = Jinja2Templates(directory="templates")
app.mount("/static", StaticFiles(directory="static"), name="static")

@app.get("/")
def home(request: Request):
    return templates.TemplateResponse("index3.html", {"request": request})

# ----------------- Audio / AI utils -----------------
def pcm16_bytes_to_float32(arr: bytes) -> np.ndarray:
    # int16 -> float32 [-1, 1]
    return np.frombuffer(arr, dtype=np.int16).astype(np.float32) / 32768.0

def transcribe_float(audio_f32: np.ndarray, language="en") -> str:
    inputs = processor(audio_f32, sampling_rate=SAMPLE_RATE,
                       return_tensors="pt", return_attention_mask=True)
    try:
        ids = whisper_model.generate(
            inputs.input_features, attention_mask=inputs.attention_mask,
            task="transcribe", language=language
        )
    except Exception:
        fids = processor.get_decoder_prompt_ids(language=language, task="transcribe")
        ids = whisper_model.generate(
            inputs.input_features, attention_mask=inputs.attention_mask,
            forced_decoder_ids=fids
        )
    return processor.batch_decode(ids, skip_special_tokens=True)[0].strip()

async def tts_mp3_bytes(text: str, voice: str) -> bytes:
    # edge-tts writes to a file; we read bytes and delete
    fn = f"tts_{uuid.uuid4().hex}.mp3"
    try:
        communicate = edge_tts.Communicate(text=text, voice=voice)
        await communicate.save(fn)
        with open(fn, "rb") as f:
            return f.read()
    finally:
        try: os.remove(fn)
        except: pass

   
def calculate_ai_playback_threshold_from_bytes(mp3_bytes: bytes, multiplier=1.5, silence_rms_cutoff=1e-3):
    """Compute a robust RMS threshold from the MP3 to reject AI echo when detecting user barge-in."""
    audio = AudioSegment.from_file(io.BytesIO(mp3_bytes), format="mp3")
    samples = np.array(audio.get_array_of_samples(), dtype=np.int16).astype(np.float32) / 32768.0
    if audio.channels > 1:
        samples = samples.reshape(-1, audio.channels).mean(axis=1)
    frame_size = int(audio.frame_rate * 0.032)  # 32 ms
    loud = []
    for i in range(0, len(samples), frame_size):
        f = samples[i:i+frame_size]
        if len(f) < frame_size: continue
        rms = float(np.sqrt(np.mean(f**2)))
        if rms > silence_rms_cutoff:
            loud.append(rms)
    if not loud:
        return None
    return float(np.median(loud)) * multiplier

import contextlib, uuid, asyncio, json

# app.py
import os, sys, json, time, asyncio, base64, uuid, re, io
from typing import Dict, Any, Optional, List
from collections import deque

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi import Request

import numpy as np
import torch
from transformers import WhisperProcessor, WhisperForConditionalGeneration
import edge_tts
from pydub import AudioSegment

# ---- bring your helpers / constants from interview_final.py
from interview_final import (
    interview_prompt_en, interview_prompt_ur,
    parse_pdf, build_faiss_index_with_metadata, save_index_and_metadata, query_faiss,
    save_conversation_to_json, start_new_interview,
    detect_speech_in_frame, detect_speech_with_ai_rejection,
    FRAME_DURATION, FRAME_SIZE, SILENCE_DURATION, MIN_SPEECH_DURATION,
    query_groq, pdf_path, index_path, json_path
)

# ======= IMPORTANT: NEVER hardcode keys in code =======
GROQ_API_KEY = "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"
GROQ_MODEL   = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")

SAMPLE_RATE = 16000

processor = WhisperProcessor.from_pretrained("openai/whisper-small")
whisper_model = WhisperForConditionalGeneration.from_pretrained("openai/whisper-small")

# ----------------- FastAPI Setup -----------------
app = FastAPI(title="Interview Agent - WS")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:8000","http://127.0.0.1:8000"],  # tighten in prod
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
templates = Jinja2Templates(directory="templates")
app.mount("/static", StaticFiles(directory="static"), name="static")

@app.get("/")
def home(request: Request):
    return templates.TemplateResponse("index3.html", {"request": request})

# ----------------- Audio / AI utils -----------------
def pcm16_bytes_to_float32(arr: bytes) -> np.ndarray:
    # int16 -> float32 [-1, 1]
    return np.frombuffer(arr, dtype=np.int16).astype(np.float32) / 32768.0

def transcribe_float(audio_f32: np.ndarray, language="en") -> str:
    inputs = processor(audio_f32, sampling_rate=SAMPLE_RATE,
                       return_tensors="pt", return_attention_mask=True)
    try:
        ids = whisper_model.generate(
            inputs.input_features, attention_mask=inputs.attention_mask,
            task="transcribe", language=language
        )
    except Exception:
        fids = processor.get_decoder_prompt_ids(language=language, task="transcribe")
        ids = whisper_model.generate(
            inputs.input_features, attention_mask=inputs.attention_mask,
            forced_decoder_ids=fids
        )
    return processor.batch_decode(ids, skip_special_tokens=True)[0].strip()

async def tts_mp3_bytes(text: str, voice: str) -> bytes:
    # edge-tts writes to a file; we read bytes and delete
    fn = f"tts_{uuid.uuid4().hex}.mp3"
    try:
        communicate = edge_tts.Communicate(text=text, voice=voice)
        await communicate.save(fn)
        with open(fn, "rb") as f:
            return f.read()
    finally:
        try: os.remove(fn)
        except: pass

   
def calculate_ai_playback_threshold_from_bytes(mp3_bytes: bytes, multiplier=1.5, silence_rms_cutoff=1e-3):
    """Compute a robust RMS threshold from the MP3 to reject AI echo when detecting user barge-in."""
    audio = AudioSegment.from_file(io.BytesIO(mp3_bytes), format="mp3")
    samples = np.array(audio.get_array_of_samples(), dtype=np.int16).astype(np.float32) / 32768.0
    if audio.channels > 1:
        samples = samples.reshape(-1, audio.channels).mean(axis=1)
    frame_size = int(audio.frame_rate * 0.032)  # 32 ms
    loud = []
    for i in range(0, len(samples), frame_size):
        f = samples[i:i+frame_size]
        if len(f) < frame_size: continue
        rms = float(np.sqrt(np.mean(f**2)))
        if rms > silence_rms_cutoff:
            loud.append(rms)
    if not loud:
        return None
    return float(np.median(loud)) * multiplier

import contextlib, uuid, asyncio, json

async def stream_mp3(ws, sess, audio_bytes: bytes):
    gen_id = uuid.uuid4().hex
    sess.current_gen_id = gen_id
    sess.stop_playback_flag.clear()

    await ws.send_text(json.dumps({"type":"audio_begin","id": gen_id, "threshold": sess.ai_threshold}))

    CHUNK = 32_768  # 32KB
    try:
        for i in range(0, len(audio_bytes), CHUNK):
            if sess.stop_playback_flag.is_set():
                await ws.send_text(json.dumps({"type":"audio_stop","id": gen_id}))
                return
            part = audio_bytes[i:i+CHUNK]
            await ws.send_text(json.dumps({"type":"audio","id": gen_id, "mime":"audio/mpeg", "size": len(part)}))
            await ws.send_bytes(part)
            await asyncio.sleep(0)  # yield to process mic frames / barge-in
        await ws.send_text(json.dumps({"type":"audio_end","id": gen_id}))
    finally:
        sess.current_gen_id = None

# ----------------- WebSocket Session -----------------
class Session:
    def __init__(self, language: str):
        self.id = uuid.uuid4().hex
        self.lang = "en" if language.lower().startswith("en") else "ur"
        self.voice = "en-US-SteffanNeural" if self.lang == "en" else "ur-PK-UzmaNeural"
        self.system_prompt = interview_prompt_en if self.lang == "en" else interview_prompt_ur

        # in Session.__init__
        self.current_gen_id = None
        self.play_task = None
        self.stop_playback_flag = asyncio.Event()

        # convo files
        self.conversation_filename = start_new_interview(self.lang)

        # RAG
        self.embedding_model = None
        self.index = None
        self.metadata = None

        # VAD buffers
        self.audio_frames: List[np.ndarray] = []
        self.silence_frames = 0
        self.speech_detected = False
        self.speech_frame_count = 0
        self._partial: Optional[np.ndarray] = None

        self.max_silence_frames = int(SILENCE_DURATION / FRAME_DURATION)
        self.min_speech_frames = int(MIN_SPEECH_DURATION / FRAME_DURATION)

        # Interruption state
        self.ai_speaking = False
        self.ai_threshold: Optional[float] = None
        self.pre_roll_frames = deque(maxlen=int(0.5 / FRAME_DURATION))  # ~0.5s pre-roll
        self.user_talk_frames = 0
        self.user_talk_frames_needed = 1
        self._pending_audio_stop = False

        # Chat history
        self.conversation_history = [{"role": "system", "content": self.system_prompt}]
        self.previous_ai_question: Optional[str] = None

    def reset_vad(self, clear_pre_roll: bool = False):
        self.audio_frames.clear()
        self.silence_frames = 0
        self.speech_detected = False
        self.speech_frame_count = 0
        self._partial = None
        self.user_talk_frames = 0
        if clear_pre_roll:
            self.pre_roll_frames.clear()
    

    def process_incoming_pcm(self, f32: np.ndarray) -> (Optional[np.ndarray], bool):
        """Frame user PCM, detect utterances; if AI is speaking, detect barge-in and return early.
        Returns (audio, interrupted) where 'interrupted' means we detected barge-in and the
        client should stop current TTS playback immediately.
        """
        if f32 is None or f32.size == 0:
            return None, False

        # glue partials to make full frames
        if self._partial is not None and self._partial.size:
            f32 = np.concatenate([self._partial, f32])
            self._partial = None

        total = f32.size
        full_frames = (total // FRAME_SIZE) * FRAME_SIZE
        remainder = total - full_frames
        if remainder > 0:
            self._partial = f32[-remainder:]
            f32 = f32[:full_frames]
        if f32.size == 0:
            return None, False

        frames = f32.reshape(-1, FRAME_SIZE)

        for frame in frames:
            # keep short pre-roll so we don't cut the first syllable
            self.pre_roll_frames.append(frame)

            # ---- barge-in path while AI is talking ----
            if self.ai_speaking and self.ai_threshold is not None:
                has_speech = detect_speech_with_ai_rejection(
                    frame, ai_speaking=True, ai_threshold=self.ai_threshold
                )
                if has_speech:
                    if self.user_talk_frames == 0:
                        self._pending_audio_stop = True
                    self.user_talk_frames += 1
                    if self.user_talk_frames >= self.user_talk_frames_needed:
                        self.user_talk_frames = 0
                        # build a tiny buffer = pre-roll + current frame
                        self.audio_frames = list(self.pre_roll_frames)
                        audio = np.concatenate(self.audio_frames) if self.audio_frames else None
                        # flip flags; mark pending stop
                        self.reset_vad(clear_pre_roll=True)
                        self.ai_speaking = False
                        self.ai_threshold = None
                        self._pending_audio_stop = True
                        return audio, True   # <--- tell caller we interrupted
                else:
                    self.user_talk_frames = 0

                # while AI speaking we don't accumulate a full user utterance
                continue

            # ---- regular user-turn VAD ----
            has_speech = detect_speech_in_frame(frame)
            if has_speech:
                if not self.speech_detected:
                    self.speech_detected = True
                self.audio_frames.append(frame)
                self.speech_frame_count += 1
                self.silence_frames = 0
            else:
                if self.speech_detected:
                    # include trailing silence for nicer end
                    self.audio_frames.append(frame)
                    self.silence_frames += 1
                    if self.silence_frames >= self.max_silence_frames:
                        if self.speech_frame_count >= self.min_speech_frames:
                            audio = np.concatenate(self.audio_frames) if self.audio_frames else None
                            self.reset_vad(clear_pre_roll=True)
                            return audio, False
                        else:
                            self.reset_vad(clear_pre_roll=True)

        return None, False


# ----------------- WS handler -----------------
@app.websocket("/ws")
async def ws_handler(ws: WebSocket):
    await ws.accept()
    sess: Optional[Session] = None

    try:
        while True:
            msg = await ws.receive()

            # ---------- JSON control ----------
            if "text" in msg and msg["text"] is not None:
                try:
                    data = json.loads(msg["text"])
                except json.JSONDecodeError:
                    await ws.send_text(json.dumps({"type": "status", "level":"err", "message":"Invalid JSON"}))
                    continue

                typ = data.get("type")
                if typ == "start":
                    lang = (data.get("language") or "en").lower()
                    sess = Session(lang)
                    await ws.send_text(json.dumps({"type":"status","level":"ok","message":f"session started ({sess.lang})"}))

                    # Voice + greeting text
                    if sess.lang == "en":
                        sess.voice = "en-US-SteffanNeural"
                        interview_prompt = interview_prompt_en
                        greet_text = "Hello! Welcome to our interview. I am excited to learn about you. Can you please tell what brought you to data science?"
                    else:
                        sess.voice = "ur-PK-UzmaNeural"
                        interview_prompt = interview_prompt_ur
                        greet_text = "السلام علیکم! ہم انٹرویو شروع کرتے ہیں۔"

                    # Build FAISS once per session
                    topics_dict = parse_pdf(pdf_path)
                    index, embedding_model, metadata = build_faiss_index_with_metadata(topics_dict)
                    save_index_and_metadata(index, metadata, index_path, json_path)
                    sess.index, sess.embedding_model, sess.metadata = index, embedding_model, metadata

                    # Initialize conversation history (system + assistant greeting)
                    sess.conversation_history = [
                        {"role": "system", "content": interview_prompt},
                        {"role": "assistant", "content": greet_text}
                    ]

                    # Send greeting (text)
                    await ws.send_text(json.dumps({"type":"ai_text","text":greet_text}))

                    # TTS for greeting
                    audio_bytes = await tts_mp3_bytes(greet_text, sess.voice)

                    # compute rejection threshold from this exact MP3
                    # sess.ai_threshold = calculate_ai_playback_threshold_from_bytes(audio_bytes)
                    # if sess.ai_threshold is None:
                    #     sess.ai_threshold = 0.01  # fallback
                    #     print(f"[WARN] AI threshold was None — using fallback 0.01")
                    # else:
                    #     print(f"[INFO] Calculated AI threshold: {sess.ai_threshold:.6f}")
                    # sess.ai_speaking = True
                    # sess.pre_roll_frames.clear()

                    sess.ai_threshold = calculate_ai_playback_threshold_from_bytes(audio_bytes) or 0.01
                    sess.ai_speaking = True
                    sess.pre_roll_frames.clear()

                    # cancel any previous stream if still running
                    if sess.play_task and not sess.play_task.done():
                        sess.stop_playback_flag.set()
                        with contextlib.suppress(Exception):
                            await sess.play_task

                    sess.play_task = asyncio.create_task(stream_mp3(ws, sess, audio_bytes))
                    def _on_done(_):
                        sess.ai_speaking = False
                        sess.ai_threshold = None
                    sess.play_task.add_done_callback(_on_done)

                    # await ws.send_text(json.dumps({"type":"audio_begin","threshold": sess.ai_threshold}))

                    # # ship the mp3
                    # await ws.send_text(json.dumps({"type":"audio","mime":"audio/mpeg","size":len(audio_bytes)}))
                    # await ws.send_bytes(audio_bytes)

                    # # mark end (the browser may ignore if it already finished)
                    # sess.ai_speaking = False
                    # sess.ai_threshold = None
                    # await ws.send_text(json.dumps({"type":"audio_end"}))

                    # Track last AI question
                    sess.previous_ai_question = greet_text if greet_text.strip().endswith("?") else None

                elif typ == "stop":
                    if sess:
                        # Hard reset of VAD + flags
                        sess.reset_vad()
                        sess.ai_speaking = False
                        sess.ai_threshold = None
                        sess._pending_audio_stop = False
                        sess.user_talk_frames = 0
                        sess.pre_roll_frames.clear()

                    if sess and sess.play_task and not sess.play_task.done():
                        sess.stop_playback_flag.set()
                        with contextlib.suppress(Exception):
                            await sess.play_task

                    await ws.send_text(json.dumps({"type":"status","level":"ok","message":"session closed"}))
                    break

                else:
                        await ws.send_text(json.dumps({"type":"status","level":"err","message":f"unknown type {typ}"}))

            # ---------- Binary audio (PCM16@16k mono) ----------
            elif "bytes" in msg and msg["bytes"] is not None:
                if not sess:
                    continue

                f32 = pcm16_bytes_to_float32(msg["bytes"])
                utter_audio, interrupted = sess.process_incoming_pcm(f32)
               # after sess.process_incoming_pcm(...)
                if utter_audio is None:
                    if interrupted or getattr(sess, "_pending_audio_stop", False):
                        # cancel the streamer and tell client to stop the current id
                        sess.stop_playback_flag.set()
                        await ws.send_text(json.dumps({"type":"audio_stop","id": sess.current_gen_id}))
                        sess._pending_audio_stop = False
                    continue

                # if we *do* have an utterance and it was an interruption, stop too
                if interrupted or getattr(sess, "_pending_audio_stop", False):
                    sess.stop_playback_flag.set()
                    await ws.send_text(json.dumps({"type":"audio_stop","id": sess.current_gen_id}))
                    sess._pending_audio_stop = False


                # guard so we don't feed a sub-frame to STT
                if utter_audio.size < FRAME_SIZE:
                    continue


                # 1) STT
                lang_code = "en" if sess.lang == "en" else "ur"
                user_text = transcribe_float(utter_audio, language=lang_code)
                await ws.send_text(json.dumps({"type":"stt","text": user_text}))
                if not user_text or len(user_text.strip()) < 2:
                    await ws.send_text(json.dumps({"type": "status", "level": "warn", "message": "empty transcript"}))
                    continue

                # Persist last QA pair (AI question -> user answer)
                if sess.previous_ai_question:
                    try:
                        save_conversation_to_json(sess.previous_ai_question, user_text, sess.conversation_filename)
                    except Exception:
                        pass

                # 2) Build FAISS/RAG context
                context = ""
                try:
                    if sess.embedding_model is not None and sess.index is not None and sess.metadata is not None:
                        similar_qs = query_faiss(user_text, sess.embedding_model, sess.index, sess.metadata, top_n=5)
                        context = "\n".join([f"- {q[0]}" for q in similar_qs]) if similar_qs else ""
                except Exception:
                    context = ""

                # 3) LLM
                sess.conversation_history.append({"role":"user","content": user_text})
                ai_response, updated_history = query_groq(
                    user_input=user_text,
                    context=context,
                    conversation_history=sess.conversation_history
                )
                sess.conversation_history = updated_history

                # 4) Send AI response (text)
                await ws.send_text(json.dumps({"type":"ai_text","text": ai_response}))

                # 5) TTS -> send mp3 bytes with interruption controls
                # 5) TTS -> send mp3 bytes with interruption controls
                audio_bytes = await tts_mp3_bytes(ai_response, sess.voice)

                sess.ai_threshold = calculate_ai_playback_threshold_from_bytes(audio_bytes) or 0.01
                sess.ai_speaking = True
                sess.pre_roll_frames.clear()

                # cancel any previous stream if still running
                if sess.play_task and not sess.play_task.done():
                    sess.stop_playback_flag.set()
                    with contextlib.suppress(Exception):
                        await sess.play_task

                sess.play_task = asyncio.create_task(stream_mp3(ws, sess, audio_bytes))
                # sess.ai_threshold = calculate_ai_playback_threshold_from_bytes(audio_bytes)
                # sess.ai_speaking = True
                # sess.pre_roll_frames.clear()
                def _on_done(_):
                    sess.ai_speaking = False
                    sess.ai_threshold = None
                sess.play_task.add_done_callback(_on_done)


                # audio_bytes = await tts_mp3_bytes(ai_response, sess.voice)

                # sess.ai_threshold = calculate_ai_playback_threshold_from_bytes(audio_bytes)
                # sess.ai_speaking = True
                # await ws.send_text(json.dumps({"type":"audio_begin","threshold": sess.ai_threshold}))
                # await ws.send_text(json.dumps({"type":"audio","mime":"audio/mpeg","size":len(audio_bytes)}))
                # await ws.send_bytes(audio_bytes)
                # sess.ai_speaking = False
                # sess.ai_threshold = None
                # await ws.send_text(json.dumps({"type":"audio_end"}))

                # 6) Track last AI question
                sess.previous_ai_question = ai_response if ai_response.strip().endswith("?") else None

    except WebSocketDisconnect:
        pass
    except Exception as e:
        try:
            await ws.send_text(json.dumps({"type":"status","level":"err","message":f"server error: {e}"}))
        except:
            pass
    finally:
        try:
            await ws.close()
        except:
            pass

# ----------------- WebSocket Session -----------------
class Session:
    def __init__(self, language: str):
        self.id = uuid.uuid4().hex
        self.lang = "en" if language.lower().startswith("en") else "ur"
        self.voice = "en-US-SteffanNeural" if self.lang == "en" else "ur-PK-UzmaNeural"
        self.system_prompt = interview_prompt_en if self.lang == "en" else interview_prompt_ur

        # in Session.__init__
        self.current_gen_id = None
        self.play_task = None
        self.stop_playback_flag = asyncio.Event()

        # convo files
        self.conversation_filename = start_new_interview(self.lang)

        # RAG
        self.embedding_model = None
        self.index = None
        self.metadata = None

        # VAD buffers
        self.audio_frames: List[np.ndarray] = []
        self.silence_frames = 0
        self.speech_detected = False
        self.speech_frame_count = 0
        self._partial: Optional[np.ndarray] = None

        self.max_silence_frames = int(SILENCE_DURATION / FRAME_DURATION)
        self.min_speech_frames = int(MIN_SPEECH_DURATION / FRAME_DURATION)

        # Interruption state
        self.ai_speaking = False
        self.ai_threshold: Optional[float] = None
        self.pre_roll_frames = deque(maxlen=int(0.5 / FRAME_DURATION))  # ~0.5s pre-roll
        self.user_talk_frames = 0
        self.user_talk_frames_needed = 2
        self._pending_audio_stop = False

        # Chat history
        self.conversation_history = [{"role": "system", "content": self.system_prompt}]
        self.previous_ai_question: Optional[str] = None

    def reset_vad(self, clear_pre_roll: bool = False):
        self.audio_frames.clear()
        self.silence_frames = 0
        self.speech_detected = False
        self.speech_frame_count = 0
        self._partial = None
        self.user_talk_frames = 0
        if clear_pre_roll:
            self.pre_roll_frames.clear()
    

    def process_incoming_pcm(self, f32: np.ndarray) -> (Optional[np.ndarray], bool):
        """Frame user PCM, detect utterances; if AI is speaking, detect barge-in and return early.
        Returns (audio, interrupted) where 'interrupted' means we detected barge-in and the
        client should stop current TTS playback immediately.
        """
        if f32 is None or f32.size == 0:
            return None, False

        # glue partials to make full frames
        if self._partial is not None and self._partial.size:
            f32 = np.concatenate([self._partial, f32])
            self._partial = None

        total = f32.size
        full_frames = (total // FRAME_SIZE) * FRAME_SIZE
        remainder = total - full_frames
        if remainder > 0:
            self._partial = f32[-remainder:]
            f32 = f32[:full_frames]
        if f32.size == 0:
            return None, False

        frames = f32.reshape(-1, FRAME_SIZE)

        for frame in frames:
            # keep short pre-roll so we don't cut the first syllable
            self.pre_roll_frames.append(frame)

            # ---- barge-in path while AI is talking ----
            if self.ai_speaking and self.ai_threshold is not None:
                has_speech = detect_speech_with_ai_rejection(
                    frame, ai_speaking=True, ai_threshold=self.ai_threshold
                )
                if has_speech:
                    if self.user_talk_frames == 0:
                        self._pending_audio_stop = True
                    self.user_talk_frames += 1
                    if self.user_talk_frames >= self.user_talk_frames_needed:
                        self.user_talk_frames = 0
                        # build a tiny buffer = pre-roll + current frame
                        self.audio_frames = list(self.pre_roll_frames)
                        audio = np.concatenate(self.audio_frames) if self.audio_frames else None
                        # flip flags; mark pending stop
                        self.reset_vad(clear_pre_roll=True)
                        self.ai_speaking = False
                        self.ai_threshold = None
                        self._pending_audio_stop = True
                        return audio, True   # <--- tell caller we interrupted
                else:
                    self.user_talk_frames = 0

                # while AI speaking we don't accumulate a full user utterance
                continue

            # ---- regular user-turn VAD ----
            has_speech = detect_speech_in_frame(frame)
            if has_speech:
                if not self.speech_detected:
                    self.speech_detected = True
                self.audio_frames.append(frame)
                self.speech_frame_count += 1
                self.silence_frames = 0
            else:
                if self.speech_detected:
                    # include trailing silence for nicer end
                    self.audio_frames.append(frame)
                    self.silence_frames += 1
                    if self.silence_frames >= self.max_silence_frames:
                        if self.speech_frame_count >= self.min_speech_frames:
                            audio = np.concatenate(self.audio_frames) if self.audio_frames else None
                            self.reset_vad(clear_pre_roll=True)
                            return audio, False
                        else:
                            self.reset_vad(clear_pre_roll=True)

        return None, False


# ----------------- WS handler -----------------
@app.websocket("/ws")
async def ws_handler(ws: WebSocket):
    await ws.accept()
    sess: Optional[Session] = None

    try:
        while True:
            msg = await ws.receive()

            # ---------- JSON control ----------
            if "text" in msg and msg["text"] is not None:
                try:
                    data = json.loads(msg["text"])
                except json.JSONDecodeError:
                    await ws.send_text(json.dumps({"type": "status", "level":"err", "message":"Invalid JSON"}))
                    continue

                typ = data.get("type")
                if typ == "start":
                    lang = (data.get("language") or "en").lower()
                    sess = Session(lang)
                    await ws.send_text(json.dumps({"type":"status","level":"ok","message":f"session started ({sess.lang})"}))

                    # Voice + greeting text
                    if sess.lang == "en":
                        sess.voice = "en-US-SteffanNeural"
                        interview_prompt = interview_prompt_en
                        greet_text = "Hello! Welcome to our interview. I am excited to learn about you. Can you please tell what brought you to data science?"
                    else:
                        sess.voice = "ur-PK-UzmaNeural"
                        interview_prompt = interview_prompt_ur
                        greet_text = "السلام علیکم! ہم انٹرویو شروع کرتے ہیں۔"

                    # Build FAISS once per session
                    topics_dict = parse_pdf(pdf_path)
                    index, embedding_model, metadata = build_faiss_index_with_metadata(topics_dict)
                    save_index_and_metadata(index, metadata, index_path, json_path)
                    sess.index, sess.embedding_model, sess.metadata = index, embedding_model, metadata

                    # Initialize conversation history (system + assistant greeting)
                    sess.conversation_history = [
                        {"role": "system", "content": interview_prompt},
                        {"role": "assistant", "content": greet_text}
                    ]

                    # Send greeting (text)
                    await ws.send_text(json.dumps({"type":"ai_text","text":greet_text}))

                    # TTS for greeting
                    audio_bytes = await tts_mp3_bytes(greet_text, sess.voice)

                    # compute rejection threshold from this exact MP3
                    # sess.ai_threshold = calculate_ai_playback_threshold_from_bytes(audio_bytes)
                    # if sess.ai_threshold is None:
                    #     sess.ai_threshold = 0.01  # fallback
                    #     print(f"[WARN] AI threshold was None — using fallback 0.01")
                    # else:
                    #     print(f"[INFO] Calculated AI threshold: {sess.ai_threshold:.6f}")
                    # sess.ai_speaking = True
                    # sess.pre_roll_frames.clear()

                    sess.ai_threshold = calculate_ai_playback_threshold_from_bytes(audio_bytes) or 0.01
                    sess.ai_speaking = True
                    sess.pre_roll_frames.clear()

                    # cancel any previous stream if still running
                    if sess.play_task and not sess.play_task.done():
                        sess.stop_playback_flag.set()
                        with contextlib.suppress(Exception):
                            await sess.play_task

                    sess.play_task = asyncio.create_task(stream_mp3(ws, sess, audio_bytes))
                    def _on_done(_):
                        sess.ai_speaking = False
                        sess.ai_threshold = None
                    sess.play_task.add_done_callback(_on_done)

                    # await ws.send_text(json.dumps({"type":"audio_begin","threshold": sess.ai_threshold}))

                    # # ship the mp3
                    # await ws.send_text(json.dumps({"type":"audio","mime":"audio/mpeg","size":len(audio_bytes)}))
                    # await ws.send_bytes(audio_bytes)

                    # # mark end (the browser may ignore if it already finished)
                    # sess.ai_speaking = False
                    # sess.ai_threshold = None
                    # await ws.send_text(json.dumps({"type":"audio_end"}))

                    # Track last AI question
                    sess.previous_ai_question = greet_text if greet_text.strip().endswith("?") else None

                elif typ == "stop":
                    if sess:
                        # Hard reset of VAD + flags
                        sess.reset_vad()
                        sess.ai_speaking = False
                        sess.ai_threshold = None
                        sess._pending_audio_stop = False
                        sess.user_talk_frames = 0
                        sess.pre_roll_frames.clear()

                    if sess and sess.play_task and not sess.play_task.done():
                        sess.stop_playback_flag.set()
                        with contextlib.suppress(Exception):
                            await sess.play_task

                    await ws.send_text(json.dumps({"type":"status","level":"ok","message":"session closed"}))
                    break

                else:
                        await ws.send_text(json.dumps({"type":"status","level":"err","message":f"unknown type {typ}"}))

            # ---------- Binary audio (PCM16@16k mono) ----------
            elif "bytes" in msg and msg["bytes"] is not None:
                if not sess:
                    continue

                f32 = pcm16_bytes_to_float32(msg["bytes"])
                utter_audio, interrupted = sess.process_incoming_pcm(f32)
               # after sess.process_incoming_pcm(...)
                if utter_audio is None:
                    if interrupted or getattr(sess, "_pending_audio_stop", False):
                        # cancel the streamer and tell client to stop the current id
                        sess.stop_playback_flag.set()
                        await ws.send_text(json.dumps({"type":"audio_stop","id": sess.current_gen_id}))
                        sess._pending_audio_stop = False
                    continue

                # if we *do* have an utterance and it was an interruption, stop too
                if interrupted or getattr(sess, "_pending_audio_stop", False):
                    sess.stop_playback_flag.set()
                    await ws.send_text(json.dumps({"type":"audio_stop","id": sess.current_gen_id}))
                    sess._pending_audio_stop = False


                # guard so we don't feed a sub-frame to STT
                if utter_audio.size < FRAME_SIZE:
                    continue


                # 1) STT
                lang_code = "en" if sess.lang == "en" else "ur"
                user_text = transcribe_float(utter_audio, language=lang_code)
                await ws.send_text(json.dumps({"type":"stt","text": user_text}))
                if not user_text or len(user_text.strip()) < 2:
                    await ws.send_text(json.dumps({"type": "status", "level": "warn", "message": "empty transcript"}))
                    continue

                # Persist last QA pair (AI question -> user answer)
                if sess.previous_ai_question:
                    try:
                        save_conversation_to_json(sess.previous_ai_question, user_text, sess.conversation_filename)
                    except Exception:
                        pass

                # 2) Build FAISS/RAG context
                context = ""
                try:
                    if sess.embedding_model is not None and sess.index is not None and sess.metadata is not None:
                        similar_qs = query_faiss(user_text, sess.embedding_model, sess.index, sess.metadata, top_n=5)
                        context = "\n".join([f"- {q[0]}" for q in similar_qs]) if similar_qs else ""
                except Exception:
                    context = ""

                # 3) LLM
                sess.conversation_history.append({"role":"user","content": user_text})
                ai_response, updated_history = query_groq(
                    user_input=user_text,
                    context=context,
                    conversation_history=sess.conversation_history
                )
                sess.conversation_history = updated_history

                # 4) Send AI response (text)
                await ws.send_text(json.dumps({"type":"ai_text","text": ai_response}))

                # 5) TTS -> send mp3 bytes with interruption controls
                # 5) TTS -> send mp3 bytes with interruption controls
                audio_bytes = await tts_mp3_bytes(ai_response, sess.voice)

                sess.ai_threshold = calculate_ai_playback_threshold_from_bytes(audio_bytes) or 0.01
                sess.ai_speaking = True
                sess.pre_roll_frames.clear()

                # cancel any previous stream if still running
                if sess.play_task and not sess.play_task.done():
                    sess.stop_playback_flag.set()
                    with contextlib.suppress(Exception):
                        await sess.play_task

                sess.play_task = asyncio.create_task(stream_mp3(ws, sess, audio_bytes))
                # sess.ai_threshold = calculate_ai_playback_threshold_from_bytes(audio_bytes)
                # sess.ai_speaking = True
                # sess.pre_roll_frames.clear()
                def _on_done(_):
                    sess.ai_speaking = False
                    sess.ai_threshold = None
                sess.play_task.add_done_callback(_on_done)


                # audio_bytes = await tts_mp3_bytes(ai_response, sess.voice)

                # sess.ai_threshold = calculate_ai_playback_threshold_from_bytes(audio_bytes)
                # sess.ai_speaking = True
                # await ws.send_text(json.dumps({"type":"audio_begin","threshold": sess.ai_threshold}))
                # await ws.send_text(json.dumps({"type":"audio","mime":"audio/mpeg","size":len(audio_bytes)}))
                # await ws.send_bytes(audio_bytes)
                # sess.ai_speaking = False
                # sess.ai_threshold = None
                # await ws.send_text(json.dumps({"type":"audio_end"}))

                # 6) Track last AI question
                sess.previous_ai_question = ai_response if ai_response.strip().endswith("?") else None

    except WebSocketDisconnect:
        pass
    except Exception as e:
        try:
            await ws.send_text(json.dumps({"type":"status","level":"err","message":f"server error: {e}"}))
        except:
            pass
    finally:
        try:
            await ws.close()
        except:
            pass
