# app.py
import os, sys, json, time, asyncio, base64, uuid, re
from typing import Dict, Any, Optional, List

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi import Request
from interview_final import *
import numpy as np
import soundfile as sf
import torch
from transformers import WhisperProcessor, WhisperForConditionalGeneration
import edge_tts
import requests
from interview_final import *


GROQ_API_KEY = "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"
# ======= IMPORTANT: NEVER hardcode keys in code =======
#GROQ_API_KEY = os.getenv("GROQ_API_KEY")  # set in environment
GROQ_MODEL   = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")

SAMPLE_RATE = 16000

processor = WhisperProcessor.from_pretrained("openai/whisper-small")
whisper_model = WhisperForConditionalGeneration.from_pretrained("openai/whisper-small")


# ----------------- FastAPI Setup -----------------
app = FastAPI(title="Interview Agent - WS")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:8000",
        "http://127.0.0.1:8000"],  # tighten in prod
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
templates = Jinja2Templates(directory="templates")
app.mount("/static", StaticFiles(directory="static"), name="static") 
@app.get("/")
def home(request: Request):
    return templates.TemplateResponse("index3.html", {"request": request})

# ----------------- Audio / AI utils -----------------
def pcm16_bytes_to_float32(arr: bytes) -> np.ndarray:
    # int16 -> float32 [-1, 1]
    a = np.frombuffer(arr, dtype=np.int16).astype(np.float32) / 32768.0
    return a

def transcribe_float(audio_f32: np.ndarray, language="en") -> str:
    inputs = processor(audio_f32, sampling_rate=SAMPLE_RATE,
                       return_tensors="pt", return_attention_mask=True)
    try:
        ids = whisper_model.generate(
            inputs.input_features, attention_mask=inputs.attention_mask,
            task="transcribe", language=language
        )
    except:
        fids = processor.get_decoder_prompt_ids(language=language, task="transcribe")
        ids = whisper_model.generate(
            inputs.input_features, attention_mask=inputs.attention_mask,
            forced_decoder_ids=fids
        )
    return processor.batch_decode(ids, skip_special_tokens=True)[0].strip()


async def tts_mp3_bytes(text: str, voice: str) -> bytes:
    # edge-tts streams to a file path; to keep it simple, write->read then remove.
    fn = f"tts_{uuid.uuid4().hex}.mp3"
    try:
        communicate = edge_tts.Communicate(text=text, voice=voice)
        await communicate.save(fn)
        with open(fn, "rb") as f:
            return f.read()
    finally:
        try:
            os.remove(fn)
        except:
            pass

async def ws_send_audio_stream_start(ws, mime="audio/mpeg"):
    await ws.send_text(json.dumps({"type": "audio_stream_start", "mime": mime}))

async def ws_send_audio_chunk(ws, chunk: bytes):
    await ws.send_bytes(chunk)

async def ws_send_audio_stream_end(ws, reason="ok"):
    await ws.send_text(json.dumps({"type": "audio_stream_end", "reason": reason}))

async def tts_stream_ws(text: str, voice: str, ws, stop_event, chunk_ms: int = 200):
    """
    Stream TTS (MP3) over WebSocket in chunks and stop immediately when stop_event is set.
    Uses edge-tts streaming API. Returns True if completed, False if interrupted/error.
    """
    communicate = edge_tts.Communicate(text=text, voice=voice)
    await ws_send_audio_stream_start(ws, mime="audio/mpeg")

    try:
        async for part in communicate.stream():
            if stop_event.is_set():
                await ws_send_audio_stream_end(ws, reason="interrupted")
                return False

            if part["type"] == "audio":
                await ws_send_audio_chunk(ws, part["data"])
            # (optional) handle WordBoundary, SentenceBoundary if needed

        await ws_send_audio_stream_end(ws, reason="ok")
        return True

    except Exception as e:
        try:
            await ws_send_audio_stream_end(ws, reason=f"error:{e}")
        except:
            pass
        return False

# ----------------- WebSocket Session -----------------
class Session:
    def __init__(self, lang: str = "en"):
        self.lang = lang
        self.voice = "en-US-SteffanNeural" if lang == "en" else "ur-PK-UzmaNeural"
        self.tts_task = None

        # conversation state you already maintain:
        self.conversation_history = []
        self.messages = []
        self.conversation_context = []
        self.previous_ai_question = None

        # RAG holders you already set in start:
        self.embedding_model = None
        self.index = None
        self.metadata = None

        # --- Auto-VAD state (you already have this if you used earlier patch) ---
        self.audio_frames = []
        self.silence_frames = 0
        self.speech_detected = False
        self.speech_frame_count = 0
        self.max_silence_frames = int(SILENCE_DURATION / FRAME_DURATION)
        self.min_speech_frames = int(MIN_SPEECH_DURATION / FRAME_DURATION)
        self._partial = None

        # --- Interruption / barge-in state ---
        self.is_speaking = False              # AI currently speaking
        self.stop_speaking = Event()          # backend-only cancel
        self.user_interrupted = False

        self.realtime_audio_buffer = []       # ~5s rolling buffer while AI is speaking
        self.max_buffer_frames = int(5.0 / FRAME_DURATION)
        self.collecting_interrupt = False     # after interrupt, we’re collecting utterance
        self.interrupt_seed_sent = False
        self.current_ai_rms_threshold = None
        self.tts_task = None   # holds asyncio.Task for the current TTS stream


    # ---------- Auto-VAD you already have (abbrev) ----------
    def reset_vad(self):
        self.audio_frames.clear()
        self.silence_frames = 0
        self.speech_detected = False
        self.speech_frame_count = 0
        self._partial = None
    # --- NEW: feed PCM16->float32 chunk(s) and detect utterance boundaries ---
    # Returns: np.ndarray (float32 mono) when an utterance is complete, else None
    def process_incoming_pcm(self, f32: np.ndarray) -> Optional[np.ndarray]:
        if f32 is None or f32.size == 0:
            return None

        # Glue with any leftover from last time to make full 512-sample frames
        if self._partial is not None and self._partial.size:
            f32 = np.concatenate([self._partial, f32])
            self._partial = None

        total = f32.size
        full_frames = (total // FRAME_SIZE) * FRAME_SIZE
        remainder = total - full_frames

        if remainder > 0:
            self._partial = f32[-remainder:]
            f32 = f32[:full_frames]

        if f32.size == 0:
            return None

        frames = f32.reshape(-1, FRAME_SIZE)

        # Mirror continuous_speech_listener logic (frame-based)
        for frame in frames:
            has_speech = detect_speech_in_frame(frame)  # from interview_final.py
            if has_speech:
                if not self.speech_detected:
                    self.speech_detected = True
                self.audio_frames.append(frame)
                self.speech_frame_count += 1
                self.silence_frames = 0
            else:
                if self.speech_detected:
                    # include trailing silence for nicer turn-end context (as in original)
                    self.audio_frames.append(frame)
                    self.silence_frames += 1

                    if self.silence_frames >= self.max_silence_frames:
                        # end utterance only if we had enough speech frames
                        if self.speech_frame_count >= self.min_speech_frames:
                            audio = np.concatenate(self.audio_frames) if self.audio_frames else None
                            # reset for next utterance
                            self.reset_vad()
                            return audio
                        else:
                            # too short: treat as noise → reset but keep partials clean
                            self.reset_vad()
                else:
                    # haven't detected speech yet; just ignore leading silence
                    pass

        return None
    
    def _append_realtime_buffer(self, frame: np.ndarray):
        """Keep a rolling buffer so we don't miss the start of interruption."""
        self.realtime_audio_buffer.append(frame.copy())
        if len(self.realtime_audio_buffer) > self.max_buffer_frames:
            self.realtime_audio_buffer = self.realtime_audio_buffer[-self.max_buffer_frames:]

    def _flush_realtime_buffer(self) -> Optional[np.ndarray]:
        if not self.realtime_audio_buffer:
            return None
        out = np.concatenate(self.realtime_audio_buffer)
        self.realtime_audio_buffer.clear()
        return out

    def seed_interrupt_vad_with_buffer(self):
        """Feed buffered start into your normal VAD so the utterance includes the beginning."""
        seed = self._flush_realtime_buffer()
        if seed is not None and seed.size > 0:
            _ = self.process_incoming_pcm(seed)   # your existing VAD path

    def monitor_frame_for_interruption(self, frame: np.ndarray) -> bool:
        """
        Socket-based equivalent of _monitor_interruption:
        - respects stabilization delay
        - keeps a rolling buffer
        - uses enhanced VAD with AI echo rejection
        - requires N consecutive speech frames
        Returns True when interruption is confirmed (caller will stop speaking).
        """
        if not self.is_speaking:
            return False

        # Stabilization delay to avoid false positives right after playback starts
        if self.playback_start_time is not None:
            if (time.time() - self.playback_start_time) < self._stabilization_delay:
                self._append_realtime_buffer(frame)
                return False

        # Always buffer so we can seed VAD later
        self._append_realtime_buffer(frame)

        # Basic + enhanced detection (with fallback)
        frame_rms = compute_rms(frame)
        try:
            has_speech = detect_speech_with_ai_rejection(
                frame,
                ai_speaking=True,
                ai_threshold=self.current_ai_rms_threshold
            )
        except Exception:
            # If enhanced path unavailable, fall back to RMS gate
            has_speech = frame_rms > RMS_THRESHOLD

        if has_speech:
            self._int_consecutive_speech += 1

            # Your lenient loudness rule vs AI playback (50% of AI loudness)
            ai_thr = self.current_ai_rms_threshold
            loud_enough = (ai_thr is None) or (frame_rms > ai_thr * 0.5)

            if self._int_consecutive_speech >= self._int_required_speech and loud_enough:
                # Confirmed interruption: let caller stop speaking and seed VAD
                return True
        else:
            self._int_consecutive_speech = 0

        return False

    def start_ai_playback_monitor(self, ai_rms_threshold: Optional[float] = None):
        self.is_speaking = True
        self.stop_speaking.clear()
        self.user_interrupted = False
        self.realtime_audio_buffer.clear()
        self.current_ai_rms_threshold = ai_rms_threshold
        self.playback_start_time = time.time()
        self._int_consecutive_speech = 0

    def stop_ai_playback_monitor(self):
        self.is_speaking = False
        self.current_ai_rms_threshold = None
        self.playback_start_time = None
        self._int_consecutive_speech = 0
        self.realtime_audio_buffer.clear()

# ----------------- WS Protocol -----------------
# Client sends JSON messages and binary frames:
# 1) {"type":"start","language":"en"|"ur"}
# 2) {"type":"utterance_start"}
# 3) (binary) PCM16@16k mono frames repeatedly
# 4) {"type":"utterance_end"} -> server STT -> LLM -> TTS -> send back
#
# Server sends:
# - {"type":"status","message":"..."}
# - {"type":"stt","text":"..."}
# - {"type":"ai_text","text":"..."}
# - binary audio with header {"type":"audio","mime":"audio/mpeg","size":...} followed by raw bytes

@app.websocket("/ws")
async def ws_handler(ws: WebSocket):
    """WebSocket: start session, stream mic PCM16, auto-VAD turns, barge-in interruption."""
    await ws.accept()
    sess: Optional[Session] = None

    try:
        while True:
            # ---- Optional: clean up if a previous TTS finished naturally ----
            if sess and sess.tts_task is not None and sess.tts_task.done():
                try:
                    await sess.tts_task
                finally:
                    sess.tts_task = None
                sess.stop_ai_playback_monitor()

            msg = await ws.receive()  # {"text": "..."} or {"bytes": b"..."}
            # -------------------- TEXT CONTROL --------------------
            if "text" in msg and msg["text"] is not None:
                # Parse JSON control
                try:
                    data = json.loads(msg["text"])
                except json.JSONDecodeError:
                    await ws.send_text(json.dumps({"type": "status", "level": "err", "message": "Invalid JSON"}))
                    continue

                typ = (data.get("type") or "").lower()

                # ---- START SESSION ----
                if typ == "start":
                    lang = (data.get("language") or "en").lower()
                    sess = Session(lang)
                    await ws.send_text(json.dumps({
                        "type": "status", "level": "ok", "message": f"session started ({sess.lang})"
                    }))

                    # Language + prompt + greeting
                    if sess.lang == "en":
                        sess.voice = "en-US-SteffanNeural"
                        interview_prompt = interview_prompt_en
                        greet_text = ("Hello! Welcome to our interview. I am excited to learn about you. "
                                      "Can you please tell what brought you to data science?")
                    else:
                        sess.voice = "ur-PK-UzmaNeural"
                        interview_prompt = interview_prompt_ur
                        greet_text = "السلام علیکم! ہم انٹرویو شروع کرتے ہیں۔"

                    # (Optional) Build FAISS once per session
                    try:
                        topics_dict = parse_pdf(pdf_path)
                        index, embedding_model, metadata = build_faiss_index_with_metadata(topics_dict)
                        save_index_and_metadata(index, metadata, index_path, json_path)
                        sess.index = index
                        sess.embedding_model = embedding_model
                        sess.metadata = metadata
                    except Exception:
                        # Non-fatal: continue without RAG
                        sess.index = sess.embedding_model = sess.metadata = None

                    # Initialize conversation history (system + assistant greeting)
                    sess.conversation_history = [
                        {"role": "system", "content": interview_prompt},
                        {"role": "assistant", "content": greet_text}
                    ]
                    sess.messages = list(sess.conversation_history)
                    sess.previous_ai_question = greet_text if greet_text.strip().endswith("?") else None

                    # Send greeting (text + simple mp3)
                    await ws.send_text(json.dumps({"type": "ai_text", "text": greet_text}))
                    try:
                        audio_bytes = await tts_mp3_bytes(greet_text, sess.voice)
                        await ws.send_text(json.dumps({"type": "audio", "mime": "audio/mpeg", "size": len(audio_bytes)}))
                        await ws.send_bytes(audio_bytes)
                    except Exception:
                        pass

                elif typ == "stop":
                    await ws.send_text(json.dumps({"type": "status", "level": "ok", "message": "session closed"}))
                    break

                else:
                    await ws.send_text(json.dumps({"type": "status", "level": "err", "message": f"unknown type {typ}"}))

            # -------------------- BINARY AUDIO --------------------
            elif "bytes" in msg and msg["bytes"] is not None:
                if not sess:
                    continue  # ignore audio until session exists

                # PCM16 -> float32 mono [-1, 1]
                f32 = pcm16_bytes_to_float32(msg["bytes"])
                if f32.size:
                    f32 = np.clip(f32, -1.0, 1.0)

                # --------- If AI is speaking: check for interruption per FRAME_SIZE frame ---------
                if sess.is_speaking and not sess.collecting_interrupt and f32.size >= FRAME_SIZE:
                    full = (f32.size // FRAME_SIZE) * FRAME_SIZE
                    frames = f32[:full].reshape(-1, FRAME_SIZE)

                    interrupted_now = False
                    for frame in frames:
                        if sess.monitor_frame_for_interruption(frame):
                            # Backend-only cancel: stop streaming immediately
                            sess.user_interrupted = True
                            sess.collecting_interrupt = True
                            sess.stop_speaking.set()        # <- cancels tts_stream_ws mid-stream

                            # If there's a running TTS task, wait for it to end cleanly
                            if sess.tts_task is not None:
                                try:
                                    await sess.tts_task
                                finally:
                                    sess.tts_task = None
                            sess.stop_ai_playback_monitor()

                            sess.seed_interrupt_vad_with_buffer()
                            _ = sess.process_incoming_pcm(frame)  # include the current frame
                            interrupted_now = True
                        else:
                            # keep partials glued for VAD consistency
                            _ = sess.process_incoming_pcm(np.empty(0, dtype=np.float32))

                    # push remainder into VAD
                    rem = f32[full:]
                    if rem.size:
                        _ = sess.process_incoming_pcm(rem)

                    if interrupted_now:
                        # Try to close the interruption quickly; else wait for more frames
                        interrupt_audio = sess.process_incoming_pcm(np.empty(0, dtype=np.float32))
                        if interrupt_audio is None:
                            continue

                        # ---- STT on interruption ----
                        lang_code = "en" if sess.lang == "en" else "ur"
                        user_text = transcribe_float(interrupt_audio, language=lang_code)
                        await ws.send_text(json.dumps({"type": "stt", "text": user_text}))

                        if not user_text or len(user_text.strip()) < 2:
                            await ws.send_text(json.dumps({"type": "status", "level": "warn", "message": "empty transcript"}))
                            sess.collecting_interrupt = False
                            continue

                        # Save last QA pair if present
                        if sess.previous_ai_question:
                            try:
                                save_conversation_to_json(sess.previous_ai_question, user_text, conversation_filename)
                            except Exception:
                                pass
                            sess.conversation_context.append((sess.previous_ai_question, user_text))
                            if len(sess.conversation_context) > 2:
                                sess.conversation_context = sess.conversation_context[-2:]

                        # Build FAISS context (non-fatal)
                        context = ""
                        try:
                            if sess.embedding_model is not None and sess.index is not None and sess.metadata is not None:
                                similar_qs = query_faiss(user_text, sess.embedding_model, sess.index, sess.metadata, top_n=5)
                                context = "\n".join([f"- {q[0]}" for q in similar_qs]) if similar_qs else ""
                        except Exception:
                            context = ""

                        # LLM (use conversation history)
                        sess.conversation_history.append({"role": "user", "content": user_text})
                        ai_response, updated_history = query_groq(
                            user_input=user_text,
                            context=context,
                            conversation_history=sess.conversation_history
                        )
                        sess.conversation_history = updated_history
                        sess.messages = list(sess.conversation_history)

                        await ws.send_text(json.dumps({"type": "ai_text", "text": ai_response}))

                        # --- Stream TTS concurrently (interruptible) ---
                        sess.start_ai_playback_monitor()
                        sess.tts_task = asyncio.create_task(
                            tts_stream_ws(ai_response, sess.voice, ws, sess.stop_speaking)
                        )

                        sess.previous_ai_question = ai_response if ai_response.strip().endswith("?") else None
                        sess.collecting_interrupt = False
                        continue  # handled this turn

                # --------- Normal path (no AI speaking or no interruption) ---------
                utter_audio = sess.process_incoming_pcm(f32)
                if utter_audio is None:
                    continue  # need more frames

                # 1) STT
                lang_code = "en" if sess.lang == "en" else "ur"
                user_text = transcribe_float(utter_audio, language=lang_code)
                await ws.send_text(json.dumps({"type": "stt", "text": user_text}))

                if not user_text or len(user_text.strip()) < 2:
                    await ws.send_text(json.dumps({"type": "status", "level": "warn", "message": "empty transcript"}))
                    continue

                # Save last QA pair if present
                if sess.previous_ai_question:
                    try:
                        save_conversation_to_json(sess.previous_ai_question, user_text, conversation_filename)
                    except Exception:
                        pass
                    sess.conversation_context.append((sess.previous_ai_question, user_text))
                    if len(sess.conversation_context) > 2:
                        sess.conversation_context = sess.conversation_context[-2:]

                # 2) Build FAISS/RAG context
                context = ""
                try:
                    if sess.embedding_model is not None and sess.index is not None and sess.metadata is not None:
                        similar_qs = query_faiss(user_text, sess.embedding_model, sess.index, sess.metadata, top_n=5)
                        context = "\n".join([f"- {q[0]}" for q in similar_qs]) if similar_qs else ""
                except Exception:
                    context = ""

                # 3) LLM with conversation history
                sess.conversation_history.append({"role": "user", "content": user_text})
                ai_response, updated_history = query_groq(
                    user_input=user_text,
                    context=context,
                    conversation_history=sess.conversation_history
                )
                sess.conversation_history = updated_history
                sess.messages = list(sess.conversation_history)

                # 4) Send AI response text
                await ws.send_text(json.dumps({"type": "ai_text", "text": ai_response}))

                # 5) Stream TTS concurrently (so barge-in works)
                sess.start_ai_playback_monitor()
                sess.tts_task = asyncio.create_task(
                    tts_stream_ws(ai_response, sess.voice, ws, sess.stop_speaking)
                )

                # 6) Track last AI question
                sess.previous_ai_question = ai_response if ai_response.strip().endswith("?") else None

    except WebSocketDisconnect:
        pass
    except Exception as e:
        try:
            await ws.send_text(json.dumps({"type": "status", "level": "err", "message": f"server error: {e}"}))
        except:
            pass
    finally:
        try:
            # If a TTS is still running, cancel gracefully
            if sess and sess.tts_task is not None:
                sess.stop_speaking.set()
                try:
                    await sess.tts_task
                finally:
                    sess.tts_task = None
                sess.stop_ai_playback_monitor()
            await ws.close()
        except:
            pass
