# pip install reportlab google-auth google-auth-oauthlib google-api-python-client GitPython

from __future__ import print_function
import os
import base64
import mimetypes
import json
import uuid
import csv
import ast
import importlib.util
import sys
import random
import sqlite3
import pathlib
from datetime import datetime
from pathlib import Path

from email.message import EmailMessage

# Google / APIs
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from google.auth.transport.requests import Request

# Optional libs you had listed (PyPDF2 not used here, kept for parity)
# import PyPDF2
import git

# =========================
# ======== CONFIG =========
# =========================

SCOPES = [
    "https://www.googleapis.com/auth/gmail.send",
    "https://www.googleapis.com/auth/forms.responses.readonly",
]

# Paths
DB_PATH = "/home/aliza-ashfaq/Desktop/project_/test/Database.db"
CLONED_REPOS_DIR = "/home/aliza-ashfaq/Desktop/project_/test/cloned_repos"
CSV_PATH = "ml_interview_questions_Q1_to_Q10.csv"
ASSESSMENTS_FILE = "all_assessments.json"
CLIENT_SECRET_FILE = "client_secret_993249251770-39ot8taj89kdptcqqgdii5pjerprid2u.apps.googleusercontent.com.json"

# Email + Form
SENDER = "alizaak265@gmail.com"
SUBJECT = "Your ML/DSA Assessment PDF"
GOOGLE_FORM_URL = "https://forms.gle/mYprdvnCaW8bDJuz7"
BODY_TEMPLATE = f"""Hi,

Please find the DSA assessment PDF attached.

Also, fill out this Google Form: {GOOGLE_FORM_URL}

Thanks!
"""

# Google Form ID (responses are fetched later in the pipeline)
FORM_ID = "1mo_5-XMT8_hTKGj9D-ddWTh3cWBvNe7RKNJuQjKePbo"


# =====================================
# ======== DB / SELECTION LOGIC =======
# =====================================

def get_top_candidates(db_path=DB_PATH, limit=3):
    """
    Return top-N candidates by resume_score with non-empty emails.
    Expected table columns: candidate_id, email_address, resume_score
    """
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("""
        SELECT candidate_id, email_address
        FROM candidates
        WHERE email_address IS NOT NULL AND TRIM(email_address) <> ''
        ORDER BY resume_score DESC
        LIMIT ?
    """, (limit,))
    rows = cursor.fetchall()
    conn.close()
    return [{"candidate_id": r[0], "email_address": r[1]} for r in rows]


# =====================================
# ======== QUESTION BANK HELPERS ======
# =====================================

def load_dsa_questions(csv_path=CSV_PATH):
    """Load unique DSA questions from the CSV file"""
    questions = []
    seen_questions = set()
    with open(csv_path, 'r', newline='', encoding='utf-8') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            q = row["question"]
            if q not in seen_questions:
                questions.append(q)
                seen_questions.add(q)
    return questions


def pick_random_questions(questions, min_q=4, max_q=5, seed=None):
    """
    Pick a random number of unique questions between min_q and max_q (inclusive).
    """
    if seed is not None:
        random.seed(seed)
    n = random.randint(min_q, max_q)
    if len(questions) < n:
        raise ValueError(f"Need at least {n} questions, got {len(questions)}.")
    return random.sample(questions, n)


# =====================================
# ============ PDF MAKER ==============
# =====================================

def save_pdf(questions, title="DSA Assessment", out_path="quiz.pdf", candidate_id=None):
    from reportlab.lib.pagesizes import A4
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib.units import mm
    import html

    styles = getSampleStyleSheet()
    style_title = styles["Title"]
    style_q = styles["BodyText"]
    style_q.fontSize = 12
    style_q.leading = 16

    doc = SimpleDocTemplate(out_path, pagesize=A4, leftMargin=20*mm, rightMargin=20*mm,
                            topMargin=20*mm, bottomMargin=20*mm)
    story = []

    if candidate_id:
        story.append(Paragraph(f"Candidate ID: {candidate_id}", style_title))
        story.append(Spacer(1, 12))
    story.append(Paragraph(title, style_title))
    story.append(Paragraph(datetime.now().strftime("%Y-%m-%d %H:%M"), styles["Normal"]))
    story.append(Spacer(1, 12))

    for i, q in enumerate(questions, start=1):
        story.append(Paragraph(f"{i}. {html.escape(q)}", style_q))
        story.append(Spacer(1, 24))

    doc.build(story)
    return str(Path(out_path).resolve())


# =====================================
# ============ GMAIL HELP =============
# =====================================

def get_gmail_service():
    creds = None
    if os.path.exists("token.json"):
        creds = Credentials.from_authorized_user_file("token.json", SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
            with open("token.json", "w") as f:
                f.write(creds.to_json())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(CLIENT_SECRET_FILE, SCOPES)
            creds = flow.run_local_server(port=0)
            with open("token.json", "w") as f:
                f.write(creds.to_json())
    return build("gmail", "v1", credentials=creds)


def create_message_with_attachment(sender, to, subject, body_text, file_path):
    message = EmailMessage()
    message["To"] = to
    message["From"] = sender
    message["Subject"] = subject
    message.set_content(body_text)

    ctype, _ = mimetypes.guess_type(file_path)
    maintype, subtype = (ctype.split("/", 1) if ctype else ("application", "octet-stream"))
    with open(file_path, "rb") as f:
        message.add_attachment(f.read(), maintype=maintype, subtype=subtype, filename=os.path.basename(file_path))

    raw = base64.urlsafe_b64encode(message.as_bytes()).decode()
    return {"raw": raw}


# =====================================
# ======= FORMS / RESPONSES API =======
# =====================================

def get_forms_creds():
    # Reuse token.json for both scopes; SCOPES already includes forms readonly
    creds = None
    if os.path.exists("token.json"):
        creds = Credentials.from_authorized_user_file("token.json", SCOPES)
    if creds and creds.expired and creds.refresh_token:
        try:
            creds.refresh(Request())
            with open("token.json", "w") as f:
                f.write(creds.to_json())
        except Exception as e:
            print(f"Error refreshing token: {e}")
            creds = None
    if not creds or not creds.valid:
        flow = InstalledAppFlow.from_client_secrets_file(CLIENT_SECRET_FILE, SCOPES)
        creds = flow.run_local_server(port=0)
        with open("token.json", "w") as f:
            f.write(creds.to_json())
    return creds


def list_all_responses(form_id):
    creds = get_forms_creds()
    svc = build("forms", "v1", credentials=creds)
    out, token = [], None
    try:
        while True:
            resp = svc.forms().responses().list(formId=form_id, pageToken=token).execute()
            out.extend(resp.get("responses", []))
            token = resp.get("nextPageToken")
            if not token:
                break
        return out
    except Exception as e:
        print(f"Error getting responses: {e}")
        return []


# =====================================
# ======= GITHUB URL EXTRACTION =======
# =====================================

def read_github_urls_from_responses(jsonl_file="form_responses.jsonl"):
    """
    Read the JSONL file of form responses and extract GitHub repository URLs.
    Returns a list of URLs found in the responses.
    """
    github_urls = []
    try:
        with open(jsonl_file, 'r', encoding='utf-8') as f:
            for line in f:
                try:
                    response = json.loads(line)
                    answers = response.get('answers', {})
                    for _, answer_data in answers.items():
                        answer_value = answer_data.get('textAnswers', {}).get('answers', [])
                        for answer in answer_value:
                            value = answer.get('value', '')
                            if 'github.com' in value.lower():
                                github_urls.append(value)
                                break
                except json.JSONDecodeError:
                    print(f"Warning: Couldn't parse JSON line: {line[:50]}...")
                    continue
                except Exception as e:
                    print(f"Error processing response: {e}")
                    continue
        return github_urls
    except FileNotFoundError:
        print(f"File not found: {jsonl_file}")
        return []


def clone_github_repos(urls, target_dir="cloned_repos"):
    """
    Clone GitHub repositories from a list of URLs using GitPython
    """
    if not os.path.exists(target_dir):
        os.makedirs(target_dir)

    results = []
    for url in urls:
        repo_name = url.rstrip('/').split('/')[-1]
        if repo_name.endswith('.git'):
            repo_name = repo_name[:-4]
        username = url.rstrip('/').split('/')[-2]
        repo_dir = os.path.join(target_dir, f"{username}_{repo_name}")

        if os.path.exists(repo_dir):
            print(f"Repository already exists: {repo_dir}")
            results.append({"url": url, "status": "already_exists", "path": repo_dir})
            continue

        try:
            print(f"Cloning {url} to {repo_dir}...")
            git.Repo.clone_from(url, repo_dir)
            results.append({"url": url, "status": "success", "path": repo_dir})
            print(f"Successfully cloned {url}")
        except git.GitCommandError as e:
            print(f"Failed to clone {url}: {e}")
            results.append({"url": url, "status": "error", "error": str(e)})

    return results


# =====================================
# ========= ASSESSMENT MAPPING ========
# =====================================

def append_assessment_record(assessments_file, record):
    if os.path.exists(assessments_file):
        try:
            with open(assessments_file, 'r', encoding='utf-8') as f:
                all_assessments = json.load(f)
        except json.JSONDecodeError:
            all_assessments = {"assessments": []}
    else:
        all_assessments = {"assessments": []}
    all_assessments["assessments"].append(record)
    with open(assessments_file, 'w', encoding='utf-8') as jf:
        json.dump(all_assessments, jf, indent=2)


def extract_mapping_for_candidate(json_path, candidate_id):
    with open(json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    assessments = data.get("assessments", [])
    for assessment in assessments:
        if assessment.get("candidate_id") == candidate_id:
            return {pdf_q: details.get("csv_id") for pdf_q, details in assessment.get("questions", {}).items()}
    return {}


def load_question_bank():
    """Load all questions and their test cases from CSV"""
    questions = {}
    with open(CSV_PATH, newline='', encoding='utf-8') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            question_id = row["question ID"]
            if question_id not in questions:
                questions[question_id] = {
                    "question": row["question"],
                    "test_cases": []
                }
            input_data = row["input"]
            expected_output = row["expected"]
            questions[question_id]["test_cases"].append((input_data, expected_output))
    return questions


# =====================================
# =========== TEST RUNNER =============
# =====================================

def detect_functions_in_file(py_file):
    """Detect which functions are defined in a Python file"""
    try:
        with open(py_file, 'r', encoding='utf-8') as f:
            content = f.read()
        tree = ast.parse(content)
        functions = [node.name for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)]
        return functions
    except Exception as e:
        print(f"[error] Could not parse {py_file}: {e}")
        return []


def test_function_against_csv(candidate_file, function_name, question_id, test_cases):
    """Test a specific function against its CSV test cases and show failed cases.
    Returns (success, test_details)
    """
    test_details = {
        "total_tests": len(test_cases),
        "passed": 0,
        "failed": 0,
        "failed_cases": []
    }

    try:
        spec = importlib.util.spec_from_file_location("candidate", str(candidate_file))
        candidate_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(candidate_module)
        func = getattr(candidate_module, function_name)

        for input_data, expected_output in test_cases:
            try:
                input_obj = json.loads(input_data)

                # Handle TRUE/FALSE literals in expected output
                if isinstance(expected_output, str) and expected_output.strip().upper() == "TRUE":
                    expected_obj = True
                elif isinstance(expected_output, str) and expected_output.strip().upper() == "FALSE":
                    expected_obj = False
                else:
                    expected_obj = json.loads(expected_output)

                if isinstance(input_obj, dict):
                    result = func(**input_obj)
                elif isinstance(input_obj, (list, tuple)):
                    result = func(*input_obj)
                else:
                    result = func(input_obj)

                if result == expected_obj:
                    test_details["passed"] += 1
                else:
                    test_details["failed"] += 1
                    test_details["failed_cases"].append({
                        "input": input_data,
                        "expected": expected_output,
                        "actual": str(result)
                    })
            except Exception as e:
                test_details["failed"] += 1
                test_details["failed_cases"].append({
                    "input": input_data,
                    "expected": expected_output,
                    "actual": f"Exception: {str(e)}"
                })

        print(f"[info] {Path(candidate_file).name}: {test_details['passed']} passed, {test_details['failed']} failed")
        if test_details["failed_cases"]:
            print(f"[FAILED CASES for {Path(candidate_file).name}]:")
            for case in test_details["failed_cases"]:
                print(f"  Input: {case['input']}")
                print(f"  Expected: {case['expected']}")
                print(f"  Got: {case['actual']}\n")

        return test_details["failed"] == 0, test_details
    except Exception as e:
        print(f"[error] Could not test function '{function_name}' in {candidate_file}: {e}")
        test_details["error"] = str(e)
        return False, test_details


def run_tests_from_mapping(repo_path, mapping, question_bank):
    """
    For each file like Q2.py in the repo, find its mapped CSV ID from the mapping,
    and run the test cases from the question bank using the first function found.
    Returns a report of test results.
    """
    repo_path = pathlib.Path(repo_path)
    py_files = [f for f in repo_path.glob("Q*.py")]
    results = {
        "total_files": len(py_files),
        "files_tested": 0,
        "files_passed": 0,
        "files_failed": 0,
        "questions": {}
    }

    for py_file in py_files:
        pdf_q = py_file.stem  # e.g., "Q2"
        csv_id = mapping.get(pdf_q)
        if not csv_id:
            print(f"[skip] No CSV ID mapping for {pdf_q}")
            results["questions"][pdf_q] = {
                "status": "skipped",
                "reason": "No CSV ID mapping found"
            }
            continue
        if csv_id not in question_bank:
            print(f"[skip] No test cases for CSV ID {csv_id}")
            results["questions"][pdf_q] = {
                "status": "skipped",
                "reason": "No test cases found"
            }
            continue

        results["files_tested"] += 1
        print(f"[info] Testing {py_file.name} mapped to CSV ID {csv_id}")
        functions = detect_functions_in_file(py_file)
        if not functions:
            print(f"[warning] No functions found in {py_file.name}")
            results["questions"][pdf_q] = {
                "status": "error",
                "reason": "No functions found in file",
                "csv_id": csv_id
            }
            continue

        function_name = functions[0]  # Use the first function found
        test_cases = question_bank[csv_id]["test_cases"]
        success, test_details = test_function_against_csv(py_file, function_name, csv_id, test_cases)
        status = "✅ PASSED" if success else "❌ FAILED"
        print(f"{pdf_q} ({csv_id}): {status}")

        if success:
            results["files_passed"] += 1
        else:
            results["files_failed"] += 1

        results["questions"][pdf_q] = {
            "status": "passed" if success else "failed",
            "csv_id": csv_id,
            "function_name": function_name,
            "test_details": test_details
        }

    return results


# =====================================
# =============== MAIN ================
# =====================================

if __name__ == "__main__":
    # ---------- STEP 1: Email assessment ONLY to top 3 by resume_score ----------
    print("Selecting top 3 candidates by resume_score...")
    top_candidates = get_top_candidates()
    if not top_candidates:
        print("No candidates found with valid emails. Exiting.")
        sys.exit(0)

    # Load all questions once
    QUESTIONS = load_dsa_questions()
    # Build Gmail service once
    gmail_service = get_gmail_service()

    sent_count = 0
    for cand in top_candidates:
        candidate_id = cand["candidate_id"]
        recipient = cand["email_address"]

        # Pick 4–5 questions and generate PDF
        picked = pick_random_questions(QUESTIONS, min_q=4, max_q=5)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        pdf_path = save_pdf(
            picked,
            title="DSA Assessment",
            out_path=f"dsa_quiz_{candidate_id}_{stamp}.pdf",
            candidate_id=candidate_id
        )

        # Build mapping (PDF Q# -> CSV question ID & text) for logging
        with open(CSV_PATH, newline='', encoding='utf-8') as csvfile:
            reader = csv.DictReader(csvfile)
            q_to_id = {row["question"]: row["question ID"] for row in reader}

        picked_mapping = {}
        for idx, q in enumerate(picked, 1):
            picked_mapping[f"Q{idx}"] = {
                "csv_id": q_to_id.get(q, ""),
                "text": q
            }

        # Append to assessments log
        candidate_info = {
            "candidate_id": candidate_id,
            "email": recipient,
            "timestamp": stamp,
            "questions": picked_mapping,
            "pdf_path": pdf_path
        }
        append_assessment_record(ASSESSMENTS_FILE, candidate_info)

        # Send email with attachment (to this candidate only)
        msg = create_message_with_attachment(
            SENDER, recipient, SUBJECT, BODY_TEMPLATE, pdf_path
        )
        try:
            sent = gmail_service.users().messages().send(userId="me", body=msg).execute()
            print(f"✅ Sent to {recipient} (msg id: {sent.get('id')})")
            sent_count += 1
        except Exception as e:
            print(f"❌ Failed to send to {recipient}: {e}")

    print(f"\nEmails successfully sent: {sent_count}/{len(top_candidates)}")

    # ---------- STEP 2: Pull Google Form responses and save as JSONL ----------
    print("\nFetching Google Form responses...")
    responses = list_all_responses(FORM_ID)
    print(f"Fetched {len(responses)} responses")

    with open("form_responses.jsonl", "w", encoding="utf-8") as f:
        for r in responses:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print("Saved form responses to form_responses.jsonl")

    # ---------- STEP 3: Extract GitHub URLs and clone repos ----------
    print("\nExtracting GitHub URLs from responses...")
    github_urls = read_github_urls_from_responses("form_responses.jsonl")
    print(f"Found {len(github_urls)} GitHub URLs:")
    for url in github_urls:
        print(f"- {url}")

    if github_urls:
        print("\nCloning repositories...")
        clone_results = clone_github_repos(github_urls, target_dir=CLONED_REPOS_DIR)
        for result in clone_results:
            if result["status"] == "success":
                print(f"✅ {result['url']} -> {result['path']}")
            elif result["status"] == "already_exists":
                print(f"⚠️ {result['url']} -> {result['path']} (already exists)")
            else:
                print(f"❌ {result['url']} -> {result.get('error','error')}")
    else:
        print("No GitHub URLs found to clone.")

    # ---------- STEP 4: Auto-test submissions against CSV test cases ----------
    print("\nRunning automated tests against submissions...")

    question_bank = load_question_bank()
    repo_dir = pathlib.Path(CLONED_REPOS_DIR)
    candidate_repos = [d for d in repo_dir.iterdir() if d.is_dir() and not d.name.startswith('.')]
    if not candidate_repos:
        print(f"[error] No candidate repos found in {CLONED_REPOS_DIR}")
        sys.exit(0)

    overall_results = {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "total_candidates": len(candidate_repos),
        "candidates": {}
    }

    # Path to the same assessments log we appended earlier
    json_path = Path(ASSESSMENTS_FILE)

    for candidate_repo in candidate_repos:
        repo_name = candidate_repo.name

        # Extract candidate_id from repo name (expects "...cand_xxxxx..." pattern)
        if "cand_" in repo_name:
            start_idx = repo_name.find("cand_")
            end_idx = repo_name.find("_", start_idx + 5)
            candidate_id = repo_name[start_idx:] if end_idx == -1 else repo_name[start_idx:end_idx]
        else:
            print(f"[error] Could not extract candidate_id from repo name {repo_name}")
            continue

        print(f"\n{'='*60}\nTesting repo: {repo_name}\n{'='*60}")
        print(f"[info] Using candidate ID: {candidate_id}")

        # Read mapping from assessments JSON for this candidate
        if not json_path.exists():
            print(f"[error] Assessments file not found: {json_path}")
            continue

        mapping = extract_mapping_for_candidate(str(json_path), candidate_id)
        if not mapping:
            print(f"[error] No assessment mapping found for candidate ID {candidate_id}")
            overall_results["candidates"][repo_name] = {
                "candidate_id": candidate_id,
                "status": "error",
                "reason": "No assessment mapping found"
            }
            continue

        # Run tests and collect results
        candidate_results = run_tests_from_mapping(candidate_repo, mapping, question_bank)
        overall_results["candidates"][repo_name] = {
            "candidate_id": candidate_id,
            "status": "completed",
            "results": candidate_results
        }

    # Save test results
    results_path = Path(CLONED_REPOS_DIR).parent / "test_results.json"
    # Load previous results (if any) to know what we've already tested
    previous_shas = {}
    if results_path.exists():
        try:
            with open(results_path, "r", encoding="utf-8") as f:
                prev = json.load(f)
            prev_candidates = prev.get("candidates", {})
            for repo_name, data in prev_candidates.items():
                sha = data.get("commit_sha")
                if sha:
                    previous_shas[repo_name] = sha
        except Exception:
            previous_shas = {}
   

    print(f"\n{'='*60}")
    print(f"All tests completed. Results saved to {results_path}")
    print(f"{'='*60}")
