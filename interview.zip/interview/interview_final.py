from email.mime import message
import io
import torch
import torchaudio
import sounddevice as sd
import numpy as np
from  transformers import WhisperProcessor, WhisperForConditionalGeneration,pipeline,AutoProcessor, AutoModelForTextToSpectrogram
import sys
import warnings
import time
import requests
import json
import edge_tts
import asyncio
from pydub import AudioSegment
from pydub.playback import play
from silero_vad import collect_chunks
from threading import Thread, Event
import math
from playsound import playsound
import os
import uuid
import pdfplumber
import re
import faiss
from sentence_transformers import SentenceTransformer

# --- PDF & FAISS Setup ---
pdf_path = "interview-english1.pdf"
index_path = "faiss_index.bin"
json_path = "questions1_.json"
model_name = "paraphrase-multilingual-MiniLM-L12-v2"
# --- Interview Prompts ---
interview_prompt_ur = """
You are a technical interviewer conducting interview in URDU. Your role is to assess the candidate's knowledge in various technical topics for the position of associate Data Scientist.

Interview Flow:
1) Start with a warm greeting in Urdu
2) Ask 2-3 questions about the candidate's background, education, projects and experience
3) For each topic, you must ask at least 3 questions (ideally 4).
4) Do not move to the next topic until at least 3 questions have been asked and answered.
5) Ask 3–4 questions about TOPIC 1 : Machine Learning
6) Then shift to TOPIC 2 : Deep Learning and ask 3–4 questions
7) Next, move to TOPIC 3 : NLP and ask 3–4 questions
8) Finally, cover TOPIC 4 : Computer Vision with 3–4 questions
9) After all topics, end the interview politely

** IMPORTANT **
STYLE RULES:
- Respond ONLY in **Urdu script**. Never use English words or phrases or any other language.
- ALWAYS ask only one question at a time. NEVER combine two questions in a single message.
- When user asks to repeat, do so politely and clearly in Urdu
- When you do not understand user response, ask them to clarify politely in Urdu
- Do NOT assume candidate experience or add context not present in the question.
- Do NOT use "have you ever heard of", "can you tell us".
- Make questions sound professional and conversational
- Show explicit topic transitions like "Now let's move to the next topic, Deep Learning."
- Do not show your thinking process
- Keep each question brief (2–3 sentences max)
- Stay strictly on interview topics and follow the topic order above
- If the candidate says they don't know the answer, then ask a different but related question from the same topic before moving on.
"""


interview_prompt_en = """
You are a technical interviewer. Your role is to assess the candidate's knowledge in various technical topics for the position of associate Data Scientist.

Interview Flow:
1) Start with a warm greeting in English
2) Ask 2-3 questions about the candidate’s background, education,projects and experience
3) For each technical topic, ONLY ask questions from the provided document. Do not invent or paraphrase new questions.
4) Ask 2–3 questions about TOPIC 1 : Machine Learning
5) Then shift to TOPIC 2 : Deep Learning and ask 2–3 questions
6) Next, move to TOPIC 3 : NLP and ask 2–3 questions
7) Finally, cover TOPIC 4 : Computer Vision with 2–3 questions
8) After all topics, end the interview politely

STYLE RULES:
- Stay strictly on interview topics and follow the topic order above
- ALWAYS ask 2-3 questions for each topic before moving to the next topic.
- Do NOT tell the answer or explain concepts
- Keep it conversational and natural
- Try to ask follow-up questions based on the candidate's answers
- Do not show your thinking process
- Keep each question brief (2–3 sentences max)
- Use natural, clear English only
- If the candidate says they don't know the answer, then ask a different but related question from the same topic before moving on.
"""

os.makedirs("interviews", exist_ok=True)

def start_new_interview(language):
    interview_ID = str(uuid.uuid4())
    filename = f"interviews/conversation_{interview_ID}.json"
    data = {
        "interview_id": interview_ID,
        "language": language,
        "start_time": time.strftime("%Y-%m-%d %H:%M:%S"),
        "conversations": []
    }
    with open(filename, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    return filename

def save_conversation_to_json(question, answer, filename):
    """Save AI question and user answer to JSON file"""
    try:
        if os.path.exists(filename):
            with open(filename, 'r', encoding='utf-8') as f:
                data = json.load(f)
        else:
            data = {"conversations": []}
        
        data["conversations"].append({
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "ai_question": question,
            "user_answer": answer
        })
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
            
    except Exception as e:
        print(f"Error saving conversation: {e}")
        

def play_greeting(greeting_file):
    sound = AudioSegment.from_mp3(greeting_file)
    play(sound)

def transcribe_greeting():
    greeting_audio = AudioSegment.from_mp3(greeting_file)
    greeting_audio = greeting_audio.set_frame_rate(SAMPLE_RATE).set_channels(1)
    greeting_array = np.array(greeting_audio.get_array_of_samples(), dtype=np.float32) / 32768.0
    return transcribe(greeting_array)

def is_topic_heading(line: str) -> bool:
    topics = ["TOPIC 1 : Machine Learning", "TOPIC 2 : Deep Learning", "TOPIC 3 : NLP", "TOPIC 4: Computer Vision"]
    return line.strip() in topics

def is_question(line: str) -> bool:
    return re.match(r'^(\d+\.|\.?\d+)', line) is not None

def parse_pdf(pdf_path):
    with pdfplumber.open(pdf_path) as pdf:
        text = "\n".join(page.extract_text() for page in pdf.pages if page.extract_text())
    lines = [line.strip() for line in text.split("\n") if line.strip()]
    topics = {}
    current_topic = None
    for line in lines:
        if is_topic_heading(line):
            current_topic = line.strip()
            topics[current_topic] = []
        elif is_question(line) and current_topic:
            topics[current_topic].append(line.strip())
    return topics

def save_index_and_metadata(index, metadata, index_path, json_path):
    faiss.write_index(index, index_path)
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(metadata, f, ensure_ascii=False, indent=4)
    print(f"💾 Saved FAISS index -> {index_path}, metadata -> {json_path}")

def load_index_and_metadata(index_path, json_path):
    index = faiss.read_index(index_path)
    with open(json_path, "r", encoding="utf-8") as f:
        metadata = json.load(f)
    return index, metadata

def build_faiss_index_with_metadata(topics_dict, model_name=model_name):
    embedding_model = SentenceTransformer(model_name)
    all_questions = []
    metadata = []
    for topic, questions in topics_dict.items():
        for q in questions:
            all_questions.append(q)
            metadata.append({"topic": topic, "question": q})
    embeddings = embedding_model.encode(all_questions, convert_to_numpy=True)
    faiss.normalize_L2(embeddings)
    dim = embeddings.shape[1]
    index = faiss.IndexFlatIP(dim)
    index.add(embeddings)
    return index, embedding_model, metadata

def query_faiss(query, embedding_model, index, metadata, top_n=3):
    q_emb = embedding_model.encode([query], convert_to_numpy=True)
    faiss.normalize_L2(q_emb)
    D, I = index.search(q_emb, top_n)
    results = [(metadata[i]["question"], float(D[0][k])) for k, i in enumerate(I[0])]
    return results



processor = WhisperProcessor.from_pretrained("openai/whisper-small",device="cpu")
whisper_model = WhisperForConditionalGeneration.from_pretrained("openai/whisper-small")

vad_model, utils = torch.hub.load(
    repo_or_dir='snakers4/silero-vad',
    model='silero_vad',
    trust_repo=True,
    source='github',
    force_reload=False
)

(get_speech_timestamps, save_audio, read_audio, VADIterator, collect_chunks) = utils

SAMPLE_RATE = 16000
FRAME_DURATION = 0.032                  # 32 ms frames = 512 samples for VAD
FRAME_SIZE = int(SAMPLE_RATE * FRAME_DURATION)

# 🎯 Headphone-friendly sensitivity
RMS_THRESHOLD = 0.4 # Very low → detects even a whisper
VAD_THRESHOLD = 0.9                  # Very low VAD → catches short bursts

SILENCE_DURATION = 1.5                   # Slightly shorter wait before AI responds
INTERRUPTION_THRESHOLD = 0.2             # Lower → faster interruption trigger
MIN_SPEECH_DURATION = 0.3                # Short → quick interrupt allowed

CONVERSATION_TIMEOUT = 30.0              # No change

# 🎯 AI playback leakage rejection
AI_RMS_THRESHOLD = 0.0005                 # From playback analysis (unchanged base)
RMS_SAFETY_MARGIN = 0.01       # Safety buffer to avoid false AI detection



def compute_rms(chunk):
    return np.sqrt(np.mean(chunk ** 2))


def detect_speech_in_frame(frame):
    """Enhanced speech detection using both RMS and VAD - frame-based"""
    rms = compute_rms(frame)
    
    # Ensure frame is exactly 512 samples for VAD
    if len(frame) != 512:
        # Pad or trim to exactly 512 samples
        if len(frame) < 512:
            frame = np.pad(frame, (0, 512 - len(frame)), 'constant')
        else:
            frame = frame[:512]
    
    try:
        vad_prob = vad_model(torch.tensor(frame).unsqueeze(0),
         sr=SAMPLE_RATE).item()
        return rms > RMS_THRESHOLD or vad_prob > VAD_THRESHOLD
    except Exception as e:
        # Fallback to RMS only if VAD fails
        print(f"VAD error: {e}, using RMS only")
        return rms > RMS_THRESHOLD

def detect_speech_with_ai_rejection(frame, ai_speaking=False, ai_threshold=None):
    """
    Speech detection tuned for headphone use + AI playback leakage rejection.
    - Highly sensitive when AI is silent.
    - Rejects AI playback leakage using RMS threshold from actual AI audio.
    """
    # ✅ Headphone-friendly sensitivity
    dynamic_rms_threshold = 0.001      # Very sensitive for quiet speech
    dynamic_vad_threshold = 0.0003     # Very sensitive VAD

    rms = compute_rms(frame)
    #print(f"[AI Rejection] Frame RMS: {rms:.6f}") 

    # Pad/trim to exactly 512 samples for VAD
    vad_frame = frame.copy()
    if len(vad_frame) != 512:
        if len(vad_frame) < 512:
            vad_frame = np.pad(vad_frame, (0, 512 - len(vad_frame)), 'constant')
        else:
            vad_frame = vad_frame[:512]

    try:
        vad_prob = vad_model(torch.tensor(vad_frame).unsqueeze(0), sr=SAMPLE_RATE).item()
    except Exception as e:
        print(f"VAD error: {e}, using RMS only")
        vad_prob = 0.0

    # ✅ If AI is speaking, reject anything that matches AI playback loudness
    if ai_speaking and ai_threshold is not None:
        if rms <= ai_threshold*0.5:
            # Too similar/quiet compared to AI playback — ignore
            return False

    # ✅ Sensitive detection: OR logic between RMS and VAD
    rms_detection = rms > dynamic_rms_threshold
    vad_detection = vad_prob > dynamic_vad_threshold

    return rms_detection or vad_detection

    
    
def continuous_speech_listener(pre_buffered_audio=None):
    """
    Frame-based speech listener that processes audio in 512-sample frames.
    If pre_buffered_audio is provided, it is prepended to the recorded audio.
    Returns: (audio_data, interrupted_flag)
    """
    audio_buffer = []
    silence_frames = 0
    speech_detected = False
    speech_start_time = None
    last_speech_time = None

    # If pre-buffered audio exists, convert to frames and add to buffer
    if pre_buffered_audio is not None and len(pre_buffered_audio) > 0:
        print("🔄 Converting buffered audio to frames...")
        # Convert buffered audio to frames
        for i in range(0, len(pre_buffered_audio), FRAME_SIZE):
            frame = pre_buffered_audio[i:i+FRAME_SIZE]
            if len(frame) == FRAME_SIZE:  # Only add complete frames
                audio_buffer.append(frame)
        speech_detected = len(audio_buffer) > 0
        speech_start_time = time.time()
        last_speech_time = speech_start_time

    # Create microphone input stream with correct frame size
    stream = sd.InputStream(
        samplerate=SAMPLE_RATE,
        channels=1,
        dtype='float32',
        blocksize=FRAME_SIZE  # 512 samples
    )

    max_silence_frames = int(SILENCE_DURATION / FRAME_DURATION)  # ~62 frames
    min_speech_frames = int(MIN_SPEECH_DURATION / FRAME_DURATION)  # ~31 frames
    speech_frame_count = len(audio_buffer)

    try:
        with stream:
            while True:
                # ✅ Read exactly one frame (512 samples)
                frame, _ = stream.read(FRAME_SIZE)
                frame = frame.flatten()
                frame_rms = compute_rms(frame)
                #print(f"[Listener] Frame RMS: {frame_rms:.6f}")
                has_speech = detect_speech_in_frame(frame)
                current_time = time.time()

                if has_speech:
                    if not speech_detected:
                        speech_detected = True
                        speech_start_time = current_time
                        print("🎤 Speech started")
                    
                    audio_buffer.append(frame)
                    speech_frame_count += 1
                    silence_frames = 0
                    last_speech_time = current_time
                    
                else:
                    if speech_detected:
                        audio_buffer.append(frame)
                        silence_frames += 1
                        
                        # ✅ Check if silence duration exceeded (frame-based)
                        if silence_frames >= max_silence_frames:
                            if speech_frame_count >= min_speech_frames:
                                total_duration = len(np.concatenate(audio_buffer)) / SAMPLE_RATE
                                print(f"✅ Recording complete: {total_duration:.1f}s ({speech_frame_count} speech frames)")
                                break
                            else:
                                # Reset recording if speech was too short
                                print(f"❌ Speech too short ({speech_frame_count} frames), resetting...")
                                if pre_buffered_audio is not None:
                                    # Keep original buffered audio
                                    audio_buffer = []
                                    for i in range(0, len(pre_buffered_audio), FRAME_SIZE):
                                        frame = pre_buffered_audio[i:i+FRAME_SIZE]
                                        if len(frame) == FRAME_SIZE:
                                            audio_buffer.append(frame)
                                    speech_frame_count = len(audio_buffer)
                                else:
                                    audio_buffer = []
                                    speech_frame_count = 0
                                silence_frames = 0
                                speech_detected = len(audio_buffer) > 0

    except KeyboardInterrupt:
        print("\nInterrupted by user.")
        return None, True

    if audio_buffer and speech_detected:
        full_audio = np.concatenate(audio_buffer)
        return full_audio, False
    else:
        print("No valid speech detected.")
        return None, False

def calculate_ai_playback_threshold(audio_file, multiplier=1.2, silence_rms_cutoff=0.001):
    """
    Calculate RMS threshold for AI playback rejection:
    - Ignores silent parts of AI playback.
    - Uses only loud segments to set an accurate cutoff.
    - Adds a small multiplier for safety.
    """
    try:
        audio = AudioSegment.from_file(audio_file)
        raw_audio = audio.raw_data
        sample_rate = audio.frame_rate
        channels = audio.channels

        # Convert to float32 [-1.0, 1.0]
        audio_np = np.frombuffer(raw_audio, dtype=np.int16).astype(np.float32) / 32768.0
        if channels > 1:
            audio_np = audio_np.reshape(-1, channels).mean(axis=1)  # Mono mixdown

        # Compute RMS in short frames
        frame_size = int(sample_rate * 0.032)  # 32 ms frames
        frame_rms_values = []
        for i in range(0, len(audio_np), frame_size):
            frame = audio_np[i:i + frame_size]
            if len(frame) < frame_size:
                continue
            rms = np.sqrt(np.mean(frame ** 2))
            if rms > silence_rms_cutoff:  # Ignore near-silent frames
                frame_rms_values.append(rms)

        if not frame_rms_values:
            print("⚠️ No loud frames found in AI playback.")
            return None

        # Use median loudness to avoid spikes
        median_rms = float(np.median(frame_rms_values))
        playback_threshold = median_rms * multiplier

        print(f"🎚️ AI Playback median RMS: {median_rms:.6f} → Detection Threshold: {playback_threshold:.6f}")
        return playback_threshold

    except Exception as e:
        print(f"Error calculating playback threshold: {e}")
        return None


#transcribe function to convert speech to text
def transcribe(audio_array):
    inputs = processor(
        audio_array,
        sampling_rate=SAMPLE_RATE,
        return_tensors="pt",
        return_attention_mask=True
    )

    input_features = inputs.input_features
    attention_mask = inputs.attention_mask

    try:
        predicted_ids = whisper_model.generate(
            input_features,
            attention_mask=attention_mask,
            task="transcribe",
            language="en"
        )
    except:
        # Fallback for older versions
        forced_decoder_ids = processor.get_decoder_prompt_ids(language="en", task="transcribe")
        predicted_ids = whisper_model.generate(
            input_features,
            attention_mask=attention_mask,
            forced_decoder_ids=forced_decoder_ids
        )

    transcription = processor.batch_decode(predicted_ids, skip_special_tokens=True)[0]
    return transcription

#transcribed text is sent to ollama/gemma for response


GROQ_API_KEY = "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"  # 
GROQ_MODEL = "llama-3.3-70b-versatile"  # ✅ You can also use: "gemma-7b-it", "mixtral-8x7b-32768", etc.

def query_groq(user_input, context="", max_tokens=512, temperature=0.1, conversation_history=None):
    try:
        url = "https://api.groq.com/openai/v1/chat/completions"

        if isinstance(user_input, list):
            user_input = " ".join(user_input)   # or pick the last element: user_input[-1]
        elif not isinstance(user_input, str):
            user_input = str(user_input)

        goodbye_words = ["khuda hafiz", "bye", "goodbye", "khudahafiz", "alvida"]
        user_said_goodbye = any(phrase in user_input.lower() for phrase in goodbye_words)

        tools = [
            {
                "type": "function",
                "function": {
                    "name": "end_conversation",
                    "description": (
                        "ONLY call this function if the user's message contains EXACTLY these goodbye words: "
                        "'khuda hafiz', 'bye', 'goodbye', or 'alvida'. Do NOT call this for greetings or conversation."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {},
                        "required": []
                    }
                }
            }
        ]

        if conversation_history is None:
            conversation_history = [{"role": "system", "content": interview_prompt}]

        conversation_history.append({
            "role": "user",
            "content": f"""
Candidate answer: "{user_input}"

Relevant interview questions from knowledge base:
{context}

Keep it conversational. It should look like a natural conversation, not a scripted interview. Follow the instruction and flow.
"""
        })

        payload = {
            "model": GROQ_MODEL,
            "messages": conversation_history,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "stream": False,
        }

        headers = {"Authorization": f"Bearer {GROQ_API_KEY}", "Content-Type": "application/json"}
        response = requests.post(url, headers=headers, json=payload)

        if response.status_code == 200:
            result = response.json()
            choice = result["choices"][0]["message"]["content"]
            conversation_history.append({"role": "assistant", "content": choice})
            return choice.strip(), conversation_history
        else:
            print(f"Error calling Groq API: {response.status_code}")
            print(response.text)
            return "Sorry, I'm having trouble processing your answer right now.", conversation_history

    except Exception as e:
        print(f"Exception in query_groq: {str(e)}")
        return "Sorry, there was an error processing your answer.", conversation_history

async def text_to_speech(response_text: str) -> str:
    """
    Generate TTS audio using edge-tts and return the MP3 filepath.
    Async-safe: must be awaited from async code.
    """
    output_path = f"ai_response_{uuid.uuid4().hex}.mp3"
    selected_voice = voice if 'voice' in globals() else "ur-PK-UzmaNeural"
    communicate = edge_tts.Communicate(text=response_text, voice=selected_voice)
    await communicate.save(output_path)
    return output_path

# def text_to_speech(response_text):
#     try:
#         #print(f"Generating speech for: {response_text}")
#         output_path = "ai_response.mp3"

#         selected_voice = voice if 'voice' in globals() else "ur-PK-UzmaNeural"

#         async def run():
#             communicate = edge_tts.Communicate(text=response_text, voice=selected_voice)
#             await communicate.save(output_path)
#             #print(f"Audio saved to: {output_path}")

#         asyncio.run(run())

#         return output_path

#     except Exception as e:
#         print(f"Error in TTS: {e}")
#         return None

def end_conversation():
    print("Khuda Hafiz! Aap se baat karke acha laga.")
    sys.exit(0)

class NaturalConversationManager:
    def __init__(self):
        self.is_speaking = False
        self.stop_speaking = Event()
        self.user_interrupted = False
        self.interruption_audio = None
        self.realtime_audio_buffer = []  

    def store_interruption_audio(self, audio_chunk):
        """Store interrupted user speech detected during playback"""
        if self.interruption_audio is None:
            self.interruption_audio = audio_chunk
        else:
            self.interruption_audio = np.concatenate([self.interruption_audio, audio_chunk])

    def get_interruption_audio(self):
        if self.interruption_audio is not None and len(self.interruption_audio) > 0:
            return self.interruption_audio
        return None

    def clear_interruption_buffer(self):
        self.interruption_audio = None

    def play_response_with_interruption(self, audio_file):
        """Play AI speech while monitoring for user interruption with echo rejection"""
        self.current_ai_rms_threshold = calculate_ai_playback_threshold(audio_file, multiplier=1.5)

        self.is_speaking = True
        self.stop_speaking.clear()
        self.user_interrupted = False
        self.realtime_audio_buffer = []
        self.playback_start_time = time.time()  # Track when playback started

        playback_thread = Thread(target=self._play_audio_chunks, args=(audio_file,))
        monitor_thread = Thread(target=self._monitor_interruption)

        print("Starting AI response with echo rejection...")
        playback_thread.start()
        monitor_thread.start()

        playback_thread.join()
        self.is_speaking = False
        monitor_thread.join(timeout=1.0)

        return self.user_interrupted

    def _play_audio_chunks(self, audio_file):
        """Plays AI speech in chunks while allowing interruption"""
        try:
            audio = AudioSegment.from_file(audio_file)
            raw_audio = audio.raw_data
            sample_rate = audio.frame_rate
            channels = audio.channels

            audio_np = np.frombuffer(raw_audio, dtype=np.int16).astype(np.float32) / 32768.0
            audio_np = audio_np.reshape(-1, channels if channels == 2 else 1)

            print("AI speaking...")
            chunk_size = int(sample_rate * 0.1)

            stream = sd.OutputStream(samplerate=sample_rate, channels=channels, dtype=np.float32,
                                     blocksize=chunk_size * 2, latency='high')
            stream.start()

            playback_interrupted = False

            for i in range(0, len(audio_np), chunk_size):
                if self.stop_speaking.is_set():
                    playback_interrupted = True
                    break

                chunk = audio_np[i:i + chunk_size]
                if len(chunk) < chunk_size:
                    chunk = np.vstack([chunk, np.zeros((chunk_size - len(chunk), channels), dtype=np.float32)])

                stream.write(chunk)
                time.sleep(0.005)

            stream.stop()
            stream.close()

            if not playback_interrupted:
                print("AI finished speaking completely")
                self.user_interrupted = False  

        except Exception as e:
            print(f"Error playing audio: {e}")

        finally:
            if not self.user_interrupted:  # ✅ Only clear when no interruption
                self.stop_speaking.clear()

    def _monitor_interruption(self):
        """Detect user speech during AI playback using frame-based processing with echo rejection"""
        stream = sd.InputStream(samplerate=SAMPLE_RATE, channels=1, dtype='float32', blocksize=FRAME_SIZE)
        consecutive_speech_frames = 0
        required_speech_frames = 2  # ✅ Reduced from 5 to 2 for faster detection
        max_buffer_frames = int(5.0 / FRAME_DURATION)  # 5 seconds of frames
        
        # ✅ Reduced stabilization delay
        stabilization_delay = 0.2  # 200ms delay (reduced from 500ms)

        try:
            with stream:
                while self.is_speaking and not self.stop_speaking.is_set():
                    frame, _ = stream.read(FRAME_SIZE)
                    frame = frame.flatten()
                    
                    if hasattr(self, 'playback_start_time') and time.time() - self.playback_start_time < stabilization_delay:
                        continue

                    # ✅ Store frames in buffer (limit to 5 seconds)
                    self.realtime_audio_buffer.append(frame)
                    if len(self.realtime_audio_buffer) > max_buffer_frames:
                        self.realtime_audio_buffer = self.realtime_audio_buffer[-max_buffer_frames:]

                    # ✅ Use basic speech detection first for debugging
                    frame_rms = compute_rms(frame)
                    #print(f"[Monitor] Frame RMS: {frame_rms:.6f}")
                    basic_speech = frame_rms > RMS_THRESHOLD
                    
                    # ✅ Use enhanced speech detection with AI rejection
                    has_speech = detect_speech_with_ai_rejection(
                        frame, 
                        ai_speaking=True, 
                        ai_threshold=self.current_ai_rms_threshold
                    )
                    
                    # ✅ Debug output
                    if  has_speech:
                        print(f"🎙️ Audio detected - RMS: {frame_rms:.4f}, Basic: {basic_speech}, Enhanced: {has_speech}")

                    if has_speech:
                        consecutive_speech_frames += 1
                        print(f"🔊 Potential user speech: {consecutive_speech_frames}/{required_speech_frames}")
                        
                        if consecutive_speech_frames >= required_speech_frames:
                            # ✅ Simplified verification - just check if speech is strong enough
                            ai_threshold = getattr(self, 'current_ai_rms_threshold', None)
                            
                            # ✅ More lenient threshold check
                            # if not ai_threshold or frame_rms > ai_threshold * 1.1:  # Only 1.1x stronger needed
                            #     print("✅ User speech detected → marking interruption")
                            #     # ✅ Store all buffered frames as interruption audio
                            #     self.interruption_audio = np.concatenate(self.realtime_audio_buffer)
                            #     self.user_interrupted = True
                            #     self.stop_speaking.set()
                            #     break
                            # else:
                            #     print(f"❌ Speech too weak (RMS: {frame_rms:.4f} vs AI: {ai_threshold:.4f})")
                            #     consecutive_speech_frames = max(0, consecutive_speech_frames - 1)  # Reduce counter slightly
                            if not ai_threshold or frame_rms > ai_threshold * 0.5:  # 50% of AI loudness
                                print("✅ User speech detected → marking interruption")
                                self.interruption_audio = np.concatenate(self.realtime_audio_buffer)
                                self.user_interrupted = True
                                self.stop_speaking.set()
                                break
                            else:
                                print(f"❌ Speech too weak (RMS: {frame_rms:.4f} vs AI: {ai_threshold:.4f})")
                                consecutive_speech_frames = max(0, consecutive_speech_frames - 1)
                    else:
                        consecutive_speech_frames = 0
                        
        except Exception as e:
            print(f"Monitoring error: {e}")
    
    




if __name__ == "__main__":

    print("\nPress Ctrl+C to exit\n")
    
    # Language selection
    print("Enter the language of the interview (Press 1 for English, 2 for Urdu):")
    language_choice = input().strip()
    if language_choice == "1":
        interview_prompt = interview_prompt_en
        voice = "en-US-SteffanNeural"
        greeting_file = "greeting_english.mp3" 
         # English voice
    elif language_choice == "2":
        interview_prompt = interview_prompt_ur
        voice = "ur-PK-UzmaNeural"     # Urdu voice
        greeting_file = "greetings.mp3"
    else:
        print("Invalid choice. Defaulting to English.")
        interview_prompt = interview_prompt_en
        greeting_file = "greeting_english.mp3"
        voice = "en-US-SteffanNeural"

        # --- Initialize PDF/FAISS once at startup ---
    topics_dict = parse_pdf(pdf_path)
    index, embedding_model, metadata = build_faiss_index_with_metadata(topics_dict)
    save_index_and_metadata(index, metadata, index_path, json_path)

   #last_answer = "Let's start the interview."
    conversation_filename = start_new_interview(language_choice)
    conversation_manager = NaturalConversationManager()
    previous_ai_question = None  # Track the previous AI question
    conversation_context = []  # Store last 2 question-answer pairs

    # Initial greeting
    print("AI: Starting conversation...")
    
    # Store initial greeting (transcribe the greeting file)
    try:
        play_thread = Thread(target=play_greeting, args=(greeting_file,))
        play_thread.start()
        greeting_text = transcribe_greeting()
        play_thread.join()
        last_answer = greeting_text  # Use the transcribed greeting as the initial FAISS query
        #print(f"Greeting transcribed: {greeting_text}")
        conversation_history = [{"role": "system", "content": interview_prompt},
                                {"role": "assistant", "content": greeting_text}
                                ]

        previous_ai_question = greeting_text  # Set the greeting as the first question
    except Exception as e:
        greeting_text = "Assalam alaikum! Main aap ka interviewer hun. Kya aap tayar hain?"
        print(f"Using default greeting text due to error: {e}")
        previous_ai_question = greeting_text
    
  # Ensure audio is processed
    while True:
        try:
            buffered_audio = conversation_manager.get_interruption_audio()
            if buffered_audio is not None and len(buffered_audio) > 0:
                print("Continuing from previous interruption with buffered audio...")
                user_audio, _ = continuous_speech_listener(buffered_audio)
                conversation_manager.clear_interruption_buffer()
            else:
                user_audio, interrupted = continuous_speech_listener()

            if user_audio is not None and len(user_audio) > 0:
                print("Processing speech...")
                user_text = transcribe(user_audio)
                print(f"You: {user_text}")

                if not user_text.strip() or len(user_text.strip()) < 3:
                    print("Didn't catch that. Please speak again.")
                    continue

                # Save the previous AI question with current user answer
                if previous_ai_question:
                    save_conversation_to_json(previous_ai_question, user_text, conversation_filename)

                    # Add to context (keep only last 2 QA pairs)
                    conversation_context.append((previous_ai_question, user_text))
                    if len(conversation_context) > 2:
                        conversation_context = conversation_context[-2:]  # Keep only last 2

                # Pass context to AI
                #ai_response = query_groq(user_text, conversation_context)
                similar_qs = query_faiss(user_text, embedding_model, index, metadata, top_n=5)
                #print(f"FAISS suggestions: {similar_qs}")
                context = "\n".join([f"- {q[0]}" for q in similar_qs])
                ai_response, conversation_history = query_groq(
                user_text,
                context,
                conversation_history=conversation_history
            )

                print(f"AI: {ai_response}")
                
                # Update the previous AI question for next iteration
                previous_ai_question = ai_response

                if ai_response:
                    print("Generating speech...")
                    audio_file = text_to_speech(ai_response)

                    if audio_file:
                        was_interrupted = conversation_manager.play_response_with_interruption(audio_file)

                        if was_interrupted:
                            #print("\nUser interrupted. Processing captured speech...")
                            buffered_audio = conversation_manager.interruption_audio

                            if buffered_audio is not None and buffered_audio.size > 0:
                                continuation_audio, _ = continuous_speech_listener(buffered_audio)

                                if continuation_audio is not None and len(continuation_audio) > 0:
                                    interrupted_text = transcribe(continuation_audio)
                                    print(f"User: {interrupted_text}")

                                    if interrupted_text.strip():
                                        # Save the interrupted response with the previous AI question
                                        if previous_ai_question:
                                            save_conversation_to_json(previous_ai_question, interrupted_text, conversation_filename)

                                            # Add to context (keep only last 2 QA pairs)
                                            conversation_context.append((previous_ai_question, interrupted_text))
                                            if len(conversation_context) > 2:
                                                conversation_context = conversation_context[-2:]
                                        
                                        # Pass context to AI
                                        similar_qs = query_faiss(interrupted_text, embedding_model, index, metadata, top_n=5)
                                        print(f"FAISS suggestions: {similar_qs}")
                                        context = "\n".join([f"- {q[0]}" for q in similar_qs])

                                        # Pass context to AI
                                        new_ai_response, conversation_history = query_groq(
                                            interrupted_text,
                                            context,
                                            conversation_history=conversation_history
                                        )
                                        print(f"AI: {new_ai_response}")
                                        
                                        # Update previous AI question
                                        previous_ai_question = new_ai_response

                                        if new_ai_response:
                                            new_audio = text_to_speech(new_ai_response)
                                            if new_audio:
                                                conversation_manager.play_response_with_interruption(new_audio)

                            conversation_manager.clear_interruption_buffer()
                            continue
                    else:
                        print("Failed to generate speech.")
                else:
                    print("No AI response generated.")

            elif interrupted:
                print("Conversation ended by user.")
                break
            else:
                print("No speech detected, continuing to listen...")

        except KeyboardInterrupt:
            print("\nConversation ended. Goodbye!")
            break
        except Exception as e:
            print(f"Error: {e}")
            print("Continuing conversation...")
            time.sleep(1)