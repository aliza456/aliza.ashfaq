"""
FastAPI app (no database) that mirrors your script end‑to‑end:
- Google OAuth (Forms responses readonly + Gmail send scope kept as in script)
- Fetch Google Form responses → save JSONL
- Extract GitHub URLs from JSONL
- Clone repos with GitPython
- Load assessments + CSV question bank
- Run tests per Q*.py with support for single or multiple CSV IDs
- Aggregate results to test_results.json

Hardcoded candidate_id: "aliza.ashfaq"

Run:
    pip install fastapi uvicorn google-auth google-auth-oauthlib google-api-python-client GitPython PyPDF2
    uvicorn fastapi_no_db_app:app --reload --port 8000

Notes:
- No DB used; everything stored on filesystem.
- OAuth launches a local browser the first time to create token.json.
- Defaults use your paths; override with env vars if desired.
"""

from __future__ import annotations

import os
import json
import csv
import pathlib
import ast
import importlib.util
from datetime import datetime
from typing import Dict, List, Tuple, Optional, Union

from app import FastAPI, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from google.auth.transport.requests import Request

import git

# ------------------------------
# Config (defaults reflect your latest script; env vars can override)
# ------------------------------
SCOPES = [
    "https://www.googleapis.com/auth/gmail.send",
    "https://www.googleapis.com/auth/forms.responses.readonly",
]
FORM_ID = os.getenv("FORM_ID", "1mo_5-XMT8_hTKGj9D-ddWTh3cWBvNe7RKNJuQjKePbo")
CLIENT_SECRET_FILE = os.getenv(
    "CLIENT_SECRET_FILE",
    "client_secret_993249251770-39ot8taj89kdptcqqgdii5pjerprid2u.apps.googleusercontent.com.json",
)
TOKEN_FILE = os.getenv("TOKEN_FILE", "token.json")

# Use your provided absolute paths by default; can be overridden
CLONED_REPOS_DIR = pathlib.Path(os.getenv("CLONED_REPOS_DIR", "/home/aliza-ashfaq/Desktop/interview/cloned_repos"))
CSV_PATH = pathlib.Path(os.getenv("CSV_PATH", "ml_interview_questions_Q1_to_Q10.csv"))
ASSESSMENTS_JSON = pathlib.Path(os.getenv("ASSESSMENTS_JSON", "/home/aliza-ashfaq/Desktop/interview/all_assessments.json"))
RESULTS_PATH = pathlib.Path(os.getenv("RESULTS_PATH", str(CLONED_REPOS_DIR.parent / "test_results.json")))
RESPONSES_JSONL = pathlib.Path(os.getenv("RESPONSES_JSONL", "form_responses.jsonl"))

HARDCODED_CANDIDATE_ID = "aliza.ashfaq"

CLONED_REPOS_DIR.mkdir(parents=True, exist_ok=True)

# ------------------------------
# Pydantic bodies
# ------------------------------
class FetchBody(BaseModel):
    form_id: str = FORM_ID

class CloneBody(BaseModel):
    target_dir: Optional[str] = None
    urls: Optional[List[str]] = None  # If omitted, read from JSONL

class TestsBody(BaseModel):
    repo_name_contains: Optional[str] = None  # Filter cloned repos by substring

# ------------------------------
# Google OAuth helpers
# ------------------------------

def get_creds() -> Credentials:
    creds: Optional[Credentials] = None
    if os.path.exists(TOKEN_FILE):
        creds = Credentials.from_authorized_user_file(TOKEN_FILE, SCOPES)
    if creds and creds.expired and creds.refresh_token:
        try:
            creds.refresh(Request())
            with open(TOKEN_FILE, "w", encoding="utf-8") as f:
                f.write(creds.to_json())
        except Exception:
            creds = None
    if not creds or not creds.valid:
        flow = InstalledAppFlow.from_client_secrets_file(CLIENT_SECRET_FILE, SCOPES)
        creds = flow.run_local_server(port=0)
        with open(TOKEN_FILE, "w", encoding="utf-8") as f:
            f.write(creds.to_json())
    return creds

# ------------------------------
# Forms API
# ------------------------------

def list_all_responses(form_id: str) -> List[dict]:
    creds = get_creds()
    svc = build("forms", "v1", credentials=creds)
    out: List[dict] = []
    token: Optional[str] = None
    while True:
        resp = svc.forms().responses().list(formId=form_id, pageToken=token).execute()
        out.extend(resp.get("responses", []))
        token = resp.get("nextPageToken")
        if not token:
            break
    return out

# ------------------------------
# URL extraction & cloning
# ------------------------------

def read_github_urls_from_responses(jsonl_file: pathlib.Path = RESPONSES_JSONL) -> List[str]:
    urls: List[str] = []
    if not jsonl_file.exists():
        return urls
    with open(jsonl_file, "r", encoding="utf-8") as f:
        for line in f:
            try:
                response = json.loads(line)
                answers = response.get("answers", {})
                for _, answer_data in answers.items():
                    for ans in answer_data.get("textAnswers", {}).get("answers", []):
                        val = ans.get("value", "")
                        if "github.com" in val.lower():
                            urls.append(val)
                            break
            except Exception:
                continue
    return urls


def clone_github_repos(urls: List[str], target_dir: pathlib.Path) -> List[dict]:
    target_dir.mkdir(parents=True, exist_ok=True)
    results: List[dict] = []
    for url in urls:
        u = url.strip()
        if not u:
            continue
        repo_name = u.rstrip('/').split('/')[-1]
        if repo_name.endswith('.git'):
            repo_name = repo_name[:-4]
        username = u.rstrip('/').split('/')[-2]
        repo_dir = target_dir / f"{username}_{repo_name}"
        if repo_dir.exists():
            results.append({"url": u, "status": "already_exists", "path": str(repo_dir)})
            continue
        try:
            git.Repo.clone_from(u, repo_dir)
            results.append({"url": u, "status": "success", "path": str(repo_dir)})
        except git.GitCommandError as e:
            results.append({"url": u, "status": "error", "error": str(e)})
    return results

# ------------------------------
# Testing utilities
# ------------------------------

def load_question_bank(csv_path: pathlib.Path) -> Dict[str, dict]:
    if not csv_path.exists():
        raise FileNotFoundError(f"CSV not found: {csv_path}")
    questions: Dict[str, dict] = {}
    with open(csv_path, newline='', encoding='utf-8') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            qid = row["question ID"].strip()
            questions.setdefault(qid, {"question": row["question"].strip(), "test_cases": []})
            questions[qid]["test_cases"].append((row["input"], row["expected"]))
    return questions


def extract_mapping_for_candidate(json_path: pathlib.Path, candidate_id: str) -> Dict[str, Union[str, List[str]]]:
    if not json_path.exists():
        return {}
    with open(json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    for assessment in data.get("assessments", []):
        if assessment.get("candidate_id") == candidate_id:
            out: Dict[str, Union[str, List[str]]] = {}
            for pdf_q, details in assessment.get("questions", {}).items():
                if isinstance(details, dict):
                    if "csv_ids" in details and isinstance(details["csv_ids"], list):
                        out[pdf_q] = details["csv_ids"]
                    elif "csv_id" in details:
                        out[pdf_q] = details["csv_id"]
                else:
                    out[pdf_q] = details
            return out
    return {}


def detect_functions_in_file(py_file: pathlib.Path) -> List[str]:
    try:
        with open(py_file, 'r', encoding='utf-8') as f:
            content = f.read()
        tree = ast.parse(content)
        return [n.name for n in ast.walk(tree) if isinstance(n, ast.FunctionDef)]
    except Exception:
        return []


def _coerce_expected(s: str):
    ss = s.strip()
    if ss.upper() == "TRUE":
        return True
    if ss.upper() == "FALSE":
        return False
    return json.loads(ss)


def test_function_against_csv(candidate_file: pathlib.Path, function_name: str, test_cases: List[Tuple[str, str]]):
    details = {"total_tests": len(test_cases), "passed": 0, "failed": 0, "failed_cases": []}
    try:
        spec = importlib.util.spec_from_file_location("candidate", candidate_file)
        mod = importlib.util.module_from_spec(spec)
        assert spec.loader is not None
        spec.loader.exec_module(mod)
        func = getattr(mod, function_name)
        for input_data, expected_output in test_cases:
            try:
                input_obj = json.loads(input_data)
                expected_obj = _coerce_expected(expected_output)
                if isinstance(input_obj, dict):
                    res = func(**input_obj)
                elif isinstance(input_obj, (list, tuple)):
                    res = func(*input_obj)
                else:
                    res = func(input_obj)
                if res == expected_obj:
                    details["passed"] += 1
                else:
                    details["failed"] += 1
                    details["failed_cases"].append({"input": input_data, "expected": expected_output, "actual": repr(res)})
            except Exception as e:
                details["failed"] += 1
                details["failed_cases"].append({"input": input_data, "expected": expected_output, "actual": f"Exception: {e}"})
        return (details["failed"] == 0), details
    except Exception as e:
        details["error"] = str(e)
        return False, details


def run_tests_from_mapping(repo_path: pathlib.Path, mapping: Dict[str, Union[str, List[str]]], question_bank: Dict[str, dict]):
    py_files = [f for f in repo_path.glob("Q*.py")]
    results = {
        "total_files": len(py_files),
        "files_tested": 0,
        "files_passed": 0,
        "files_failed": 0,
        "questions": {}
    }

    for py_file in py_files:
        pdf_q = py_file.stem
        csv_id_or_ids = mapping.get(pdf_q)
        if not csv_id_or_ids:
            results["questions"][pdf_q] = {"status": "skipped", "reason": "No CSV ID mapping found"}
            continue
        csv_ids = csv_id_or_ids if isinstance(csv_id_or_ids, list) else [csv_id_or_ids]

        all_passed = True
        combined = {"total_tests": 0, "passed": 0, "failed": 0, "failed_cases": []}
        fn_name: Optional[str] = None

        for single_csv_id in csv_ids:
            if single_csv_id not in question_bank:
                continue
            fns = detect_functions_in_file(py_file)
            if not fns:
                results["questions"][pdf_q] = {"status": "error", "reason": "No functions found in file", "csv_id": single_csv_id}
                all_passed = False
                continue
            fn_name = fns[0]
            success, det = test_function_against_csv(py_file, fn_name, question_bank[single_csv_id]["test_cases"])
            combined["total_tests"] += det.get("total_tests", 0)
            combined["passed"] += det.get("passed", 0)
            combined["failed"] += det.get("failed", 0)
            combined["failed_cases"].extend(det.get("failed_cases", []))
            if not success:
                all_passed = False

        if csv_ids:
            results["files_tested"] += 1
            if all_passed:
                results["files_passed"] += 1
            else:
                results["files_failed"] += 1
            results["questions"][pdf_q] = {
                "status": "passed" if all_passed else "failed",
                "csv_ids": csv_ids,
                "function_name": fn_name,
                "test_details": combined,
            }

    return results

# ------------------------------
# FastAPI app
# ------------------------------
app = FastAPI(title="Forms→GitHub→Tests (No DB)", version="1.0.0")

@app.get("/health")
def health():
    return {"status": "ok"}

@app.get("/config")
def get_config():
    return {
        "FORM_ID": FORM_ID,
        "CLIENT_SECRET_FILE": CLIENT_SECRET_FILE,
        "TOKEN_FILE": TOKEN_FILE,
        "CLONED_REPOS_DIR": str(CLONED_REPOS_DIR),
        "CSV_PATH": str(CSV_PATH),
        "ASSESSMENTS_JSON": str(ASSESSMENTS_JSON),
        "RESULTS_PATH": str(RESULTS_PATH),
        "RESPONSES_JSONL": str(RESPONSES_JSONL),
        "HARDCODED_CANDIDATE_ID": HARDCODED_CANDIDATE_ID,
    }

@app.post("/forms/fetch")
def fetch_form_responses(body: FetchBody):
    responses = list_all_responses(body.form_id)
    with open(RESPONSES_JSONL, 'w', encoding='utf-8') as f:
        for r in responses:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    return {"form_id": body.form_id, "responses_count": len(responses), "saved_to": str(RESPONSES_JSONL)}

@app.get("/forms/urls")
def list_urls():
    urls = read_github_urls_from_responses(RESPONSES_JSONL)
    return {"count": len(urls), "urls": urls}

@app.post("/github/clone")
def clone_repos(body: CloneBody):
    target = pathlib.Path(body.target_dir) if body.target_dir else CLONED_REPOS_DIR
    urls = body.urls if body.urls is not None else read_github_urls_from_responses(RESPONSES_JSONL)
    if not urls:
        raise HTTPException(status_code=400, detail="No GitHub URLs provided or found in JSONL.")
    results = clone_github_repos(urls, target)
    return {"target_dir": str(target), "results": results}

@app.post("/tests/run")
def run_tests(body: TestsBody):
    if not CLONED_REPOS_DIR.exists():
        raise HTTPException(status_code=400, detail=f"No cloned repos directory: {CLONED_REPOS_DIR}")
    repos = [d for d in CLONED_REPOS_DIR.iterdir() if d.is_dir() and not d.name.startswith('.')] 
    if body.repo_name_contains:
        repos = [r for r in repos if body.repo_name_contains in r.name]
    if not repos:
        raise HTTPException(status_code=404, detail="No repositories found matching criteria.")

    question_bank = load_question_bank(CSV_PATH)
    mapping = extract_mapping_for_candidate(ASSESSMENTS_JSON, HARDCODED_CANDIDATE_ID)

    overall = {"timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "candidate_id": HARDCODED_CANDIDATE_ID, "repos": {}}

    for repo in repos:
        overall["repos"][repo.name] = run_tests_from_mapping(repo, mapping, question_bank)

    # Merge with existing file to preserve history-like behavior
    merged: dict
    if RESULTS_PATH.exists():
        try:
            with open(RESULTS_PATH, 'r', encoding='utf-8') as f:
                old = json.load(f)
        except Exception:
            old = {}
        merged = {**old}
        merged.setdefault("history", []).append(overall)
    else:
        merged = {"history": [overall]}

    with open(RESULTS_PATH, 'w', encoding='utf-8') as f:
        json.dump(merged, f, indent=2)

    return JSONResponse(content=merged)

@app.post("/run-all")
def run_all():
    # 1) Fetch responses
    responses = list_all_responses(FORM_ID)
    with open(RESPONSES_JSONL, 'w', encoding='utf-8') as f:
        for r in responses:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

    # 2) Extract URLs
    urls = read_github_urls_from_responses(RESPONSES_JSONL)

    # 3) Clone
    clone_results = clone_github_repos(urls, CLONED_REPOS_DIR) if urls else []

    # 4) Test
    question_bank = load_question_bank(CSV_PATH)
    mapping = extract_mapping_for_candidate(ASSESSMENTS_JSON, HARDCODED_CANDIDATE_ID)

    repos = [d for d in CLONED_REPOS_DIR.iterdir() if d.is_dir() and not d.name.startswith('.')]
    overall = {"timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "candidate_id": HARDCODED_CANDIDATE_ID, "repos": {}}
    for repo in repos:
        overall["repos"][repo.name] = run_tests_from_mapping(repo, mapping, question_bank)

    # Save/merge
    merged: dict
    if RESULTS_PATH.exists():
        try:
            with open(RESULTS_PATH, 'r', encoding='utf-8') as f:
                old = json.load(f)
        except Exception:
            old = {}
        merged = {**old}
        merged.setdefault("history", []).append(overall)
    else:
        merged = {"history": [overall]}

    with open(RESULTS_PATH, 'w', encoding='utf-8') as f:
        json.dump(merged, f, indent=2)

    return {
        "fetched_responses": len(responses),
        "urls_found": len(urls),
        "cloned": clone_results,
        "results_path": str(RESULTS_PATH),
        "final_report": merged,
    }
