# pip install reportlab google-auth google-auth-oauthlib google-api-python-client

from __future__ import print_function
import os, base64, mimetypes, json, csv, random, uuid, sqlite3
from datetime import datetime
from pathlib import Path
from email.message import EmailMessage

from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from google.auth.transport.requests import Request as GoogleAuthRequest

# =========================
# ======== CONFIG =========
# =========================

SCOPES = [
    "https://www.googleapis.com/auth/gmail.send",
    "https://www.googleapis.com/auth/forms.responses.readonly",
]

DB_PATH = "/home/aliza-ashfaq/Desktop/interview/Database.db"  # <-- UPDATE
CSV_PATH = "ml_interview_questions_Q1_to_Q10.csv"  # <-- UPDATE if needed
ASSESSMENTS_FILE = "all_assessments.json"
CLIENT_SECRET_FILE = "client_secret_993249251770-39ot8taj89kdptcqqgdii5pjerprid2u.apps.googleusercontent.com.json"  # <-- UPDATE

SENDER = "alizaak265@gmail.com"  # <-- UPDATE (authorized Gmail)
SUBJECT = "Your ML/DSA Assessment"
GOOGLE_FORM_URL = "https://forms.gle/nEAhYKcw6jfKMd8GA"  # <-- UPDATE

BODY_TEMPLATE = f"""Hi,

Please find the DSA assessment PDF attached.

Also, please fill out this Google Form: {GOOGLE_FORM_URL}

Thanks!
"""

# =========================
# ===== DB + SELECTION ====
# =========================

def get_top_3_candidates(db_path=DB_PATH, limit=3):
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    cur.execute("""
        SELECT candidate_id, email_address
        FROM candidates
        WHERE email_address IS NOT NULL
          AND TRIM(email_address) <> ''
          AND (sent = 0 OR sent IS NULL)
        ORDER BY resume_score DESC
        LIMIT ?
    """, (limit,))
    rows = cur.fetchall()
    conn.close()
    return [{"candidate_id": r[0], "email_address": r[1]} for r in rows]

def mark_sent(candidate_id, db_path=DB_PATH):
    conn = sqlite3.connect(db_path)
    conn.execute("UPDATE candidates SET sent = 1 WHERE candidate_id = ?", (candidate_id,))
    conn.commit()
    conn.close()

# =========================
# ====== QUESTIONS ========
# =========================

# def load_dsa_questions(csv_path=CSV_PATH):
#     questions, seen = [], set()
#     with open(csv_path, newline='', encoding='utf-8') as f:
#         for row in csv.DictReader(f):
#             q = row["question"]
#             if q not in seen:
#                 seen.add(q)
#                 questions.append(q)
#     return questions

def read_question_groups(csv_path=CSV_PATH):
    """
    Returns:
      unique_questions: list[str]               # one entry per base question (e.g., 'Q1 text')
      qtext_to_csvids: dict[str, list[str]]     # question text -> ALL CSV IDs (Q1_TC1, Q1_TC2, ...)
      base_to_qtext: dict[str, str]             # 'Q1' -> canonical question text
    Assumes CSV has columns: 'question ID', 'question'
    """
    by_base = {}           # base_id -> {'text': <qtext>, 'csv_ids': [all TCs]}
    qtext_to_csvids = {}   # text -> list of csv_ids
    base_to_qtext = {}

    with open(csv_path, newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            csv_id = row["question ID"].strip()
            qtext  = row["question"].strip()
            base_id = csv_id.split('_')[0]  # 'Q1_TC2' -> 'Q1' ; also works if plain 'Q1'

            if base_id not in by_base:
                by_base[base_id] = {"text": qtext, "csv_ids": []}
            by_base[base_id]["csv_ids"].append(csv_id)

            # Keep a mapping text -> all csv_ids (across bases that share identical text)
            qtext_to_csvids.setdefault(qtext, []).append(csv_id)

    # Canonicalize one text per base question
    base_to_qtext = {base: payload["text"] for base, payload in by_base.items()}

    # One unique question per base (used when randomly picking questions)
    unique_questions = [payload["text"] for payload in by_base.values()]
    return unique_questions, qtext_to_csvids, base_to_qtext


def pick_random_questions(questions, min_q=4, max_q=5, seed=None):
    if seed is not None:
        random.seed(seed)
    n = random.randint(min_q, max_q)
    if len(questions) < n:
        raise ValueError(f"Need at least {n} questions, got {len(questions)}.")
    return random.sample(questions, n)

# =========================
# ========= PDF ===========
# =========================

def save_pdf(questions, title="DSA Assessment", out_path="quiz.pdf", candidate_id=None):
    from reportlab.lib.pagesizes import A4
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib.units import mm
    import html

    styles = getSampleStyleSheet()
    style_title = styles["Title"]
    style_q = styles["BodyText"]; style_q.fontSize = 12; style_q.leading = 16

    doc = SimpleDocTemplate(out_path, pagesize=A4,
                            leftMargin=20*mm, rightMargin=20*mm,
                            topMargin=20*mm, bottomMargin=20*mm)
    story = []
    if candidate_id:
        story.append(Paragraph(f"Candidate ID: {candidate_id}", style_title))
        story.append(Spacer(1, 12))
    story.append(Paragraph(title, style_title))
    story.append(Paragraph(datetime.now().strftime("%Y-%m-%d %H:%M"), styles["Normal"]))
    story.append(Spacer(1, 12))
    for i, q in enumerate(questions, 1):
        story.append(Paragraph(f"{i}. {html.escape(q)}", style_q))
        story.append(Spacer(1, 18))
    doc.build(story)
    return str(Path(out_path).resolve())

# =========================
# ====== EMAIL/GMAIL ======
# =========================

def get_gmail_service():
    creds = None
    if os.path.exists("token.json"):
        creds = Credentials.from_authorized_user_file("token.json", SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
            with open("token.json", "w") as f:
                f.write(creds.to_json())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(CLIENT_SECRET_FILE, SCOPES)
            creds = flow.run_local_server(port=0)
            with open("token.json", "w") as f:
                f.write(creds.to_json())
    return build("gmail", "v1", credentials=creds)

def create_message_with_attachment(sender, to, subject, body_text, file_path):
    msg = EmailMessage()
    msg["To"] = to
    msg["From"] = sender
    msg["Subject"] = subject
    msg.set_content(body_text)
    ctype, _ = mimetypes.guess_type(file_path)
    maintype, subtype = (ctype.split("/", 1) if ctype else ("application", "octet-stream"))
    with open(file_path, "rb") as f:
        msg.add_attachment(f.read(), maintype=maintype, subtype=subtype, filename=os.path.basename(file_path))
    raw = base64.urlsafe_b64encode(msg.as_bytes()).decode()
    return {"raw": raw}

# =========================
# ========= MAIN ==========
# =========================

def main():
    print("Selecting top 3 candidates by resume_score...")
    top_candidates = get_top_3_candidates()
    if not top_candidates:
        print("No candidates with valid emails. Exiting.")
        raise SystemExit(0)

    QUESTIONS, QTEXT_TO_CSVIDS, BASE_TO_QTEXT = read_question_groups()
    # Build mapping (question text -> CSV ID) once
    with open(CSV_PATH, newline='', encoding='utf-8') as f:
        q_to_id = {row["question"]: row["question ID"] for row in csv.DictReader(f)}

    gmail = get_gmail_service()
    sent_count = 0

    # Ensure assessments file exists/shape
    if os.path.exists(ASSESSMENTS_FILE):
        try:
            with open(ASSESSMENTS_FILE, "r", encoding="utf-8") as f:
                assessments_store = json.load(f)
        except json.JSONDecodeError:
            assessments_store = {"assessments": []}
    else:
        assessments_store = {"assessments": []}

    for cand in top_candidates:
        candidate_id = cand["candidate_id"] or f"cand_{uuid.uuid4().hex[:8]}"
        recipient = cand["email_address"]

        picked = pick_random_questions(QUESTIONS, min_q=4, max_q=5)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        pdf_path = save_pdf(picked, title="DSA Assessment",
                            out_path=f"dsa_quiz_{candidate_id}_{stamp}.pdf",
                            candidate_id=candidate_id)

        # PDF Q# -> CSV ID mapping
        picked_mapping = {
        f"Q{i}": {
            "csv_ids": QTEXT_TO_CSVIDS.get(q, []),  # <-- list of ALL testcases for that question
            "text": q
        }
        for i, q in enumerate(picked, 1)
}
        # Append to central log
        assessments_store["assessments"].append({
            "candidate_id": candidate_id,
            "email": recipient,
            "timestamp": stamp,
            "questions": picked_mapping,
            "pdf_path": pdf_path
        })

        # Send the email to THIS candidate
        try:
            msg = create_message_with_attachment(SENDER, recipient, SUBJECT, BODY_TEMPLATE, pdf_path)
            sent = gmail.users().messages().send(userId="me", body=msg).execute()
            print(f"✅ Sent to {recipient} (msg id: {sent.get('id')})")
            mark_sent(candidate_id)
            sent_count += 1
        except Exception as e:
            print(f"❌ Failed to send to {recipient}: {e}")

    # Save the updated assessments log once
    with open(ASSESSMENTS_FILE, "w", encoding="utf-8") as jf:
        json.dump(assessments_store, jf, indent=2)

    print(f"\nEmails successfully sent: {sent_count}/{len(top_candidates)}")


if __name__ == "__main__":
    main()