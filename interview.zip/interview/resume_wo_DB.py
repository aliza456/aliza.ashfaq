# --- simplified ATS pipeline: uploads-only, no DB, individual outputs ---

from groq import Groq
import base64, os
from pathlib import Path
import pymupdf, io
from PIL import Image
import json
import ollama
from datetime import datetime, timedelta
import secrets, string
import uuid, hmac, hashlib
# ------------------------- CONFIG -------------------------
# Prefer env vars; falls back to your literal for convenience
GROQ_API_KEY = os.getenv("GROQ_API_KEY", "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")
client = Groq(api_key=GROQ_API_KEY)

MODEL = "gemma3:4b"            # Ollama local model for comparison
JD_PDF = "JD.pdf"              # JD source PDF
JD_JSON_FILE = "jd_extraction.json"
UPLOADS_DIR = "uploads"        # resumes (PDFs) are read only from here
JD_IMG_DIR = "output_JD"
RESUME_IMG_DIR = "output_resumes"
RESUMES_JSON_DIR = "extracted_resumes"   # individual extracted resume JSON files
EVALS_DIR = "evaluations"                # individual evaluation JSON files
os.makedirs(JD_IMG_DIR, exist_ok=True)
os.makedirs(RESUME_IMG_DIR, exist_ok=True)
os.makedirs(RESUMES_JSON_DIR, exist_ok=True)
os.makedirs(EVALS_DIR, exist_ok=True)

# ------------------------- HELPERS -------------------------
def encode_image(path: str) -> str:
    with open(path, "rb") as f:
        return base64.b64encode(f.read()).decode("utf-8")

def stitch_vertical(image_paths, out_path="stitched.png", bg="white"):
    imgs = [Image.open(p).convert("RGB") for p in image_paths]
    maxw = max(im.width for im in imgs)
    norm = [
        im if im.width == maxw else im.resize((maxw, int(im.height * maxw / im.width)), Image.LANCZOS)
        for im in imgs
    ]
    total_h = sum(im.height for im in norm)
    canvas = Image.new("RGB", (maxw, total_h), color=bg)
    y = 0
    for im in norm:
        canvas.paste(im, (0, y)); y += im.height
    canvas.save(out_path)
    return out_path

def groq_extract_from_image_JD(image_path: str, model: str = "meta-llama/llama-4-scout-17b-16e-instruct") -> str:
    try:
        base64_image = encode_image(image_path)
        system_prompt = "You are a strict information extractor. Your task is to extract ALL relevant information from the image. Output ONLY valid JSON per the schema. No extra text or prose."
        user_prompt =  """
            - Extract job overview, responsibilities , required tools, and qualifications from the image.
            - Use all the valid details from the image to populate the JSON fields.
            - Do not write "```json" in your response.
            """
        response = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": system_prompt},
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": user_prompt},
                        {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{base64_image}"}}
                    ],
                },
            ],
            temperature=0,
            max_tokens=2048,
        )
        return response.choices[0].message.content
    except Exception as e:
        print(f"An error occurred while processing JD {image_path}: {e}")
        return None

def groq_extract_from_image_resume(image_path: str, model: str = "meta-llama/llama-4-scout-17b-16e-instruct") -> str:
    try:
        base64_image = encode_image(image_path)
        system_prompt = "You are a precise information extractor. Extract ALL visible information from the resume image. Output ONLY valid JSON per the schema with NO extra text."
        user_prompt =  """
            - Extract EVERY Projects, Work Experience, Education, Skills, certifications and Technologies.
            - Extract ALL RELEVANT details from this résumé image.
            - Output a JSON object with keys: name, email, phone, education (list of {degree, institution, year}), Work Experience (list of {job_title, company, start_date, end_date, responsibilities}), Skills (list), Technologies (list).
            - Do not write "```json" in your response.
            """
        response = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": system_prompt},
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": user_prompt},
                        {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{base64_image}"}}
                    ],
                },
            ],
            temperature=0,
            max_tokens=4096,
        )
        return response.choices[0].message.content
    except Exception as e:
        print(f"An error occurred while processing resume {image_path}: {e}")
        return None

def save_json_result(result_text, filename) -> bool:
    if result_text:
        try:
            parsed = json.loads(result_text)
            with open(filename, "w", encoding="utf-8") as f:
                json.dump(parsed, f, indent=2, ensure_ascii=False)
            print(f"✅ Saved JSON to: {filename}")
            return True
        except json.JSONDecodeError as e:
            print(f"⚠️ Invalid JSON, saving raw text to {filename}.txt ({e})")
            with open(f"{filename}.txt", "w", encoding="utf-8") as f:
                f.write(result_text)
            return False
    else:
        print("⚠️ No result to save")
        return False

def load_jd_file(file_path):
    file_path = Path(file_path).resolve()
    with open(file_path, "r", encoding="utf-8") as f:
        return json.load(f), str(file_path)

def load_all_resume_files(directory):
    resume_files = {}
    dir_path = Path(directory).resolve()
    if not dir_path.is_dir():
        raise FileNotFoundError(f"Directory not found: {directory}")
    for json_file in dir_path.glob("*.json"):
        try:
            with open(json_file, "r", encoding="utf-8") as f:
                resume_data = json.load(f)
                resume_name = json_file.stem
                resume_files[resume_name] = {"data": resume_data, "path": str(json_file)}
        except Exception as e:
            print(f"Error loading {json_file}: {e}")
    return resume_files

def minify(obj) -> str:
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":"))

def get_resume_files_from_uploads(uploads_dir=UPLOADS_DIR):
    resumes = []
    p = Path(uploads_dir)
    if not p.exists():
        print(f"⚠️ Uploads directory '{uploads_dir}' not found!")
        return []
    for pdf in p.glob("*.pdf"):
        resumes.append({"candidate_id": pdf.stem, "resume_filepath": str(pdf), "resume_filename": pdf.name})
    return resumes

# --------------- LLM comparison prompt & helpers ---------------
SYSTEM = (
    """You are an AI resume evaluator who analyzes candidates' resumes critically and contextually. 
    You don’t just look for keyword matches — you cross-verify every claimed skill, experience, or achievement against supporting evidence 
    such as project descriptions, outcomes, or measurable results. 
Projects 25, Educational Background 15, Work Experience 25, Technical Skills 25, Related Certifications 10.

# Evaluation Rules:
- If a skill is listed but not demonstrated in the resume, you should flag it as unsubstantiated— and score strictly by this rubric (max points): 
- Analyze relevance, depth, and contextual alignment of the résumé content to the job description.
- Award points only when there is **clear, contextual evidence** (e.g., described responsibilities, achievements, measurable impact, or detailed technical application). 
- **Do not** award points for skills or tools listed without supporting context in experience, education, or projects.
- Assess based on both **strengths (reason)** and **what is lacking (lacking)** for each category.
- Ensure that reasoning is specific, not generic — justify why a score was given in context to the job requirements.
- Compute `final_score` as the total of all category scores and include a quick calculation check.
- Return **only valid JSON**, no markdown or extra text.
- Use this exact schema:

{
  "Projects": {"score": int, "reason": str, "lacking": str},
  "Educational Background": {"score": int, "reason": str, "lacking": str},
  "Work Experience": {"score": int, "reason": str, "lacking": str},
  "Technical Skills": {"score": int, "reason": str, "lacking": str},
  "Related Certifications": {"score": int, "reason": str, "lacking": str},
  "final_score": {"value": int}
}

# Scoring Guidance:
- **Projects (25 pts):** Evaluate relevance, depth, and measurable outcomes of projects related to the job role. Full credit requires detailed context and tangible results.
- **Educational Background (15 pts):** Award based on field relevance, degree level, and notable coursework or academic projects.
- **Work Experience (25 pts):** Assess relevance, seniority, and evidence of impact or responsibilities aligned to the job description.
- **Technical Skills (25 pts):** Give points for proven, demonstrated skills applied in Projects and work experience — not just listed keywords.
- **Related Certifications (10 pts):** Score only if certifications are verifiably related to the job field or required technologies.

All scores and reasoning must reflect contextual judgment rather than surface keyword matches."

"""
)

USER_TEMPLATE = """Check the resume against the job description and evaluate if candidate is the right fit for the job.

Job Description:
{jd_json}

Resume:
{resume_json}
"""

def compare_with_llm(jd_obj: dict, resume_obj: dict, model: str = MODEL) -> dict:
    user_prompt = USER_TEMPLATE.format(
        jd_json=minify(jd_obj),
        resume_json=minify(resume_obj),
    )
    try:
        resp = ollama.chat(
            model=model,
            messages=[{"role": "system", "content": SYSTEM},
                      {"role": "user", "content": user_prompt}],
            options={"temperature": 0},
        )
        raw = resp["message"]["content"]
        if raw and raw.strip().startswith("{"):
            return json.loads(raw)
        # fallback: try to find JSON inside any wrappers
        import re
        m = re.search(r"\{.*\}", raw, re.DOTALL)
        return json.loads(m.group()) if m else {"error": "No valid JSON found in response", "raw": raw}
    except json.JSONDecodeError as e:
        return {"error": f"Invalid JSON response: {e}", "raw": raw}
    except Exception as e:
        return {"error": str(e)}

# ------------------------- MAIN -------------------------
if __name__ == "__main__":
    print("=" * 60)
    print("PROCESSING JD + RESUMES FROM 'uploads/' (NO DATABASE)")
    print("=" * 60)

    # ----- JD extraction (once) -----
    jd_result = None
    if os.path.exists(JD_PDF):
        print("\nPROCESSING JOB DESCRIPTION (JD.pdf)...")
        try:
            doc = pymupdf.open(JD_PDF)
            img_paths = []
            for p in doc:
                img = Image.open(io.BytesIO(p.get_pixmap(dpi=300).tobytes("png")))
                out_path = f"{JD_IMG_DIR}/page_{p.number + 1}.png"
                img.save(out_path)
                img_paths.append(out_path)
            doc.close()
            print(f"JD images saved to: {JD_IMG_DIR}")

            if img_paths:
                stitched_jd_path = stitch_vertical(sorted(img_paths), out_path="stitched_JD.png")
                print(f"Stitched JD saved to: {stitched_jd_path}")
                print("Extracting JD details with Groq API...")
                jd_result = groq_extract_from_image_JD(stitched_jd_path)
                if jd_result:
                    save_json_result(jd_result, JD_JSON_FILE)
                else:
                    print("No JD result returned.")
        except Exception as e:
            print(f"Error processing JD: {e}")
    else:
        print("JD.pdf not found — skipping JD extraction (will fail if comparisons need it).")

    print("\n" + "=" * 60)

    # ----- Resume extraction from uploads/ -----
    resume_entries = get_resume_files_from_uploads(UPLOADS_DIR)
    print(f"Found {len(resume_entries)} PDF(s) in '{UPLOADS_DIR}'")

    resume_results = {}

    for i, resume_info in enumerate(resume_entries, start=1):
        resume_path = resume_info["resume_filepath"]
        resume_name = resume_info["candidate_id"]
        print(f"\nPROCESSING RESUME {i}/{len(resume_entries)}: {resume_path}")

        if not os.path.exists(resume_path):
            print(f"⚠️ File not found, skipping: {resume_path}")
            continue

        try:
            current_dir = os.path.join(RESUME_IMG_DIR, resume_name)
            os.makedirs(current_dir, exist_ok=True)

            # PDF -> page images
            doc = pymupdf.open(resume_path)
            page_imgs = []
            for p in doc:
                img = Image.open(io.BytesIO(p.get_pixmap(dpi=300).tobytes("png")))
                out_path = f"{current_dir}/page_{p.number + 1}.png"
                img.save(out_path)
                page_imgs.append(out_path)
            doc.close()
            print(f"Resume images saved to: {current_dir}")

            # Stitch & extract with Groq
            if page_imgs:
                stitched_resume_path = f"stitched_resume_{resume_name}.png"
                stitch_vertical(sorted(page_imgs), out_path=stitched_resume_path)
                print(f"Stitched Resume saved to: {stitched_resume_path}")

                print("Extracting resume details with Groq API...")
                resume_result_text = groq_extract_from_image_resume(stitched_resume_path)
                if resume_result_text:
                    resume_results[resume_name] = resume_result_text
                    save_json_result(
                        resume_result_text,
                        os.path.join(RESUMES_JSON_DIR, f"{resume_name}.json"),
                    )
                else:
                    print(f"⚠️ No extraction result for: {resume_name}")
            else:
                print(f"⚠️ No images produced for: {resume_name}")

        except Exception as e:
            print(f"Error processing resume {resume_path}: {e}")

    print("\n" + "=" * 60)
    print("EXTRACTION COMPLETED")
    print(f"JD processed: {'✅' if jd_result else '❌'}")
    print(f"Resumes processed: {len(resume_results)}/{len(resume_entries)}")
    print("=" * 60)

    # ----- Comparison (Ollama) -----
    try:
        if not os.path.exists(JD_JSON_FILE):
            raise FileNotFoundError(f"JD JSON not found: {JD_JSON_FILE}")
        jd_obj, jd_path = load_jd_file(JD_JSON_FILE)
        print(f"\nLoaded JD JSON: {jd_path}")

        resume_jsons = load_all_resume_files(RESUMES_JSON_DIR)
        if not resume_jsons:
            print(f"⚠️ No extracted resume JSONs found in: {RESUMES_JSON_DIR}")
            raise SystemExit(1)

        all_results = {}
        for resume_name, info in resume_jsons.items():
            print(f"\n{'='*60}\nEVALUATING: {resume_name}\n{'='*60}")
            result = compare_with_llm(jd_obj, info["data"], MODEL)
            all_results[resume_name] = result

            # save each evaluation individually
            eval_path = Path(EVALS_DIR) / f"{resume_name}_evaluation.json"
            with open(eval_path, "w", encoding="utf-8") as f:
                json.dump(result, f, indent=2, ensure_ascii=False)
            print(f"✅ Saved evaluation to: {eval_path}")

        # also save a summary file
        summary_path = "all_resume_evaluations.json"
        Path(summary_path).write_text(
            json.dumps({"total_resumes": len(resume_jsons), "evaluations": all_results}, ensure_ascii=False, indent=2),
            encoding="utf-8"
        )
        print("\n" + "=" * 60)
        print("EVALUATION COMPLETE")
        print("=" * 60)
        print(f"📄 Summary saved to: {summary_path}")

    except Exception as e:
        print(f"Comparison stage error: {e}")

