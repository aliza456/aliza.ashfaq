import sqlite3
import uuid
from datetime import datetime
import random

db_path = "/home/aliza-ashfaq/Desktop/interview/Database.db"

def create_connection(db_path):
    conn = sqlite3.connect(db_path)
    return conn

def close_connection(conn):
    if conn:
        conn.close()


def create_unique_job_id():
    # Example format: JOB-YYYYMMDD-XXXX
    date_part = datetime.now().strftime("%Y%m%d")
    random_part = str(random.randint(1000, 9999))
    job_id = f"JOB-{date_part}-{random_part}"
    return job_id


def add_job(job_id ,title, description):
    conn = create_connection(db_path)
    cursor = conn.cursor()

    job_id = create_unique_job_id()
    cursor.execute("""
        INSERT INTO jobs (job_id, title, description)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (job_id, title, description))

    conn.commit()
    close_connection(conn)
    return job_id


def create_job():

    title = input("Enter job title: ")
    description = input("Enter job description: ")
    job_id = add_job(title, description)
    print(f"Job '{title}' added with ID: {job_id}")

if __name__ == "__main__":
    create_job()