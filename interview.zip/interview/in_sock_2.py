# app.py
import os, sys, json, time, asyncio, base64, uuid, re
from typing import Dict, Any, Optional, List

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi import Request
from interview_final import *
import numpy as np
import soundfile as sf
import torch
from transformers import WhisperProcessor, WhisperForConditionalGeneration
import edge_tts
import requests
from interview_final import *

GROQ_API_KEY = "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"
# ======= IMPORTANT: NEVER hardcode keys in code =======
#GROQ_API_KEY = os.getenv("GROQ_API_KEY")  # set in environment
GROQ_MODEL   = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")

SAMPLE_RATE = 16000

processor = WhisperProcessor.from_pretrained("openai/whisper-small")
whisper_model = WhisperForConditionalGeneration.from_pretrained("openai/whisper-small")


# ----------------- FastAPI Setup -----------------
app = FastAPI(title="Interview Agent - WS")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:8000",
        "http://127.0.0.1:8000"],  # tighten in prod
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
templates = Jinja2Templates(directory="templates")
app.mount("/static", StaticFiles(directory="static"), name="static") 
@app.get("/")
def home(request: Request):
    return templates.TemplateResponse("index3.html", {"request": request})

# ----------------- Audio / AI utils -----------------
def pcm16_bytes_to_float32(arr: bytes) -> np.ndarray:
    # int16 -> float32 [-1, 1]
    a = np.frombuffer(arr, dtype=np.int16).astype(np.float32) / 32768.0
    return a

def transcribe_float(audio_f32: np.ndarray, language="en") -> str:
    inputs = processor(audio_f32, sampling_rate=SAMPLE_RATE,
                       return_tensors="pt", return_attention_mask=True)
    try:
        ids = whisper_model.generate(
            inputs.input_features, attention_mask=inputs.attention_mask,
            task="transcribe", language=language
        )
    except:
        fids = processor.get_decoder_prompt_ids(language=language, task="transcribe")
        ids = whisper_model.generate(
            inputs.input_features, attention_mask=inputs.attention_mask,
            forced_decoder_ids=fids
        )
    return processor.batch_decode(ids, skip_special_tokens=True)[0].strip()


async def tts_mp3_bytes(text: str, voice: str) -> bytes:
    # edge-tts streams to a file path; to keep it simple, write->read then remove.
    fn = f"tts_{uuid.uuid4().hex}.mp3"
    try:
        communicate = edge_tts.Communicate(text=text, voice=voice)
        await communicate.save(fn)
        with open(fn, "rb") as f:
            return f.read()
    finally:
        try:
            os.remove(fn)
        except:
            pass

# ----------------- WebSocket Session -----------------
class Session:
    def __init__(self, language: str):
        self.id = uuid.uuid4().hex
        self.lang = "en" if language.lower().startswith("en") else "ur"
        self.voice = "en-US-SteffanNeural" if self.lang == "en" else "ur-PK-UzmaNeural"
        self.system_prompt = interview_prompt_en if self.lang == "en" else interview_prompt_ur
        self.messages = [{"role": "system", "content": self.system_prompt}]
        self.buffer = []  # list[np.ndarray float32], each ~20-40ms
        self.utterance_active = False   
        self.audio_frames: List[np.ndarray] = []
        self.silence_frames = 0
        self.speech_detected = False
        self.speech_frame_count = 0
        # derived thresholds from interview_final.py constants
        self.max_silence_frames = int(SILENCE_DURATION / FRAME_DURATION)
        self.min_speech_frames = int(MIN_SPEECH_DURATION / FRAME_DURATION)
        # for partial frame glue when socket delivers odd sizes
        self._partial: Optional[np.ndarray] = None
        self.conversation_history = []     # OpenAI/Groq-style [{"role":...,"content":...}, ...]
        self.conversation_context = []     # last 2 (q, a) tuples for your light context window
        self.previous_ai_question = None   # last AI question (string) for pairing with next user answer
        # (optional) keep RAG bits on the session so you don't rebuild each turn
        self.embedding_model = None
        self.index = None
        self.metadata = None


    def reset_utterance(self):
        self.buffer.clear()
        self.utterance_active = False

    def push_pcm(self, f32: np.ndarray):
        self.buffer.append(f32)

    def current_audio(self) -> Optional[np.ndarray]:
        if not self.buffer:
            return None
        return np.concatenate(self.buffer)

    def reset_vad(self):
        self.audio_frames.clear()
        self.silence_frames = 0
        self.speech_detected = False
        self.speech_frame_count = 0
        self._partial = None

    # feed PCM16->float32 chunk(s) and detect utterance boundaries ---
    # Returns: np.ndarray (float32 mono) when an utterance is complete, else None
    def process_incoming_pcm(self, f32: np.ndarray) -> Optional[np.ndarray]:
        if f32 is None or f32.size == 0:
            return None

        # Glue with any leftover from last time to make full 512-sample frames
        if self._partial is not None and self._partial.size:
            f32 = np.concatenate([self._partial, f32])
            self._partial = None

        total = f32.size
        full_frames = (total // FRAME_SIZE) * FRAME_SIZE
        remainder = total - full_frames

        if remainder > 0:
            self._partial = f32[-remainder:]
            f32 = f32[:full_frames]

        if f32.size == 0:
            return None

        frames = f32.reshape(-1, FRAME_SIZE)

        # Mirror continuous_speech_listener logic (frame-based)
        for frame in frames:
            has_speech = detect_speech_in_frame(frame)  # from interview_final.py
            if has_speech:
                if not self.speech_detected:
                    self.speech_detected = True
                self.audio_frames.append(frame)
                self.speech_frame_count += 1
                self.silence_frames = 0
            else:
                if self.speech_detected:
                    # include trailing silence for nicer turn-end context (as in original)
                    self.audio_frames.append(frame)
                    self.silence_frames += 1

                    if self.silence_frames >= self.max_silence_frames:
                        # end utterance only if we had enough speech frames
                        if self.speech_frame_count >= self.min_speech_frames:
                            audio = np.concatenate(self.audio_frames) if self.audio_frames else None
                            # reset for next utterance
                            self.reset_vad()
                            return audio
                        else:
                            # too short: treat as noise → reset but keep partials clean
                            self.reset_vad()
                else:
                    # haven't detected speech yet; just ignore leading silence
                    pass

        return None
# ----------------- WS Protocol -----------------
# Client sends JSON messages and binary frames:
# 1) {"type":"start","language":"en"|"ur"}
# 2) {"type":"utterance_start"}
# 3) (binary) PCM16@16k mono frames repeatedly
# 4) {"type":"utterance_end"} -> server STT -> LLM -> TTS -> send back
#
# Server sends:
# - {"type":"status","message":"..."}
# - {"type":"stt","text":"..."}
# - {"type":"ai_text","text":"..."}
# - binary audio with header {"type":"audio","mime":"audio/mpeg","size":...} followed by raw bytes

@app.websocket("/ws")
async def ws_handler(ws: WebSocket):
    await ws.accept()
    sess: Optional[Session] = None

    try:
        while True:
            msg = await ws.receive()  # can be {"text":..} or {"bytes":..}

            # --------- Text messages (JSON) ----------
            if "text" in msg and msg["text"] is not None:
                try:
                    data = json.loads(msg["text"])
                except json.JSONDecodeError:
                    await ws.send_text(json.dumps({"type": "status", "level":"err", "message":"Invalid JSON"}))
                    continue

                typ = data.get("type")
                if typ == "start":
                    lang = (data.get("language") or "en").lower()
                    sess = Session(lang)
                    await ws.send_text(json.dumps({"type":"status","level":"ok","message":f"session started ({sess.lang})"}))

                    # Voice + greeting
                    if sess.lang == "en":
                        sess.voice = "en-US-SteffanNeural"
                        interview_prompt = interview_prompt_en
                        greet_text = "Hello! Welcome to our interview. I am excited to learn about you. Can you please tell what brought you to datascience?"
                    else:
                        sess.voice = "ur-PK-UzmaNeural"
                        interview_prompt = interview_prompt_ur
                        greet_text = "السلام علیکم! ہم انٹرویو شروع کرتے ہیں۔"

                    # Build FAISS once per session
                    topics_dict = parse_pdf(pdf_path)
                    index, embedding_model, metadata = build_faiss_index_with_metadata(topics_dict)
                    save_index_and_metadata(index, metadata, index_path, json_path)
                    sess.index = index
                    sess.embedding_model = embedding_model
                    sess.metadata = metadata

                    # Initialize conversation history (system + assistant greeting)
                    sess.conversation_history = [
                        {"role": "system", "content": interview_prompt},
                        {"role": "assistant", "content": greet_text}
                    ]
                    sess.messages = list(sess.conversation_history)

                    # Send greeting (text + TTS)
                    await ws.send_text(json.dumps({"type":"ai_text","text":greet_text}))
                    audio_bytes = await tts_mp3_bytes(greet_text, sess.voice)
                    await ws.send_text(json.dumps({"type":"audio","mime":"audio/mpeg","size":len(audio_bytes)}))
                    await ws.send_bytes(audio_bytes)

                    # Track last AI question (if it ends with '?')
                    sess.previous_ai_question = greet_text if greet_text.strip().endswith("?") else None

                elif typ == "stop":
                    await ws.send_text(json.dumps({"type":"status","level":"ok","message":"session closed"}))
                    break

                else:
                    await ws.send_text(json.dumps({"type":"status","level":"err","message":f"unknown type {typ}"}))

            # --------- Binary messages (PCM16 frames) ----------
            elif "bytes" in msg and msg["bytes"] is not None:
                if not sess:
                    continue  # ignore until we have a session

                # PCM16 -> float32 mono [-1,1],browser sends raw PCM16 frames as binary WebSocket messages.
                #server expects mono, 16-bit little-endian PCM samples normalized to float32 in [-1,1] at 16 kHz (SAMPLE_RATE = 16000)
                f32 = pcm16_bytes_to_float32(msg["bytes"])
                #if f32.size:           #results in audio clipping
                    #f32 = np.clip(f32, -1.0, 1.0)

                # get completed utterance
                utter_audio = sess.process_incoming_pcm(f32)
                if utter_audio is None:
                    continue  # keep listening

                # 1) STT
                lang_code = "en" if sess.lang == "en" else "ur"
                user_text = transcribe_float(utter_audio, language=lang_code)
                await ws.send_text(json.dumps({"type": "stt", "text": user_text}))

                if not user_text or len(user_text.strip()) < 2:
                    await ws.send_text(json.dumps({"type": "status", "level": "warn", "message": "empty transcript"}))
                    continue

                # Persist last QA pair (AI question -> user answer)
                if sess.previous_ai_question:
                    try:
                        save_conversation_to_json(sess.previous_ai_question, user_text, conversation_filename)
                    except Exception as _:
                        # non-fatal
                        pass
                    sess.conversation_context.append((sess.previous_ai_question, user_text))
                    if len(sess.conversation_context) > 2:
                        sess.conversation_context = sess.conversation_context[-2:]

                # 2) Build FAISS/RAG context for this turn
                context = ""
                try:
                    if sess.embedding_model is not None and sess.index is not None and sess.metadata is not None:
                        similar_qs = query_faiss(user_text, sess.embedding_model, sess.index, sess.metadata, top_n=5)
                        context = "\n".join([f"- {q[0]}" for q in similar_qs]) if similar_qs else ""
                except Exception as _:
                    # non-fatal: proceed without RAG context
                    context = ""

                # 3) LLM: append user to history and call Groq once
                sess.conversation_history.append({"role":"user","content": user_text})
                ai_response, updated_history = query_groq(
                    user_input=user_text,
                    context=context,
                    conversation_history=sess.conversation_history
                )
                sess.conversation_history = updated_history
                sess.messages = list(sess.conversation_history)

                # 4) Send AI response
                await ws.send_text(json.dumps({"type": "ai_text", "text": ai_response}))

                # 5) TTS -> send mp3 bytes
                audio_bytes = await tts_mp3_bytes(ai_response, sess.voice)
                await ws.send_text(json.dumps({"type": "audio", "mime": "audio/mpeg", "size": len(audio_bytes)}))
                await ws.send_bytes(audio_bytes)

                # 6) Track last AI question for pairing with next user answer
                sess.previous_ai_question = ai_response if ai_response.strip().endswith("?") else None

    except WebSocketDisconnect:
        pass
    except Exception as e:
        try:
            await ws.send_text(json.dumps({"type":"status","level":"err","message":f"server error: {e}"}))
        except:
            pass
    finally:
        try:
            await ws.close()
        except:
            pass
