import sqlite3, os, hmac, hashlib
import pathlib
from typing import Optional
from fastapi import Query
from numpy import record
from fastapi import Request as FastAPIRequest
from fastapi import FastAPI, HTTPException, Form, File, UploadFile, APIRouter
from datetime import datetime
from fastapi.responses import HTMLResponse, FileResponse, JSONResponse, RedirectResponse
from jwt_auth import create_access_token, COOKIE_NAME, require_candidate   
from fastapi.staticfiles import StaticFiles
import asyncio
from pathlib import Path
import os
import shutil
from pydantic import BaseModel
import json
import re
import csv
from resume_wo_DB import *
from question_2 import *
import git
from read_form import *
from key_map2 import *
from fastapi.templating import Jinja2Templates


class Settings(BaseModel):
    CSV_PATH: str = "ml_interview_questions_Q1_to_Q10.csv"   # questions CSV
    OUTPUT_DIR: str = "tests"                         # where PDFs will be saved
    DEFAULT_MIN_Q: int = 4
    DEFAULT_MAX_Q: int = 5
    TITLE: str = "DSA Assessment"

settings = Settings()
os.makedirs(settings.OUTPUT_DIR, exist_ok=True)
DB_PATH = os.getenv("DB_PATH", "/home/aliza-ashfaq/Desktop/interview/Database.db")
TOKEN_PEPPER = os.getenv("TOKEN_PEPPER", "change-this-pepper")

app = FastAPI()
templates = Jinja2Templates(directory="templates")  # Add this line

api = APIRouter(prefix="/api")

UPLOADS_DIR = "/home/aliza-ashfaq/Desktop/interview/uploads" # or your actual path
UPLOADS_DIR = Path(UPLOADS_DIR)
os.makedirs(UPLOADS_DIR, exist_ok=True)


def _db():
    return sqlite3.connect(DB_PATH)

def _h(raw: str) -> str:
    return hmac.new(TOKEN_PEPPER.encode(), raw.encode(), hashlib.sha256).hexdigest()


# Basic GitHub URL validation
GH_REGEX = re.compile(r"^https?://(www\.)?github\.com/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+/?$")


def read_github_urls_from_responses(repo_submission: dict) -> str:
   
    repo_url = repo_submission.get("repo_url")
    if not repo_url:
        raise ValueError("No repository URL found in submission.")

    repo_url = repo_url.strip()
    if not GH_REGEX.match(repo_url):
        raise ValueError(f"Invalid GitHub URL: {repo_url}")

    return repo_url

def _append_jsonl(path: str, data: dict):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(data, ensure_ascii=False) + "\n")

    """
    Serves the dashboard with 3 buttons (Resume Drop, Interview, Test).
    Make sure dashboard.html exists in the same static directory.
    """
    return FileResponse("dashboard.html")

# @app.post("/api/login")
# async def candidate_login(request: Request):
#     print("Login API called!")
#     data = await request.json()
#     cid = data.get("candidate_id")
#     password = data.get("password")

#     if not cid or not password:
#         raise HTTPException(status_code=400, detail="Missing candidate_id or password")

#     con = _db()
#     cur = con.cursor()
#     cur.execute("""
#         SELECT candidate_id, email_address, password
#           FROM candidates
#          WHERE candidate_id = ?;
#     """, (cid,))
#     row = cur.fetchone()
#     con.close()

#     if not row:
#         raise HTTPException(status_code=404, detail="Candidate not found")

#     candidate_id, email, stored_pw = row

#     if stored_pw != password:
#         raise HTTPException(status_code=401, detail="Incorrect password")

#     # Create JWT (same as before)
#     access_token = create_access_token(candidate_id=str(candidate_id))

#     print(f"JWT generated for {candidate_id}")
#     return JSONResponse({
#         "status": "ok",
#         "message": "Login successful",
#         "candidate_id": candidate_id,
#         "access_token": access_token
#     })


# --- helper to make sure JD is extracted ---
def safe_id(s: str) -> str:
    return "".join(c for c in s if c.isalnum() or c in "-_.") or "candidate"

def ensure_jd_extracted():
    if not os.path.exists(JD_JSON_FILE):
        print("Extracting JD first...")
        # convert JD.pdf → stitched image → extract JSON
        import pymupdf, io
        from PIL import Image

        doc = pymupdf.open(JD_PDF)
        pages = []
        for p in doc:
            img = Image.open(io.BytesIO(p.get_pixmap(dpi=300).tobytes("png")))
            path = f"page_{p.number + 1}.png"
            img.save(path)
            pages.append(path)
        doc.close()

        stitched = stitch_vertical(sorted(pages), out_path="stitched_JD.png")
        jd_text = groq_extract_from_image_JD(stitched)
        save_json_result(jd_text, JD_JSON_FILE)
    else:
        print("JD already extracted.")

@app.get("/")
async def root():
    return RedirectResponse(url="/login")

@app.get("/login", response_class=HTMLResponse)
async def serve_login_page():
    return FileResponse("static/login_page.html")

@app.get("/dashboard", response_class=HTMLResponse)
async def serve_dashboard_page():
    return FileResponse("static/dashboard.html")

@app.post("/resume_drop")
async def resume_drop(request1 : FastAPIRequest,name: str = Form(...), email: str = Form(...), resume: UploadFile = Form(...)):
    ext = pathlib.Path(resume.filename).suffix.lower()
    if ext != ".pdf":
        return HTMLResponse("Please upload a PDF resume only.", status_code=400)

    safe_name = "".join(c for c in name if c.isalnum() or c in "-_") or "candidate"
    pdf_path = UPLOADS_DIR / f"{safe_name}.pdf"

    # 1. save uploaded file
    with pdf_path.open("wb") as f:
        shutil.copyfileobj(resume.file, f)
    print(f"✅ Saved resume: {pdf_path}")

    # 2. ensure JD JSON exists
    ensure_jd_extracted()

    # 3. extract info from resume
    import pymupdf, io
    from PIL import Image
    doc = pymupdf.open(str(pdf_path))
    page_imgs = []
    for p in doc:
        img = Image.open(io.BytesIO(p.get_pixmap(dpi=300).tobytes("png")))
        out = f"{safe_name}_page_{p.number+1}.png"
        img.save(out)
        page_imgs.append(out)
    doc.close()

    stitched_resume = f"stitched_resume_{safe_name}.png"
    stitch_vertical(sorted(page_imgs), out_path=stitched_resume)
    res_text = groq_extract_from_image_resume(stitched_resume)
    res_json_path = Path(RESUMES_JSON_DIR) / f"{safe_name}.json"
    save_json_result(res_text, res_json_path)

    # 4. compare with JD
    jd_obj, _ = load_jd_file(JD_JSON_FILE)
    with open(res_json_path, "r", encoding="utf-8") as f:
        res_obj = json.load(f)
    result = compare_with_llm(jd_obj, res_obj)
    eval_path = Path(EVALS_DIR) / f"{safe_name}_evaluation.json"
    with open(eval_path, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, ensure_ascii=False)

    final_score = result.get("final_score", {}).get("value", 0)

    # optional: extract score for display
    project_score = result.get("Projects", {}).get("score", 0)
    education_score = result.get("Educational Background", {}).get("score", 0)
    work_exp = result.get("Work Experience", {}).get("score", 0)
    techskills = result.get("Technical Skills", {}).get("score", 0)
    cert = result.get("Related Certifications", {}).get("score", 0)

    params = {
        "request": request1,
        "name": safe_name,
        "email": email,
        "score": final_score,
        "project_score": project_score,
        "education_score": education_score,
        "work_exp": work_exp,
        "techskills": techskills,
        "cert": cert
    }
    
    # 5. render template with scores
    return templates.TemplateResponse("resume_results.html", params)
@app.post("/generate-test")
def generate_test_pdf(
    candidate_id: str = Form(...),
    min_q: int = Form(settings.DEFAULT_MIN_Q),
    max_q: int = Form(settings.DEFAULT_MAX_Q),
    seed: int | None = Form(None),
    title: str = Form(settings.TITLE),
    force_new: bool = Form(False),
):
    """Generates a PDF for this candidate and returns a URL you can embed."""
    if min_q > max_q:
        raise HTTPException(400, "min_q cannot be greater than max_q")


    # Sanitize candidate_id for filesystem/URL safety
    safe_candidate_id = "".join(c for c in candidate_id if c.isalnum() or c in "-_.") or "candidate"
    
    # Check if candidate already has a test
    cand_dir = Path("tests") / safe_candidate_id
    assessment_file = cand_dir / "assessment_data.json"
    latest_pdf = cand_dir / "latest.pdf"
    
    # If test exists and force_new is False, return existing test
    if not force_new and assessment_file.exists() and latest_pdf.exists():
        try:
            with open(assessment_file, 'r', encoding='utf-8') as f:
                existing_data = json.load(f)
            
            if existing_data.get("assessments"):
                latest_assessment = existing_data["assessments"][-1]
                existing_pdf_path = latest_assessment.get("pdf_path", "")
                
                if existing_pdf_path:
                    filename = Path(existing_pdf_path).name
                else:
                    filename = "latest.pdf"
                
                pdf_url = f"/tests/{safe_candidate_id}/{filename}"
                
                return {
                    "candidate_id": candidate_id,
                    "safe_candidate_id": safe_candidate_id,
                    "count": len(latest_assessment.get("questions", {})),
                    "pdf_url": pdf_url,
                    "message": "Existing test returned (use force_new=true to generate new test)",
                    "is_existing": True
                }
        except Exception as e:
            print(f"[warning] Error reading existing test: {e}, generating new test")

    # Generate new test
    cand_dir.mkdir(parents=True, exist_ok=True)
    
    try:
        questions = load_question_bank(CSV_PATH)
        
        # Get UNIQUE question texts only
        unique_questions = {}
        QTEXT_TO_CSVIDS = {}
        
        for csv_id, question_data in questions.items():
            question_text = question_data.get("question", "")
            if question_text:
                # Only add if we haven't seen this text before
                if question_text not in unique_questions:
                    unique_questions[question_text] = question_data
                
                # Map question text to its CSV ID(s)
                if question_text not in QTEXT_TO_CSVIDS:
                    QTEXT_TO_CSVIDS[question_text] = []
                QTEXT_TO_CSVIDS[question_text].append(csv_id)
        
        # Pick random questions from unique texts
        all_unique_texts = list(unique_questions.keys())
        num_questions = random.randint(min_q, max_q)
        picked = random.sample(all_unique_texts, min(num_questions, len(all_unique_texts)))
        
    except Exception as e:
        print(f"Error in question loading: {e}")
        raise HTTPException(500, f"Failed to pick questions: {e}")

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    unique_test_id = f"{safe_candidate_id}_{ts}"
    filename = f"ml_quiz_{unique_test_id}.pdf"
    pdf_path = cand_dir / filename

    # Initialize assessments store
    assessments_store = {"assessments": []}
    
    # Load existing assessments if file exists
    if assessment_file.exists():
        try:
            with open(assessment_file, 'r', encoding='utf-8') as f:
                assessments_store = json.load(f)
        except Exception:
            assessments_store = {"assessments": []}
    
    picked_mapping = {
        f"Q{i}": {
            "csv_ids": QTEXT_TO_CSVIDS.get(q, []),
            "text": q
        }
        for i, q in enumerate(picked, 1)
    }

    # Append new assessment
    assessments_store["assessments"].append({
        "candidate_id": candidate_id,
        "questions": picked_mapping,
        "pdf_path": str(pdf_path),
        "generated_at": datetime.now().isoformat()
    })

    try:
        # Create PDF using the save_pdf function from question_2.py
        created_pdf_path = save_pdf(picked, title=unique_test_id, out_path=str(pdf_path), candidate_id=candidate_id)
        print(f"PDF created at: {created_pdf_path}")
        
        # Update latest.pdf symlink
        if latest_pdf.exists():
            latest_pdf.unlink()
        latest_pdf.write_bytes(pdf_path.read_bytes())

        # Save assessment data
        with open(assessment_file, "w", encoding="utf-8") as f:
            json.dump(assessments_store, f, indent=2, ensure_ascii=False)
        print(f"Assessment data saved to: {assessment_file}")
        
    except Exception as e:
        print(f"Error creating PDF: {e}")
        raise HTTPException(500, f"Failed to create PDF: {e}")

    pdf_url = f"/tests/{safe_candidate_id}/{filename}"

    return {
        "candidate_id": candidate_id,
        "safe_candidate_id": safe_candidate_id,
        "count": len(picked),
        "pdf_url": pdf_url,
        "message": "New PDF generated",
        "is_existing": False
    }
 
    
@app.post("/test-candidate",response_class=HTMLResponse)
def api_test_candidate(
    request : FastAPIRequest,
    candidate_id: str = Form(...),
    repo_url: str = Form(...),
    branch: str = Form("main"),
    force_reclone: bool = Form(True),
    include_failed_cases: bool = Form(True),
    include_passed_cases: bool = Form(True),  # Add this parameter
):
    if not GH_REGEX.match(repo_url):
       raise HTTPException(status_code=400, detail="Invalid GitHub repo URL.")
    
    repo_path = clone_repo(repo_url, branch, CLONED_REPOS_DIR, force_reclone=force_reclone)
    # mapping
    mapping = extract_mapping_for_candidate(candidate_id)
    if not mapping:
        raise HTTPException(status_code=404, detail=f"No assessment mapping found for '{candidate_id}'.")

    if not CSV_PATH.exists():
        raise HTTPException(status_code=500, detail=f"Question CSV not found at {CSV_PATH}")
    qbank = load_question_bank(CSV_PATH)
    # run
    results = run_tests_from_mapping(repo_path, mapping, qbank)
    
    # Process results to include/exclude case details as requested
    if not include_failed_cases:
        for q, r in results.get("questions", {}).items():
            if isinstance(r.get("test_details"), dict):
                r["test_details"]["failed_cases"] = []
    
    if not include_passed_cases:
        for q, r in results.get("questions", {}).items():
            if isinstance(r.get("test_details"), dict):
                r["test_details"]["passed_cases"] = []
    
    # Calculate stats
    total_files = len(results.get("questions", {}))
    passed = 0
    failed = 0
    
    for question_id, question_result in results.get("questions", {}).items():
        if question_result.get("status") == "passed":
            passed += 1
        else:
            failed += 1
    
    safe_candidate_id = "".join(c for c in candidate_id if c.isalnum() or c in "-_") or "candidate"
    results_dir = Path("test_results")
    results_dir.mkdir(exist_ok=True)
    
    results_file = results_dir / f"{safe_candidate_id}_results.json"
    
    full_results = {
        "candidate_id": candidate_id,
        "repo_name": repo_path.name,
        "repo_url": repo_url,
        "branch": branch,
        "status": "completed",
        "results": {
            "total_files": total_files,
            "files_tested": results.get("files_tested", 0),
            "files_passed": passed,
            "files_failed": failed,
            "questions": results.get("questions", {})
        },
        "tested_at": datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
    }
    
    # Save to file
    with open(results_file, 'w', encoding='utf-8') as f:
        json.dump(full_results, f, indent=2, ensure_ascii=False)
    
    print(f"Test results saved to: {results_file}")
    
    total_failed_cases = 0
    for question_data in results.get("questions", {}).values():
        test_details = question_data.get("test_details", {})
        failed_cases = test_details.get("failed_cases", [])
        total_failed_cases += len(failed_cases)
    
    # Prepare template context
    context = {
        "request": request,
        "candidate_id": candidate_id,
        "repo_name": repo_path.name,
        "repo_url": repo_url,
        "branch": branch,
        "status": "completed",
        "tested_at": full_results["tested_at"],
        "total_files": total_files,
        "files_tested": results.get("files_tested", 0),
        "passed_files": passed,
        "failed_files": failed,
        "questions": results.get("questions", {}),
        "total_failed_cases": total_failed_cases
    }
    
    return templates.TemplateResponse("test_results.html", context)


@app.get("/interview")
def interview(name: str, score: int):
    return {"ok": True, "name": name, "score": score}

# Add all your HTML page routes
@app.get("/resume_drop", response_class=HTMLResponse)
async def serve_resume_drop_page():
    return FileResponse("static/resume_drop.html")

@app.get("/test", response_class=HTMLResponse)
async def serve_test_page():
    return FileResponse("static/test.html")


app.mount("/tests", StaticFiles(directory="tests"), name="tests")
app.mount("/", StaticFiles(directory="static", html=True), name="static")
