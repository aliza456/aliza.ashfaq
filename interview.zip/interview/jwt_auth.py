# jwt_auth.py
import os, jwt
from datetime import datetime, timedelta, timezone
from app import HTTPException, Request

JWT_SECRET = os.getenv("JWT_SECRET", "f8e3b66d43b848fdb7c1a8ffefae5e0a9b72b1ab3b0f44ce89d8b5c7b7f2c0ac")
JWT_ALG = os.getenv("JWT_ALG", "HS256")
ACCESS_TOKEN_EXPIRE_MIN = int(os.getenv("ACCESS_TOKEN_EXPIRE_MIN", "120"))
COOKIE_NAME = "access_token"

def create_access_token(candidate_id: str) -> str:
    now = datetime.now(timezone.utc)
    payload = {
        "sub": candidate_id,
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MIN)).timestamp()),
        "typ": "access",
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALG)

def require_candidate(request: Request) -> str:
    token = request.cookies.get(COOKIE_NAME)
    if not token:
        raise HTTPException(status_code=401, detail="Not authenticated")
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALG])
        cid = payload.get("sub")
        if not cid:
            raise HTTPException(status_code=401, detail="Invalid token")
        return cid
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Session expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")
