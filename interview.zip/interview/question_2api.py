# api_send_assessments.py
# pip install fastapi uvicorn pydantic-settings

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import question_2  # <--- import your logic file

app = FastAPI(title="Step 1: Send Assessment PDFs", version="1.0.0")

class SendRequest(BaseModel):
    limit: int = 3
    min_q: int = 4
    max_q: int = 5
    seed: int | None = None

@app.get("/health")
def health():
    return {"ok": True}

@app.post("/send")
def send_assessments_api(req: SendRequest):
    """API endpoint that triggers the PDF generation and email sending"""
    try:
        result = question_2.main(limit=req.limit, min_q=req.min_q, max_q=req.max_q, seed=req.seed)
        return {"status": "success", "result": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("api_send_assessments:app", host="0.0.0.0", port=8000, reload=True)
