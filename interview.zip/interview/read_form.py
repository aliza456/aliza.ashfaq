import os, json
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from google.auth.transport.requests import Request
import git

SCOPES = ["https://www.googleapis.com/auth/gmail.send","https://www.googleapis.com/auth/forms.responses.readonly"]
FORM_ID = "1mo_5-XMT8_hTKGj9D-ddWTh3cWBvNe7RKNJuQjKePbo"

def get_creds():
    # Check for existing token file first
    creds = None
    if os.path.exists("token.json"):
        creds = Credentials.from_authorized_user_file("token.json", SCOPES)
    
    # If we have credentials but they're expired and have a refresh token
    if creds and creds.expired and creds.refresh_token:
        try:
            creds.refresh(Request())
            # Save refreshed credentials
            with open("token.json", "w") as f:
                f.write(creds.to_json())
        except Exception as e:
            print(f"Error refreshing token: {e}")
            creds = None
    
    # If no valid credentials available, get new ones
    if not creds or not creds.valid:
        flow = InstalledAppFlow.from_client_secrets_file("client_secret_993249251770-39ot8taj89kdptcqqgdii5pjerprid2u.apps.googleusercontent.com.json", SCOPES)
        creds = flow.run_local_server(port=0)  # opens browser to consent with Forms scope
        with open("token.json", "w") as f:
            f.write(creds.to_json())
    
    return creds

def list_all_responses(form_id):
    creds = get_creds()
    svc = build("forms", "v1", credentials=creds)
    out, token = [], None
    try:
        while True:
            resp = svc.forms().responses().list(formId=form_id, pageToken=token).execute()
            out.extend(resp.get("responses", []))
            token = resp.get("nextPageToken")
            if not token:
                break
        return out
    except Exception as e:
        print(f"Error getting responses: {e}")
        return []

def read_github_urls_from_responses(jsonl_file="form_responses.jsonl"):
    """
    Read the JSONL file of form responses and extract GitHub repository URLs.
    Returns a list of URLs found in the responses.
    """
    github_urls = []
    
    try:
        with open(jsonl_file, 'r', encoding='utf-8') as f:
            for line in f:
                try:
                    # Parse each JSON line
                    response = json.loads(line)
                    
                    # Process the response structure to find GitHub URLs
                    # This will depend on how your form is structured
                    answers = response.get('answers', {})
                    
                    # Loop through all answers to find GitHub URL field
                    for question_id, answer_data in answers.items():
                        answer_value = answer_data.get('textAnswers', {}).get('answers', [])
                        for answer in answer_value:
                            value = answer.get('value', '')
                            # Simple check for GitHub URLs
                            if 'github.com' in value.lower():
                                github_urls.append(value)
                                break
                                
                except json.JSONDecodeError:
                    print(f"Warning: Couldn't parse JSON line: {line[:50]}...")
                    continue
                except Exception as e:
                    print(f"Error processing response: {e}")
                    continue
                    
        return github_urls
        
    except FileNotFoundError:
        print(f"File not found: {jsonl_file}")
        return []


def clone_github_repos(urls, target_dir="cloned_repos"):
    """
    Clone GitHub repositories from a list of URLs using GitPython
    """
    # Create target directory if it doesn't exist
    if not os.path.exists(target_dir):
        os.makedirs(target_dir)
    
    results = []
    
    for url in urls:
        # Extract repo name from URL
        repo_name = url.rstrip('/').split('/')[-1]
        if repo_name.endswith('.git'):
            repo_name = repo_name[:-4]
            
        # Get username as well for uniqueness
        username = url.rstrip('/').split('/')[-2]
        repo_dir = os.path.join(target_dir, f"{username}_{repo_name}")
        
        # Skip if already cloned
        if os.path.exists(repo_dir):
            print(f"Repository already exists: {repo_dir}")
            results.append({"url": url, "status": "already_exists", "path": repo_dir})
            continue
        
        # Clone the repository
        try:
            print(f"Cloning {url} to {repo_dir}...")
            git.Repo.clone_from(url, repo_dir)
            results.append({"url": url, "status": "success", "path": repo_dir})
            print(f"Successfully cloned {url}")
        except git.GitCommandError as e:
            print(f"Failed to clone {url}: {e}")
            results.append({"url": url, "status": "error", "error": str(e)})
    
    return results

# Example usage
# Complete main function for the script
if __name__ == "__main__":
    # Step 1: Fetch form responses
    data = list_all_responses(FORM_ID)
    print(f"Fetched {len(data)} responses")
    
    # Step 2: Save responses to JSONL file
    with open("form_responses.jsonl", "w", encoding="utf-8") as f:
        for r in data:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
            
    # Step 3: Extract GitHub URLs from responses
    github_urls = read_github_urls_from_responses()
    print(f"Found {len(github_urls)} GitHub URLs:")
    for url in github_urls:
        print(f"- {url}")
        
    # Step 4: Clone repositories if any URLs were found
    if github_urls:
        clone_results = clone_github_repos(github_urls)
        print(f"\nCloning results:")
        for result in clone_results:
            if result["status"] == "success":
                print(f"✅ {result['url']} -> {result['path']}")
            elif result["status"] == "already_exists":
                print(f"⚠️ {result['url']} -> {result['path']} (already exists)")
            else:
                print(f"❌ {result['url']} -> {result['status']}")
    else:
        print("No GitHub URLs found to clone.")