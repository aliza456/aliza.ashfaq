
const candidateId = localStorage.getItem('candidateId');
const accessToken = localStorage.getItem('accessToken');

if (!candidateId) {
  alert('Please login first');
  window.location.href = 'login_page.html';
}

// Use candidateId in your WebSocket connection or interview logic
console.log('Starting interview for candidate:', candidateId);

class InterviewClient {
    constructor() {
        this.socket = null;
        this.isConnected = false;
        this.isStreaming = false;
        
        // VAD properties
        this.audioContext = null;
        this.mediaStream = null;
        this.processor = null;
        this.vadActive = false;
        
        this.initializeElements();
        this.setupEventListeners();
    }
    
    initializeElements() {
        // Add all the missing DOM element references
        this.statusDiv = document.getElementById('status');
        this.connectBtn = document.getElementById('connectBtn');
        this.startBtn = document.getElementById('startBtn');
        this.conversationDiv = document.getElementById('conversation');
        this.audioPlayer = document.getElementById('audioPlayer');
        
        // Add error checking for required elements
        if (!this.statusDiv) {
            console.error('Missing element: status');
        }
        if (!this.connectBtn) {
            console.error('Missing element: connectBtn');
        }
        if (!this.startBtn) {
            console.error('Missing element: startBtn');
        }
        if (!this.conversationDiv) {
            console.error('Missing element: conversation');
        }
    }
    
    setupEventListeners() {
        if (this.connectBtn) {
            this.connectBtn.addEventListener('click', () => this.connect());
        }
        if (this.startBtn) {
            this.startBtn.addEventListener('click', () => this.startInterview());
        }
    }

    connect() {
        try {
            const socket = new WebSocket(`${location.origin.replace('http', 'ws')}/ws`);

            socket.onopen = () => {
                this.isConnected = true;
                this.updateStatus('Connected to interview server', 'connected');

                if (candidateId) {
                    console.log('Sending candidate ID to server:', candidateId);
                    this.socket.send(JSON.stringify({
                        type: 'set_candidate',
                        candidate_id: candidateId
                    }));
                }
    
                if (this.connectBtn) this.connectBtn.disabled = true;
                if (this.startBtn) this.startBtn.disabled = false;
                console.log('WebSocket connected');
            };
            
            this.socket.onmessage = (event) => {
                const data = JSON.parse(event.data);
                this.handleServerMessage(data);
            };
            
            this.socket.onclose = () => {
                this.isConnected = false;
                this.updateStatus('Disconnected from server', 'disconnected');
                if (this.connectBtn) this.connectBtn.disabled = false;
                if (this.startBtn) this.startBtn.disabled = true;
                this.cleanup();
                console.log('WebSocket disconnected');
            };
            
            this.socket.onerror = (error) => {
                console.error('WebSocket error:', error);
                this.addMessage('Connection error occurred', 'error');
            };
            
        } catch (error) {
            console.error('Failed to connect:', error);
            this.addMessage('Failed to connect to server', 'error');
        }
    }
    
    async startInterview() {
        if (!this.isConnected) return;
        
        this.addMessage('Starting interview...', 'system');
        this.socket.send(JSON.stringify({
            type: 'get_greeting'
        }));
        
        if (this.startBtn) this.startBtn.disabled = true;
        
        // Initialize continuous audio streaming
        await this.initializeAudioStreaming();
    }
    
    async initializeAudioStreaming() {
        try {
            console.log('Requesting microphone access...');
            
            this.mediaStream = await navigator.mediaDevices.getUserMedia({
                audio: {
                    sampleRate: 16000,
                    channelCount: 1,
                    echoCancellation: true,
                    noiseSuppression: true,
                    autoGainControl: true
                }
            });
            
            this.audioContext = new (window.AudioContext || window.webkitAudioContext)({
                sampleRate: 16000
            });
            
            if (this.audioContext.state === 'suspended') {
                await this.audioContext.resume();
            }
            
            const source = this.audioContext.createMediaStreamSource(this.mediaStream);
            
            // Create processor for frame-based streaming (512 samples = 32ms frames)
            this.processor = this.audioContext.createScriptProcessor(512, 1, 1);
            source.connect(this.processor);
            this.processor.connect(this.audioContext.destination);
            
            this.processor.onaudioprocess = (event) => {
                this.processAudioFrame(event);
            };
            
            this.vadActive = true;
            this.isStreaming = true;
            this.updateStatus('🟢 Streaming audio to server...', 'streaming');
            console.log('Audio streaming initialized');
            
        } catch (error) {
            console.error('Error initializing audio streaming:', error);
            this.addMessage('Error accessing microphone. Please check permissions.', 'error');
            this.updateStatus('Microphone access denied', 'error');
        }
    }
    
    processAudioFrame(event) {
        if (!this.isStreaming || !this.socket || this.socket.readyState !== WebSocket.OPEN) {
            return;
        }
        
        const inputBuffer = event.inputBuffer;
        const inputData = inputBuffer.getChannelData(0);
        
        // Convert to the format expected by server (Float32Array)
        const audioFrame = new Float32Array(inputData);
        
        // Send frame to server for VAD processing
        this.sendAudioFrame(audioFrame);
    }
    
    sendAudioFrame(audioFrame) {
        try {
            const audioBase64 = this.arrayBufferToBase64(audioFrame.buffer);
            
            this.socket.send(JSON.stringify({
                type: 'audio_stream',
                audio: audioBase64
            }));
            
        } catch (error) {
            console.error('Error sending audio frame:', error);
        }
    }
    
    handleServerMessage(data) {
        console.log('Received from server:', data.type);
        
        switch (data.type) {
            case 'candidate_set':
                console.log('Candidate ID confirmed by server:', data.candidate_id);
                console.log('Session ID assigned:', data.session_id);
                break;
            case 'ai_response':
                this.handleAIResponse(data);
                break;
            case 'transcription':
                console.log('Transcription received:', data.text);
                this.updateStatus('🟡 Processing your speech...', 'processing');
                break;
            case 'recording_status':
                if (data.recording) {
                    this.updateStatus('🔴 Recording detected...', 'recording');
                } else if (data.processing) {
                    this.updateStatus('🟡 Processing speech...', 'processing');
                } else {
                    this.updateStatus('🟢 Listening...', 'listening');
                }
                break;
            case 'processing_status':
                if (!data.processing) {
                    this.updateStatus('🟢 Ready for next input...', 'listening');
                }
                break;
            case 'error':
                this.addMessage(`Error: ${data.message}`, 'error');
                this.updateStatus('🟢 Listening...', 'listening');
                break;
            case 'pong':
                console.log('Pong received');
                break;
            // inside handleServerMessage switch:
            case 'stop_ai':
                if (this.currentAudio) {
                    try { this.currentAudio.pause(); } catch {}
                    try { this.currentAudio.src = ''; } catch {}
                    this.currentAudio = null;
                }
            this.updateStatus('🔴 Interruption detected — listening…', 'recording');
            break;

        }
    }
    
    async handleAIResponse(data) {
        // Add user input to conversation if present
        if (data.user_input) {
            this.addMessage(data.user_input, 'user');
        }
        
        // Add AI response to conversation
        this.addMessage(data.text, 'ai');
        
        // Play AI audio response
        if (data.audio) {
            await this.playAudio(data.audio);
        }
        
        // Update status to show ready for next input
        this.updateStatus('🟢 Listening...', 'listening');
    }
    
    async playAudio(audioBase64) {
        try {
            console.log('[CLIENT] Starting audio playback');
            
            // Stop any existing audio first
            if (this.currentAudio) {
                console.log('[CLIENT] Stopping existing audio');
                try { this.currentAudio.pause(); } catch {}
                try { this.currentAudio.src = ''; } catch {}
                this.currentAudio = null;
            }

            const audioBytes = this.base64ToArrayBuffer(audioBase64);
            const audioBlob = new Blob([audioBytes], { type: 'audio/mpeg' });
            const audioUrl = URL.createObjectURL(audioBlob);

            const audio = new Audio(audioUrl);
            this.currentAudio = audio; // Set reference BEFORE playing
            
            console.log('[CLIENT] Audio object created and reference set');

            audio.onended = () => {
                console.log('[CLIENT] Audio playback ended naturally');
                URL.revokeObjectURL(audioUrl);
                this.currentAudio = null;
                // Tell server AI finished speaking
                if (this.socket && this.socket.readyState === WebSocket.OPEN) {
                    this.socket.send(JSON.stringify({ type: 'ai_done' }));
                }
            };

        audio.onerror = (e) => {
            console.error('[CLIENT] Audio playback error:', e);
            URL.revokeObjectURL(audioUrl);
            this.currentAudio = null;
        };

        // Set volume and play
        audio.volume = 0.8;
        await audio.play();
        console.log('[CLIENT] Audio playback started');
        
    } catch (e) {
        console.error('[CLIENT] Error playing audio:', e);
        this.addMessage('Error playing AI response audio', 'error');
        this.currentAudio = null;
    }
}

    
    addMessage(text, type) {
        // Add safety check for conversationDiv
        if (!this.conversationDiv) {
            console.error('conversationDiv not found, cannot add message:', text);
            return;
        }
        
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${type}`;
        
        const timestamp = new Date().toLocaleTimeString();
        const label = type === 'ai' ? 'AI:' : type === 'user' ? 'You:' : 'System:';
        messageDiv.innerHTML = `<span class="timestamp">[${timestamp}]</span> <strong>${label}</strong> ${text}`;
        
        this.conversationDiv.appendChild(messageDiv);
        this.conversationDiv.scrollTop = this.conversationDiv.scrollHeight;
    }
    
    updateStatus(message, className) {
        // Add safety check for statusDiv
        if (!this.statusDiv) {
            console.error('statusDiv not found, cannot update status:', message);
            return;
        }
        
        this.statusDiv.textContent = message;
        this.statusDiv.className = `status ${className}`;
    }
    
    arrayBufferToBase64(buffer) {
        const bytes = new Uint8Array(buffer);
        let binary = '';
        for (let i = 0; i < bytes.byteLength; i++) {
            binary += String.fromCharCode(bytes[i]);
        }
        return btoa(binary);
    }
    
    base64ToArrayBuffer(base64) {
        const binaryString = atob(base64);
        const bytes = new Uint8Array(binaryString.length);
        for (let i = 0; i < binaryString.length; i++) {
            bytes[i] = binaryString.charCodeAt(i);
        }
        return bytes.buffer;
    }
    
    cleanup() {
        this.vadActive = false;
        this.isStreaming = false;
        
        if (this.processor) {
            this.processor.disconnect();
            this.processor = null;
        }
        if (this.mediaStream) {
            this.mediaStream.getTracks().forEach(track => track.stop());
            this.mediaStream = null;
        }
        if (this.audioContext) {
            this.audioContext.close();
            this.audioContext = null;
        }
        
        console.log('Audio streaming cleanup completed');
    }
}

// Initialize when page loads
document.addEventListener('DOMContentLoaded', () => {
    console.log('Initializing Interview Client with Server-side VAD');
    new InterviewClient();
});