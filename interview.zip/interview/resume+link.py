from groq import Groq
import base64, os
from pathlib import Path
import pymupdf,io
from PIL import Image
from pathlib import Path
import json
import ollama
import sqlite3
import uuid, hmac, hashlib
from datetime import datetime, timedelta
import secrets
import string
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
import smtplib
from email.message import EmailMessage
from email.mime.text import MIMEText
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
import os, base64, mimetypes

GROQ_API_KEY = "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"
client = Groq(api_key=GROQ_API_KEY)
SCOPES = ["https://www.googleapis.com/auth/gmail.send","https://www.googleapis.com/auth/forms.responses.readonly"]

db_path = "/home/aliza-ashfaq/Desktop/interview/Database.db"
BASE_URL = os.getenv("BASE_URL", "http://127.0.0.1:8000")
TOKEN_TTL_HOURS = int(os.getenv("TOKEN_TTL_HOURS", "24"))
TOKEN_PEPPER = os.getenv("TOKEN_PEPPER", "change-this-pepper")

MODEL = "gemma3:4b"        
JD_FILE_CANDIDATES = "jd_extraction.json"

Resumes = "extracted_resumes"
os.makedirs(Resumes, exist_ok=True)


# def retrieve_resumes_from_db():
#     """Retrieve all resumes from the database"""
#     conn = sqlite3.connect(db_path)
#     cursor = conn.cursor()
#     cursor.execute('SELECT candidate_id, email_address, resume_filename, resume_filepath FROM candidates')
#     rows = cursor.fetchall()
    
#     resumes = []
#     for row in rows:
#         resumes.append({
#             "candidate_id": row[0],
#             "email_address": row[1],
#             "resume_filename": row[2],
#             "resume_filepath": row[3]
#         })
    
#     conn.close()
#     return resumes


def encode_image(path: str) -> str:
    with open(path, "rb") as f:
        return base64.b64encode(f.read()).decode("utf-8")


def stitch_vertical(image_paths, out_path="stitched.png", bg="white"):
    imgs = [Image.open(p).convert("RGB") for p in image_paths]
    # normalize widths to the widest image
    maxw = max(im.width for im in imgs)
    norm = [ (im if im.width == maxw
              else im.resize((maxw, int(im.height * maxw / im.width)), Image.LANCZOS))
             for im in imgs ]
    total_h = sum(im.height for im in norm)
    canvas = Image.new("RGB", (maxw, total_h), color=bg)
    y = 0
    for im in norm:
        canvas.paste(im, (0, y)); y += im.height
    canvas.save(out_path)
    print(out_path)
    return out_path


def groq_extract_from_image_JD(image_path: str, model: str = "meta-llama/llama-4-scout-17b-16e-instruct") -> str:
    try:
        # Encode image to base64
        base64_image = encode_image(image_path)
        
        system_prompt = "You are a strict information extractor. Your task is to extract ALL relevant information from the image. Output ONLY valid JSON per the schema. No extra text or prose."
        
        user_prompt =  """
            - Extract job overview, responsibilities , required tools, and qualifications from the image.
            - Use all the valid details from the image to populate the JSON fields.
            - Do not write "```json" in your response.
            """

        response = client.chat.completions.create(
            model=model,
            messages=[
                {
                    "role": "system",
                    "content": system_prompt
                },
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": user_prompt
                        },
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/png;base64,{base64_image}"
                            }
                        }
                    ]
                }
            ],
            temperature=0,
            max_tokens=2048
        )
        
        return response.choices[0].message.content
        
    except Exception as e:
        print(f"An error occurred while processing JD {image_path}: {e}")
        return None
    

def groq_extract_from_image_resume(image_path: str, model: str = "meta-llama/llama-4-scout-17b-16e-instruct") -> str:
    try:
        # Encode image to base64
        base64_image = encode_image(image_path)
        
        system_prompt = "You are a precise information extractor. Extract ALL visible information from the resume image. Output ONLY valid JSON per the schema with NO extra text."
        
        user_prompt =  """
            - Extract EVERY Projects, Work Experience, Education, Skills, certifications and Technologies.
            - Extract ALL RELEVANT details from this résumé image.
            - Output a JSON object with keys: name, email, phone, education (list of {degree, institution, year}), Work Experience (list of {job_title, company, start_date, end_date, responsibilities}), Skills (list), Technologies (list).
            - Do not write "```json" in your response.
            """
        response = client.chat.completions.create(
            model=model,
            messages=[
                {
                    "role": "system",
                    "content": system_prompt
                },
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": user_prompt
                        },
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/png;base64,{base64_image}"
                            }
                        }
                    ]
                }
            ],
            temperature=0,
            max_tokens=4096  # Increased for comprehensive resume extraction
        )
        
        return response.choices[0].message.content
        
    except Exception as e:
        print(f"An error occurred while processing resume {image_path}: {e}")
        return None


def save_json_result(result, filename):
    """Save extraction result to JSON file with validation"""
    if result:
        try:
            # Validate JSON before saving
            parsed_json = json.loads(result)
            print(parsed_json)
            with open(filename, "w", encoding="utf-8") as f:
                json.dump(parsed_json, f, indent=2, ensure_ascii=False)
            print(f"Results saved to: {filename}")
            
    
            return True
        except json.JSONDecodeError as e:
            print(f"Invalid JSON received for {filename}: {e}")
            print(f"Saving as text to {filename}.txt")
            with open(f"{filename}.txt", "w", encoding="utf-8") as f:
                f.write(result)
            return False
    else:
        print(f"No result to save for {filename}")
        return False


def load_jd_file(file_path):
    """Load a single JD file"""
    file_path = Path(file_path).resolve()
    with open(file_path, "r", encoding="utf-8") as f:
        return json.load(f), str(file_path)

def load_all_resume_files(directory):
    """Load all JSON resume files from directory"""
    resume_files = {}
    dir_path = Path(directory).resolve()
    
    if not dir_path.is_dir():
        raise FileNotFoundError(f"Directory not found: {directory}")
    
    for json_file in dir_path.glob("*.json"):
        try:
            with open(json_file, "r", encoding="utf-8") as f:
                resume_data = json.load(f)
                # Use filename without extension as key
                resume_name = json_file.stem
                resume_files[resume_name] = {
                    "data": resume_data,
                    "path": str(json_file)
                }
        except Exception as e:
            print(f"Error loading {json_file}: {e}")
    
    return resume_files

def minify(obj) -> str:
    # compact JSON string to save tokens
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":"))


# ---------- Prompt ----------
SYSTEM = (
    """"You are an ATS. Compare the résumé to the job description. Score strictly by this rubric (max points): 
Projects 30, Educational Background 15, Work Experience 25, Technical Skills 20, Related Certifications 10.

# Rules:
- Award points only with evidence from the résumé (skills list alone doesn’t count).
- Include a short “reason” and what is "lacking" per category.
- Add a calc_check object that recomputes the sum and flags any mismatch.
- Compute `final_score` as the sum of all scores and set calc_check accordingly.
- Return JSON only — no markdown or delimiters.
- Output strictly as valid JSON in this schema:
{
  "Projects": {"score": int, "reason": str},
  "Educational Background": {"score": int, "reason": str},
  "Work Experience": {"score": int, "reason": str},
  "Technical Skills": {"score": int, "reason": str},
  "Related Certifications": {"score": int, "reason": str},
  "final_score": {"value": int},
  "calc_check": {"sum": int, "matches_final_score": bool}
}

"""
)

USER_TEMPLATE = """Check the resume against the job description and evaluate if candidate is the right fit for the job.

Job Description:
{jd_json}

Resume:
{resume_json}

"""
def compare_with_llm(jd_obj: dict, resume_obj: dict, model: str = MODEL) -> dict:    
    user_prompt = USER_TEMPLATE.format(
        jd_json=minify(jd_obj),
        resume_json=minify(resume_obj),
    )
    
    print(f"Sending prompt length: {len(user_prompt)} characters")
    
    try:
        resp = ollama.chat(
            model=model,
            messages=[
                {"role": "system", "content": SYSTEM},
                {"role": "user", "content": user_prompt},
            ],
            options={"temperature": 0},
        )
        
        raw_content = resp["message"]["content"]
        print(raw_content)
        print(f"Raw response received (length: {len(raw_content)})")
        
        if not raw_content or raw_content.strip() == "":
            return {"error": "Empty response from model"}
        
        # Try to extract JSON if response contains extra text
        if raw_content.strip().startswith('{') and raw_content.strip().endswith('}'):
            return json.loads(raw_content)
        else:
            # Try to find JSON in the response
            import re
            json_match = re.search(r'\{.*\}', raw_content, re.DOTALL)
            if json_match:
                return json.loads(json_match.group())
            else:
                return {"error": "No valid JSON found in response", "raw": raw_content}
            
    except json.JSONDecodeError as e:
        print(f"JSON decode error: {e}")
        return {"error": "Invalid JSON response", "raw": raw_content}
    except Exception as e:
        print(f"API error: {e}")
        return {"error": str(e)}

def get_final_score_safe(result: dict) -> int:
    """Extract final score from the result, handling different response formats"""
    
    if not isinstance(result, dict):
        print(f"Warning: Result is not a dict: {type(result)}")
        return 0
    
    # Check for errors first
    if "error" in result:
        print(f"Error in result: {result['error']}")
        return 0
    
    # Method 1: Check for final_score.value (correct schema)
    if "final_score" in result:
        final_score_obj = result["final_score"]
        if isinstance(final_score_obj, dict) and "value" in final_score_obj:
            try:
                score = int(final_score_obj["value"])
                print(f"✅ Extracted final_score.value: {score}")
                return score
            except (TypeError, ValueError) as e:
                print(f"Error converting final_score.value to int: {e}")
        elif isinstance(final_score_obj, (int, float)):
            # Handle case where final_score is directly a number
            try:
                score = int(final_score_obj)
                print(f"✅ Extracted final_score (direct): {score}")
                return score
            except (TypeError, ValueError) as e:
                print(f"Error converting final_score to int: {e}")
    
    # Method 2: Sum up individual category scores
    categories = ["Projects", "Educational Background", "Work Experience", 
                  "Technical Skills", "Related Certifications"]
    
    total_score = 0
    for category in categories:
        if category in result and isinstance(result[category], dict):
            category_score = result[category].get("score", 0)
            try:
                total_score += int(category_score)
                print(f"Added {category}: {category_score}")
            except (TypeError, ValueError):
                print(f"Invalid score for {category}: {category_score}")
    
    if total_score > 0:
        print(f"✅ Calculated total from categories: {total_score}")
        return total_score
    
    # Method 3: Debug - print the actual structure
    print(f"❌ Could not extract score. Result structure:")
    print(json.dumps(result, indent=2))
    return 0

def update_candidate_score(db_path: str, candidate_id: str, final_score: int):
    """Update the final_score for a candidate in the database."""
    with sqlite3.connect(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE candidates SET resume_score = ? WHERE candidate_id = ?",
            (final_score, candidate_id)
        )
        conn.commit()
        print(f"✅ Updated candidate_id {candidate_id} with final_score {final_score}")


def retrieve_fit_candidates():
    """Retrieve all candidates with score > 60"""
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute(
            "SELECT candidate_id, email_address, resume_score FROM candidates ORDER BY resume_score DESC LIMIT 3"
        )
        rows = cursor.fetchall()
        conn.close()
        
        qualified_candidates = []
        for row in rows:
            qualified_candidates.append({
                'candidate_id': row[0],
                'email_address': row[1],
                'score': row[2]
            })
        
        return qualified_candidates
    except Exception as e:
        #print(f"Error retrieving qualified candidates: {e}")
        return []

def _h(raw: str) -> str:
    return hmac.new(TOKEN_PEPPER.encode(), raw.encode(), hashlib.sha256).hexdigest()

def generate_password(length=10) -> str:
    """
    Generate a secure random password for a candidate.
    Default length = 10 characters.
    Includes uppercase, lowercase, digits, and symbols.
    """
    alphabet = string.ascii_letters + string.digits + "!@#$%^&*()-_=+"
    # secrets.choice() gives cryptographically strong randomness
    password = ''.join(secrets.choice(alphabet) for _ in range(length))
    return password

def add_password_column():
    """Add password column to candidates table if it doesn't exist"""
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Check if column exists
        cursor.execute("PRAGMA table_info(candidates)")
        columns = [column[1] for column in cursor.fetchall()]
        
        if 'password' not in columns:
            cursor.execute('ALTER TABLE candidates ADD COLUMN password TEXT DEFAULT NULL')
            conn.commit()
            print("✅ Added password column to candidates table")
        else:
            print("✅ Password column already exists")
        
        conn.close()
    except Exception as e:
        print(f"❌ Error adding password column: {e}")


def generate_link(candidate_id: str) -> str:
    """Generate a unique interview link for a candidate."""
    raw = uuid.uuid4().hex  # 32 chars, URL-safe
    th = _h(raw)
    now = datetime.utcnow()
    exp = now + timedelta(hours=TOKEN_TTL_HOURS)

    con = sqlite3.connect(db_path)
    with con:
        con.execute("""
            UPDATE candidates
               SET interview_token_hash = ?,
                   interview_token_expires_at = ?,
                   interview_token_used_at = NULL
             WHERE candidate_id = ?;
        """, (th, exp.isoformat(), candidate_id))
    con.close()

    return f"{BASE_URL}"

def update_candidate_password(candidate_id: str, password: str):
    """Update password for a specific candidate"""
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE candidates SET password = ? WHERE candidate_id = ?",
            (password, candidate_id)
        )
        
        if cursor.rowcount > 0:
            conn.commit()
            print(f"✅ Password updated for candidate {candidate_id}")
            return True
        else:
            print(f"⚠️ No candidate found with ID: {candidate_id}")
            return False
        
        conn.close()
    except Exception as e:
        print(f"❌ Error updating password for {candidate_id}: {e}")
        return False



def get_service():
    creds = None
    if os.path.exists("token.json"):
        creds = Credentials.from_authorized_user_file("/home/aliza-ashfaq/Desktop/project_/test/token.json", SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file("/home/aliza-ashfaq/Desktop/project_/test/client_secret_993249251770-39ot8taj89kdptcqqgdii5pjerprid2u.apps.googleusercontent.com.json", SCOPES)
            creds = flow.run_local_server(port=0)
        with open("token.json", "w") as f:
            f.write(creds.to_json())
    return build("gmail", "v1", credentials=creds)


def create_gmail_message(to_email: str, subject: str, body_text: str) -> dict:
    """Create a Gmail message"""
    message = EmailMessage()
    message["To"] = to_email
    message["From"] = "alizaak265@gmail.com"  # Your Gmail address
    message["Subject"] = subject
    message.set_content(body_text)

    # Encode message
    raw_message = base64.urlsafe_b64encode(message.as_bytes()).decode('utf-8')
    return {"raw": raw_message}

def send_gmail(to_email: str, subject: str, body: str) -> bool:
    """Send email using Gmail API with OAuth"""
    try:
        service = get_service()
        message = create_gmail_message(to_email, subject, body)
        
        # Send the email
        sent_message = service.users().messages().send(
            userId="me", 
            body=message
        ).execute()
        
        print(f"✅ Gmail sent successfully to {to_email}")
        print(f"📧 Message ID: {sent_message.get('id')}")
        return True
        
    except Exception as e:
        print(f"❌ Failed to send Gmail to {to_email}: {e}")
        return False

if __name__ == "__main__":

    #add_password_column()

    JD_path = "JD.pdf"
    #resume_paths = retrieve_resumes_from_db()
    resume_paths = "uploads"
    JD_output_dir = "output_JD"
    resume_output_dir = "output_resumes" 
    os.makedirs(JD_output_dir, exist_ok=True)
    os.makedirs(resume_output_dir, exist_ok=True)

    jd_result = None
    resume_results = {}

    print("=" * 60)
    print("PROCESSING JOB DESCRIPTION AND MULTIPLE RESUMES WITH GROQ API")
    print("=" * 60)


    # ===== PROCESS JOB DESCRIPTION ONCE =====
    if os.path.exists(JD_path):
        print("\nPROCESSING JOB DESCRIPTION...")
        
        try:
            # OCR JD PDF and save images
            doc = pymupdf.open(JD_path)
            for p in doc:
                img = Image.open(io.BytesIO(p.get_pixmap(dpi=300).tobytes("png")))
                image_path = f"{JD_output_dir}/page_{p.number + 1}.png"
                img.save(image_path)
            doc.close()
            print(f"JD images saved to: {JD_output_dir}")
            
            # Get all JD images and stitch them
            jd_image_files = sorted([os.path.join(JD_output_dir, f) for f in os.listdir(JD_output_dir) if f.endswith('.png')])
            if jd_image_files:
                print(f"Stitching {len(jd_image_files)} JD pages...")
                stitched_jd_path = stitch_vertical(jd_image_files, out_path="stitched_JD.png")
                print(f"Stitched JD saved to: {stitched_jd_path}")

                # Extract JD information using Groq
                print(f"Extracting JD details with Groq API...")
                jd_result = groq_extract_from_image_JD(stitched_jd_path)
                
                if jd_result:
                    print("\nJOB DESCRIPTION EXTRACTION COMPLETED")
                    # Save JD result once
                    save_json_result(jd_result, "jd_extraction.json")
                else:
                    print("No JD result returned or error occurred.")
        
        except Exception as e:
            print(f"Error processing JD: {e}")
    
    print("\n" + "=" * 60)
    
    # ===== PROCESS ALL RESUMES =====
    for i, resume_info in enumerate(resume_paths):
        resume_path = resume_info['resume_filepath']

        if not os.path.exists(resume_path):
            print(f"Resume file '{resume_path}' not found! Skipping...")
            continue
            
        print(f"\nPROCESSING RESUME {i+1}/{len(resume_paths)}: {resume_path}")
        
        try:
            # Create subdirectory for this resume's images
            resume_name = resume_info["candidate_id"]
            print(resume_name)
            current_resume_dir = os.path.join(resume_output_dir, resume_name)
            os.makedirs(current_resume_dir, exist_ok=True)
            
            # OCR Resume PDF and save images
            doc = pymupdf.open(resume_path)
            for p in doc:
                img = Image.open(io.BytesIO(p.get_pixmap(dpi=300).tobytes("png")))
                image_path = f"{current_resume_dir}/page_{p.number + 1}.png"
                img.save(image_path)
            doc.close()
            print(f"Resume images saved to: {current_resume_dir}")
            
            # Get all Resume images and stitch them
            resume_image_files = sorted([os.path.join(current_resume_dir, f) for f in os.listdir(current_resume_dir) if f.endswith('.png')])
            if resume_image_files:
                print(f"Stitching {len(resume_image_files)} Resume pages...")
                stitched_resume_path = f"stitched_resume_{resume_name}.png"
                stitch_vertical(resume_image_files, out_path=stitched_resume_path)
                print(f"Stitched Resume saved to: {stitched_resume_path}")
                
                # Extract Resume information using Groq
                print(f"Extracting Resume details with Groq API...")
                resume_result = groq_extract_from_image_resume(stitched_resume_path)
                
                if resume_result:
                    print(f"Resume {resume_name} extraction completed")
                    # Store result with resume name as key
                    resume_results[resume_name] = resume_result
                    # Save individual resume result
                    save_json_result(resume_result, os.path.join(Resumes, f"{resume_name}.json"))
                else:
                    print(f"No result for resume {resume_name}")
            else:
                print(f"No images found for resume {resume_name}")
        
        except Exception as e:
            print(f"Error processing Resume {resume_path}: {e}")
    
    print("\n" + "=" * 60)
    print("PROCESSING COMPLETED!")
    print(f"JD processed: {'✅' if jd_result else '❌'}")
    print(f"Resumes processed: {len(resume_results)}/{len(resume_paths)}")
    print("=" * 60)

    try:
        # Load JD once
        jd, jd_path = load_jd_file(JD_FILE_CANDIDATES)
        print(f"Loaded JD: {jd_path}")
        
        # Load all resume files
        resume_files = load_all_resume_files(Resumes)
        
        if not resume_files:
            print(f"No JSON files found in directory: {Resumes}")
            exit(1)
        
        print(f"Found {len(resume_files)} resume files:")
        for name, info in resume_files.items():
            print(f"  - {name} ({info['path']})")
        
        # Process each resume
        all_results = {}
        
        for resume_name, resume_info in resume_files.items():
            print(f"\n{'='*60}")
            print(f"EVALUATING: {resume_name}")
            print(f"{'='*60}")
            
            result = compare_with_llm(jd, resume_info['data'], MODEL)
            final_score = get_final_score_safe(result)
            update_candidate_score(db_path,resume_name, final_score)
            all_results[resume_name] = result
            
            # Print summary for this resume
            if "error" not in result:
                fit = result.get("fit", "unknown")
                #score = result.get("score", 0)
                #print(f"{resume_name}: {fit.upper()} (Score: {score}/100)")
            else:
                print(f"{resume_name}: ERROR - {result.get('error', 'Unknown error')}")
        
        # Save all results in one file
        final_results = {
            "total_resumes": len(resume_files),
            "evaluations": all_results
        }
        
        # Save to file
        output_file = "all_resume_evaluations.json"
        Path(output_file).write_text(
            json.dumps(final_results, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        
        print(f"\n{'='*60}")
        print(f"EVALUATION COMPLETE")
        print(f"{'='*60}")
        print(f"Results saved to: {output_file}")
        
        # ===== SEND EMAILS TO QUALIFIED CANDIDATES =====
        print(f"\n📧 SENDING INTERVIEW INVITATIONS...")
        print("-" * 40)
        
        qualified_candidates = retrieve_fit_candidates()
        
        if qualified_candidates:
            print(f"Found {len(qualified_candidates)} qualified candidates:")
            
            for candidate in qualified_candidates:
                candidate_id = candidate['candidate_id']
                email_address = candidate['email_address']
                score = candidate['score']
                
                try:
                    # Generate password for the candidate
                    candidate_password = generate_password(12)
                    update_candidate_password(candidate_id, candidate_password)  # Add this line

                    # Generate interview link
                    interview_link = generate_link(candidate_id)

                    # Prepare email
                    subject = "Congratulations! Interview Invitation"
                    body = f"""
Dear Candidate,

Congratulations! Your resume has been selected for the next round.

LOGIN CREDENTIALS:
- Candidate ID: {candidate_id}
- Password: {candidate_password}

Please use this link to start your interview:
{interview_link}

This link expires in 24 hours.

Best regards,
HR Team
                    """
                    
                    # Send email
                    success = send_gmail(email_address, subject, body)
                    
                    if success:
                        print(f"✅ Email sent to {candidate_id} ({email_address}) - Score: {score}")
                        #print(f"🔑 Password: {candidate_password}")
                        #print(f"🔗 Link: {interview_link}")
                    else:
                        print(f"❌ Failed to send email to {candidate_id}")

                except Exception as e:
                    print(f"❌ Error processing candidate {candidate_id}: {e}")
        else:
            print("❌ No qualified candidates found (score > 60)")
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
    

