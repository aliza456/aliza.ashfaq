import csv
import PyPDF2
import ast
import json
import importlib.util
import pathlib
import sys
from datetime import datetime
import os

CLONED_REPOS_DIR = "/home/aliza-ashfaq/Desktop/interview/cloned_repos"
CSV_PATH = "ml_interview_questions_Q1_to_Q10.csv"

json_path = "/home/aliza-ashfaq/Desktop/interview/all_assessments.json"

RESULTS_PATH = pathlib.Path(CLONED_REPOS_DIR).parent / "test_results.json"


def load_previous_shas(results_path=RESULTS_PATH):
    """Return {repo_name: commit_sha} from prior test_results.json (if present)."""
    if not results_path.exists():
        return {}
    try:
        with open(results_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        out = {}
        for repo_name, entry in data.get("candidates", {}).items():
            sha = entry.get("commit_sha")
            if sha:
                out[repo_name] = sha
        return out
    except Exception:
        return {}

# def get_head_sha(repo_path: pathlib.Path) -> str | None:
#     """Return the current HEAD commit SHA of a git repo, or None if unknown."""
#     try:
#         sha = subprocess.check_output(
#             ["git", "-C", str(repo_path), "rev-parse", "HEAD"],
#             stderr=subprocess.STDOUT
#         ).decode().strip()
#         return sha
#     except Exception:
#         # Not a git repo or git not installed; return None so we don't skip by mistake
#         return None
    
def extract_mapping_for_candidate(json_path, candidate_id):
    with open(json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    assessments = data.get("assessments", [])
    for assessment in assessments:
        if assessment.get("candidate_id") == candidate_id:
            out = {}
            for pdf_q, details in assessment.get("questions", {}).items():
                if isinstance(details, dict):
                    if "csv_ids" in details and isinstance(details["csv_ids"], list):
                        out[pdf_q] = details["csv_ids"]              # e.g., ["Q2_TC1","Q2_TC2","Q2_TC3"]
                    elif "csv_id" in details:
                        out[pdf_q] = details["csv_id"]                # e.g., "Q2_TC1"
                else:
                    # If the JSON already stores a raw string/list
                    out[pdf_q] = details
            return out
    return {}


def run_tests_from_mapping(repo_path, mapping, question_bank):
    """
    For each file like Q2.py in the repo, find its mapped CSV ID from the mapping,
    and run the test cases from the question bank using the first function found.
    Returns a report of test results.
    """
    py_files = [f for f in pathlib.Path(repo_path).glob("Q*.py")]
    results = {
        "total_files": len(py_files),
        "files_tested": 0,
        "files_passed": 0,
        "files_failed": 0,
        "questions": {}
    }
    
    for py_file in py_files:
        pdf_q = py_file.stem  # e.g., "Q2"
        print(f"[debug] Processing {pdf_q}")
        
        csv_id = mapping.get(pdf_q)
        if not csv_id:
            print(f"[skip] No CSV ID mapping for {pdf_q}")
            results["questions"][pdf_q] = {
                "status": "skipped",
                "reason": "No CSV ID mapping found"
            }
            continue
            
        # Handle both single CSV ID and multiple CSV IDs
        csv_ids_to_test = csv_id if isinstance(csv_id, list) else [csv_id]
        
        all_tests_passed = True
        combined_test_details = {
            "total_tests": 0,
            "passed": 0,
            "failed": 0,
            "failed_cases": []
        }
        
        for single_csv_id in csv_ids_to_test:
            if single_csv_id not in question_bank:
                print(f"[skip] No test cases for CSV ID {single_csv_id}")
                continue
                
            print(f"[info] Testing {py_file.name} against CSV ID {single_csv_id}")
            
            functions = detect_functions_in_file(py_file)
            if not functions:
                print(f"[warning] No functions found in {py_file.name}")
                results["questions"][pdf_q] = {
                    "status": "error",
                    "reason": "No functions found in file",
                    "csv_id": single_csv_id
                }
                all_tests_passed = False
                continue
            
            function_name = functions[0]  # Use the first function found
            test_cases = question_bank[single_csv_id]["test_cases"]
            success, test_details = test_function_against_csv(py_file, function_name, single_csv_id, test_cases)
            
            # Combine test results
            combined_test_details["total_tests"] += test_details["total_tests"]
            combined_test_details["passed"] += test_details["passed"]
            combined_test_details["failed"] += test_details["failed"]
            combined_test_details["failed_cases"].extend(test_details.get("failed_cases", []))
            
            if not success:
                all_tests_passed = False
        
        if csv_ids_to_test:  # Only mark as tested if we had CSV IDs to test
            results["files_tested"] += 1
            
            if all_tests_passed:
                results["files_passed"] += 1
            else:
                results["files_failed"] += 1
            
            status = "✅ PASSED" if all_tests_passed else "❌ FAILED"
            print(f"{pdf_q} ({csv_ids_to_test}): {status}")
            
            results["questions"][pdf_q] = {
                "status": "passed" if all_tests_passed else "failed",
                "csv_ids": csv_ids_to_test,
                "function_name": function_name if 'function_name' in locals() else None,
                "test_details": combined_test_details
            }
    
    return results
    


# def run_tests_from_mapping(repo_path, mapping, question_bank):
#     """
#     For each file like Q2.py in the repo, find its mapped CSV ID from the mapping,
#     and run the test cases from the question bank using the first function found.
#     """
#     py_files = [f for f in pathlib.Path(repo_path).glob("Q*.py")]
#     for py_file in py_files:
#         pdf_q = py_file.stem 
#         print(pdf_q) # e.g., "Q2"
#         csv_id = mapping.get(pdf_q)
#         if not csv_id:
#             print(f"[skip] No CSV ID mapping for {pdf_q}")
#             continue
#         if csv_id not in question_bank:
#             print(f"[skip] No test cases for CSV ID {csv_id}")
#             continue

#         print(f"[info] Testing {py_file.name} mapped to CSV ID {csv_id}")
    

def detect_functions_in_file(py_file):
    """Detect which functions are defined in a Python file"""
    try:
        with open(py_file, 'r', encoding='utf-8') as f:
            content = f.read()
        tree = ast.parse(content)
        functions = [node.name for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)]
        return functions
    except Exception as e:
        print(f"[error] Could not parse {py_file}: {e}")
        return []

def test_function_against_csv(candidate_file, function_name, question_id, test_cases):
    """Test a specific function against its CSV test cases and show failed cases.
    Returns (success, test_details)
    """
    test_details = {
        "total_tests": len(test_cases),
        "passed": 0,
        "failed": 0,
        "failed_cases": []
    }
    
    try:
        spec = importlib.util.spec_from_file_location("candidate", candidate_file)
        candidate_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(candidate_module)
        func = getattr(candidate_module, function_name)
        
        for input_data, expected_output in test_cases:
            try:
                input_obj = json.loads(input_data)
                # Handle TRUE/FALSE in expected_output
                if expected_output.strip().upper() == "TRUE":
                    expected_obj = True
                elif expected_output.strip().upper() == "FALSE":
                    expected_obj = False
                else:
                    expected_obj = json.loads(expected_output)
                if isinstance(input_obj, dict):
                    result = func(**input_obj)
                elif isinstance(input_obj, (list, tuple)):
                    result = func(*input_obj)
                else:
                    result = func(input_obj)
                if result == expected_obj:
                    test_details["passed"] += 1
                else:
                    test_details["failed"] += 1
                    test_details["failed_cases"].append({
                        "input": input_data,
                        "expected": expected_output,
                        "actual": str(result)
                    })
            except Exception as e:
                test_details["failed"] += 1
                test_details["failed_cases"].append({
                    "input": input_data,
                    "expected": expected_output,
                    "actual": f"Exception: {str(e)}"
                })
        
        print(f"[info] {candidate_file.name}: {test_details['passed']} passed, {test_details['failed']} failed")
        if test_details["failed_cases"]:
            print(f"[FAILED CASES for {candidate_file.name}]:")
            for case in test_details["failed_cases"]:
                print(f"  Input: {case['input']}")
                print(f"  Expected: {case['expected']}")
                print(f"  Got: {case['actual']}\n")
                
        return test_details["failed"] == 0, test_details
    except Exception as e:
        print(f"[error] Could not test function '{function_name}' in {candidate_file}: {e}")
        test_details["error"] = str(e)
        return False, test_details


def load_question_bank(csv_path=CSV_PATH):
    """Load all questions and their test cases from CSV

    Returns:
        dict[str, dict]: {
            'Q1': {
                'question': <str>,
                'test_cases': [(input, expected), ...]
            },
            ...
        }
    """
    questions = {}
    with open(csv_path, newline='', encoding='utf-8') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            question_id = row["question ID"].strip()
            if question_id not in questions:
                questions[question_id] = {
                    "question": row["question"].strip(),
                    "test_cases": []
                }
            input_data = row["input"]
            expected_output = row["expected"]
            questions[question_id]["test_cases"].append((input_data, expected_output))
    return questions

def main():
    question_bank = load_question_bank()
    repo_dir = pathlib.Path(CLONED_REPOS_DIR)
    candidate_repos = [d for d in repo_dir.iterdir() if d.is_dir() and not d.name.startswith('.')]
    if not candidate_repos:
        print(f"[error] No candidate repos found in {CLONED_REPOS_DIR}")
        return

    # Load previously tested commit SHAs
    previous_shas = load_previous_shas(RESULTS_PATH)

    overall_results = {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "total_candidates": len(candidate_repos),
        "candidates": {}
    }

    for candidate_repo in candidate_repos:
        repo_name = candidate_repo.name

        # Skip if we've already tested this exact commit
        #current_sha = get_head_sha(candidate_repo)
        # if current_sha and previous_shas.get(repo_name) == current_sha:
        #     print(f"[skip] {repo_name} unchanged (sha {current_sha[:7]}); already tested.")
        #     continue

        # Extract candidate_id from repo name (format: prefix_cand_xxxxxxxx)
        if "cand_" in repo_name:
            start_idx = repo_name.find("cand_")
            end_idx = repo_name.find("_", start_idx + 5)
            candidate_id = repo_name[start_idx:] if end_idx == -1 else repo_name[start_idx:end_idx]
        else:
            print(f"[error] Could not extract candidate_id from repo name {repo_name}")
            continue

        print(f"\n{'='*60}\nTesting repo: {repo_name}\n{'='*60}")
        print(f"[info] Using candidate ID: {candidate_id}")

        mapping = extract_mapping_for_candidate(json_path, candidate_id)
        if not mapping:
            print(f"[error] No assessment mapping found for candidate ID {candidate_id}")
            overall_results["candidates"][repo_name] = {
                "candidate_id": candidate_id,
                "status": "error",
                "reason": "No assessment mapping found",
                #"commit_sha": current_sha
            }
            continue

        candidate_results = run_tests_from_mapping(candidate_repo, mapping, question_bank)

        overall_results["candidates"][repo_name] = {
            "candidate_id": candidate_id,
            "status": "completed",
            "results": candidate_results,
            #"commit_sha": current_sha,  # <-- record tested commit
            "tested_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }

    # Merge with previous file so we don't lose older entries
    if RESULTS_PATH.exists():
        try:
            with open(RESULTS_PATH, 'r', encoding='utf-8') as f:
                old = json.load(f)
        except Exception:
            old = {}
        # carry forward old candidates unless we overwrote them this run
        merged = {
            "timestamp": overall_results["timestamp"],
            "total_candidates": overall_results["total_candidates"],
            "candidates": {**old.get("candidates", {}), **overall_results["candidates"]}
        }
    else:
        merged = overall_results

    with open(RESULTS_PATH, 'w', encoding='utf-8') as f:
        json.dump(merged, f, indent=2)

    print(f"\n{'='*60}")
    print(f"All tests completed. Results saved to {RESULTS_PATH}")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()

