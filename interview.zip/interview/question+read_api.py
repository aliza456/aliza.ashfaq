# api_app.py
# pip install fastapi uvicorn pydantic-settings

from __future__ import annotations
from typing import List, Dict, Any, Optional
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from pydantic_settings import BaseSettings
import json
from pathlib import Path

# Import your logic files
import question_2  # must expose: main(limit, min_q, max_q, seed)
import read_form     # must expose: list_all_responses, read_github_urls_from_responses, clone_github_repos, FORM_ID

# =========================
# ======== CONFIG =========
# =========================

class Settings(BaseSettings):
    # From send_assessments.py
    DEFAULT_LIMIT: int = 3
    DEFAULT_MIN_Q: int = 4
    DEFAULT_MAX_Q: int = 5

    # From collect_repos.py
    FORM_ID: str = getattr(read_form, "FORM_ID", "")
    JSONL_PATH: str = "form_responses.jsonl"
    TARGET_DIR: str = "cloned_repos"

settings = Settings()

app = FastAPI(
    title="Assessments API (Send + Collect)",
    version="1.0.0",
    description="Endpoints for sending assessments and collecting/cloning GitHub repos."
)

# =========================
# ========= MODELS =========
# =========================

class SendRequest(BaseModel):
    limit: int = settings.DEFAULT_LIMIT
    min_q: int = settings.DEFAULT_MIN_Q
    max_q: int = settings.DEFAULT_MAX_Q
    seed: Optional[int] = None

class SendResponse(BaseModel):
    requested: int
    emailed: int
    details: List[Dict[str, Any]]

class CollectRequest(BaseModel):
    form_id: Optional[str] = None
    save_jsonl: bool = True
    jsonl_path: str = settings.JSONL_PATH
    target_dir: str = settings.TARGET_DIR
    dedupe_urls: bool = True

class CollectResult(BaseModel):
    responses_count: int
    urls_count: int
    urls: List[str]
    clone_summary: Dict[str, int]
    clone_results: List[Dict[str, Any]]

# =========================
# ========= ROUTES =========
# =========================

@app.get("/health")
def health():
    return {"ok": True}

@app.post("/send", response_model=SendResponse)
def send_assessments_api(req: SendRequest):
    """
    Trigger: send assessment PDFs to top N *new* candidates (sent=0),
    log to all_assessments.json, and mark sent=1.
    """
    try:
        result = question_2.main(
            limit=req.limit, min_q=req.min_q, max_q=req.max_q, seed=req.seed
        )
        # `send_assessments.main` should return {"requested": int, "emailed": int, "details": [...]}
        return SendResponse(**result)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/collect", response_model=CollectResult)
def collect_and_clone_api(req: CollectRequest):
    """
    1) Fetch Google Form responses
    2) (optional) Save to JSONL
    3) Extract GitHub URLs
    4) Clone repos (skips already existing)
    """
    form_id = req.form_id or settings.FORM_ID

    # 1) fetch responses (uses token.json with Forms scope)
    try:
        responses = read_form.list_all_responses(form_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to list form responses: {e}")

    # 2) save JSONL (optional)
    if req.save_jsonl:
        try:
            p = Path(req.jsonl_path)
            with p.open("w", encoding="utf-8") as f:
                for r in responses:
                    f.write(json.dumps(r, ensure_ascii=False) + "\n")
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Failed to write JSONL: {e}")

    # 3) extract URLs
    try:
        urls = read_form.read_github_urls_from_responses(req.jsonl_path)
        if req.dedupe_urls:
            seen = set()
            urls = [u for u in urls if not (u in seen or seen.add(u))]
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to extract GitHub URLs: {e}")

    # 4) clone
    clone_results: List[Dict[str, Any]] = []
    if urls:
        try:
            clone_results = read_form.clone_github_repos(urls, target_dir=req.target_dir)
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Failed to clone repositories: {e}")

    # summarize
    summary = {"success": 0, "already_exists": 0, "error": 0}
    for r in clone_results:
        status = r.get("status", "error")
        summary[status] = summary.get(status, 0) + 1

    return CollectResult(
        responses_count=len(responses),
        urls_count=len(urls),
        urls=urls,
        clone_summary=summary,
        clone_results=clone_results
    )

# Optional local run:
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("api_app:app", host="0.0.0.0", port=8000, reload=True)
