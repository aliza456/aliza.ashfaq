import os
from pathlib import Path
import requests
import json

evaluating_prompt = """SYSTEM:
You are an expert data scientist and machine learning engineer acting as a strict, fair interviewer/grader.

TASK:
Grade a candidate's answers to interview questions. For each answer:
- FIRST, verify factual correctness - if the answer contains ANY significant factual errors or misconceptions about concepts, assign a score of 0-2 regardless of other qualities.
- Then assess clarity, conceptual understanding, and completeness.
- Check for relevant examples/explanations when appropriate.
- If the meaning is unclear or the answer is incorrect, assign a score of 0-2.
- If the candidate explicitly says they don't know, assign a score of 0 for that question.

Be extremely vigilant about factual errors - even well-articulated answers with fundamental conceptual errors must receive low scores.
- Use the full 0-10 scale:
  - 0-2: Incorrect or fundamentally flawed answers.
  - 3-5: Partially correct but with significant gaps or errors.
  - 6-8: Mostly correct with minor omissions or inaccuracies.
  - 9-10: Fully correct, clear, and comprehensive answers.

Return evaluation in json format with Question number, score, and what was lacking.
"""

api_key = "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"


def list_directory_contents(directory_path):
    """Return a list of file and folder names in the given directory."""
    try:
        return os.listdir(directory_path)
    except Exception as e:
        print(f"Error reading directory '{directory_path}': {e}")
        return []


def evaluate_interview(conversation, model="llama-3.3-70b-versatile", api_key=None):
    """Evaluate the entire interview conversation using Groq API."""
    system_prompt = evaluating_prompt
    
    # Format the conversation into a readable format for the API
    formatted_conversation = ""
    for i, qa in enumerate(conversation, 1):
        question = qa.get("question", "")
        answer = qa.get("answer", "")
        if question and answer:
            formatted_conversation += f"Question {i}: {question}\nAnswer {i}: {answer}\n\n"
    
    user_prompt = f"Here's the complete interview conversation:\n\n{formatted_conversation}\nPlease evaluate each answer individually and provide an overall score for the entire interview based on the criteria mentioned above."
    
    url = "https://api.groq.com/openai/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ],
        "temperature": 0
    }
    try:
        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()
        result = response.json()
        return result["choices"][0]["message"]["content"]
    except Exception as e:
        print(f"Error during evaluation: {e}")
        return "Evaluation could not be completed due to an error."


if __name__ == "__main__":
    interview_path = "interviews"
    contents = list_directory_contents(interview_path)
    print(f"Contents of {interview_path}:")
    for item in contents:
        print(item)
        item_path = os.path.join(interview_path, item)
        
        if os.path.exists(item_path):
            with open(item_path, "r") as f:
                data = json.load(f)
            
            conversation = data.get("conversation", [])
            if conversation:
                print(f"\nEvaluating full interview in '{item}'...")
                evaluation = evaluate_interview(conversation, api_key=api_key)
                print("\nInterview Evaluation:")
                print(evaluation)
                print("\n" + "-"*50 + "\n")
            else:
                print(f"No conversation data found in '{item}'")
        else:
            print(f"JSON file '{item_path}' not found.")