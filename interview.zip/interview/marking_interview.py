import json
import requests
import os


GROQ_API_KEY = "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"
GROQ_MODEL = "llama-3.3-70b-versatile"

DB_PATH = "/home/aliza-ashfaq/Desktop/project_/test/Database.db"

interview_prompt = """
You are an expert technical interviewer evaluating a Data Science interview.
You will receive a JSON file containing pairs of questions (asked by the AI) and the candidate’s corresponding answers.

Evaluate each answer purely on technical merit, ignoring tone, confidence, or communication style.
Focus on accuracy, depth, and relevance only.

Scoring per question (0–15 total):

- Technical Accuracy (0–5): Are the facts and explanations correct?
- Depth of Understanding (0–5): Does the candidate show solid conceptual grasp beyond surface-level definitions?
- Relevance (0–5): Does the answer directly and completely address the question?

After grading all questions, compute:
- Overall total score (0–100) normalized across all questions.
"""

def query_groq(json_file_path: str, max_tokens: int = 1024, temperature: float = 0.1):
    """
    Sends the provided JSON interview file to the Groq API for automated grading.

    Args:
        json_file_path: Path to the candidate's interview JSON file.
        max_tokens: Maximum response token limit.
        temperature: Sampling temperature (lower = more deterministic).

    Returns:
        The model's graded JSON response as text.
    """
    url = "https://api.groq.com/openai/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {GROQ_API_KEY}",
        "Content-Type": "application/json",
    }

    # Load candidate interview JSON
    try:
        with open(json_file_path, "r", encoding="utf-8") as f:
            interview_data = json.load(f)
    except Exception as e:
        print(f"❌ Error reading JSON file: {e}")
        return None

    # Create model input
    messages = [
        {"role": "system", "content": interview_prompt},
        {
            "role": "user",
            "content": (
                "Below is the candidate's interview in JSON format. "
                "Grade it according to the rubric described above.\n\n"
                f"Interview JSON:\n{json.dumps(interview_data, indent=2)}"
            ),
        },
    ]

    payload = {
        "model": GROQ_MODEL,
        "messages": messages,
        "max_tokens": max_tokens,
        "temperature": temperature,
        "stream": False,
    }

    try:
        response = requests.post(url, headers=headers, json=payload, timeout=90)
        response.raise_for_status()
        result = response.json()
        return result["choices"][0]["message"]["content"].strip()

    except requests.RequestException as e:
        print(f"❌ API request error: {e}")
        if hasattr(e, "response") and e.response is not None:
            print(f"Response text: {e.response.text}")
        return None

    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        return None


def main(input_dir: str = "/home/aliza-ashfaq/Desktop/interview/conversation_logs", output_dir: str = "graded_results"):
    """
    Scans a directory for interview JSON files, sends each to the Groq API for grading,
    and saves the structured grading results as new JSON files.

    Args:
        input_dir: Directory containing ungraded interview JSON files.
        output_dir: Directory to save graded output JSON files.
    """
    # Ensure output directory exists
    os.makedirs(output_dir, exist_ok=True)

    # Get all JSON files from input directory
    interview_files = [f for f in os.listdir(input_dir) if f.lower().endswith(".json")]
    if not interview_files:
        print(f"⚠️ No JSON files found in '{input_dir}' directory.")
        return

    print(f"📂 Found {len(interview_files)} interview file(s) in '{input_dir}'")

    # Process each file
    for filename in interview_files:
        input_path = os.path.join(input_dir, filename)
        output_path = os.path.join(output_dir, f"graded_{filename}")

        print(f"\n🧠 Grading interview file: {filename} ...")

        result = query_groq(input_path)

        if not result:
            print(f"❌ Failed to grade {filename}")
            continue

        # Try to parse the model output as JSON; if fails, save raw text
        try:
            graded_data = json.loads(result)
            with open(output_path, "w", encoding="utf-8") as f:
                json.dump(graded_data, f, indent=2, ensure_ascii=False)
            print(f"✅ Graded result saved → {output_path}")

        except json.JSONDecodeError:
            # Save raw text if not valid JSON
            raw_output_path = os.path.join(output_dir, f"graded_{os.path.splitext(filename)[0]}_raw.txt")
            with open(raw_output_path, "w", encoding="utf-8") as f:
                f.write(result)
            print(f"⚠️ Model output was not valid JSON. Saved raw text → {raw_output_path}")

    print("\n🎯 All interview files processed.")

# Run when executed directly
if __name__ == "__main__":
    main(input_dir="/home/aliza-ashfaq/Desktop/interview/conversation_logs", output_dir="/home/aliza-ashfaq/Desktop/interview/graded_results")
