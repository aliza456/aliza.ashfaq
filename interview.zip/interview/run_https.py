#!/usr/bin/env python3
"""
Run the FastAPI app with HTTPS using the SSL certificates.
This enables getUserMedia API in the browser.
"""
import uvicorn

if __name__ == "__main__":
    uvicorn.run(
        "in:app",
        host="0.0.0.0",
        port=8000,
        ssl_keyfile="key.pem",
        ssl_certfile="cert.pem",
        reload=True  # Auto-reload on code changes (disable in production)
    )
