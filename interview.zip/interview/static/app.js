let runId = null;
let es = null;

const englishBtn = document.getElementById("englishBtn");
const urduBtn = document.getElementById("urduBtn");
const stopBtn = document.getElementById("stopBtn");
const runIdSpan = document.getElementById("runId");
const stateTxt = document.getElementById("stateTxt");
const stateBadge = document.getElementById("stateBadge");
const selectedLang = document.getElementById("selectedLang");
const logBox = document.getElementById("logBox");
const timeline = document.getElementById("timeline");
const toggleConsole = document.getElementById("toggleConsole");

function setState(txt, cls="muted"){
  stateTxt.textContent = txt;
  stateBadge.textContent = txt;
  stateBadge.className = `badge ${cls}`;
}

function setLanguageButtons(disabled) {
  englishBtn.disabled = disabled;
  urduBtn.disabled = disabled;
}

function ts(){
  const d = new Date();
  return d.toLocaleTimeString([], {hour:'2-digit', minute:'2-digit', second:'2-digit'});
}

function addStep(label, kind="info", detail=""){
  const li = document.createElement("li");
  li.innerHTML = `
    <span class="tag ${kind}">${kind.toUpperCase()}</span>
    <div>
      <div>${label}</div>
      ${detail ? `<div class="time">${detail}</div>` : `<div class="time">${ts()}</div>`}
    </div>`;
  timeline.appendChild(li);
  timeline.scrollTop = timeline.scrollHeight;
}

function appendConsole(line){
  logBox.textContent += line + "\n";
  logBox.scrollTop = logBox.scrollHeight;
}

function parseLine(line){
  const L = line.toLowerCase();

  // Friendly milestones
  if (L.includes("press ctrl+c to exit")) return;  // noise
  if (L.includes("enter the language")) return;    // noise (we auto-fed)

  if (L.includes("downloading:") || L.includes("loading") || L.includes("from_pretrained")){
    addStep("Loading models & assets…", "info");
  }
  if (L.includes("saved faiss index") || L.includes("faiss")){
    addStep("Knowledge base ready", "ok");
  }
  if (L.includes("starting conversation") || L.includes("ai: starting")){
    addStep("Interview started", "ok");
  }
  if (L.includes("speech started")){
    addStep("Listening…", "info", ts());
  }
  if (L.includes("processing speech…") || L.includes("processing speech")){
    addStep("Transcribing answer", "info");
  }
  if (L.includes("ai: ")){
    addStep("AI asked next question", "ok");
  }
  if (L.includes("generating speech")){
    addStep("Synthesizing voice response", "info");
  }
  if (L.includes("user interrupted")){
    addStep("Barge-in detected", "warn");
  }
  if (L.includes("conversation ended") || L.includes("goodbye")){
    addStep("Interview ended", "ok");
  }
}

async function startInterview(language){
  if (es) { es.close(); es = null; }
  logBox.textContent = "";
  timeline.innerHTML = "";
  setState("starting…", "info");
  selectedLang.textContent = language === "en" ? "English" : "Urdu";
  addStep(`Starting ${language === "en" ? "English" : "Urdu"} interview`, "info");

  const res = await fetch("/start_local", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ language: language }),
  });

  if (!res.ok){
    setState("error", "err");
    addStep(`Start failed (${res.status})`, "err");
    setLanguageButtons(false);
    return;
  }

  const data = await res.json();
  runId = data.run_id;
  runIdSpan.textContent = runId;
  setState("running", "ok");
  addStep(`Run ID ${runId}`, "ok");
  stopBtn.disabled = false;
  setLanguageButtons(true);

  // open SSE
  es = new EventSource(`/logs/${runId}`);
  es.onmessage = (evt) => {
    const line = evt.data || "";
    if (line.trim() === "") return;
    //appendConsole(line);
    parseLine(line);
  };
  es.onerror = () => {
    addStep("Stream ended", "warn");
    setState("stopped", "muted");
    stopBtn.disabled = true;
    setLanguageButtons(false);
    if (es){ es.close(); es = null; }
  };
}

async function stopInterview(){
  if (!runId) return;
  setState("stopping…", "warn");
  addStep("Stopping process", "warn");
  const res = await fetch(`/stop/${runId}`, { method: "POST" });
  if (res.ok){
    setState("stopped", "muted");
    addStep("Stopped", "ok");
  }else{
    addStep(`Stop failed (${res.status})`, "err");
  }
  stopBtn.disabled = true;
  setLanguageButtons(false);
  if (es){ es.close(); es = null; }
}

englishBtn.onclick = () => startInterview("en");
urduBtn.onclick = () => startInterview("ur");
stopBtn.onclick = stopInterview;

toggleConsole.onclick = () => {
  const hidden = logBox.classList.toggle("hidden");
  toggleConsole.textContent = hidden ? "Show" : "Hide";
};