import pdfplumber
import re
import json
import numpy as np
import faiss
from sentence_transformers import SentenceTransformer
import requests

pdf_path = "interview-english1.pdf"
index_path = "faiss_index.bin"
json_path = "questions1_.json"
groq_model = "llama3-70b-8192"
groq_api_key = "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"

interview_prompt_ur = """
You are a technical interviewer conducting interview in URDU. Your role is to assess the candidate's knowledge in various technical topics for the position of associate Data Scientist.

Interview Flow:
1) Start with a warm greeting in Urdu
2) Ask 2-3 questions about the candidate's background, education, projects and experience
3) For each topic, you must ask at least 3 questions (ideally 4).
4) Do not move to the next topic until at least 3 questions have been asked and answered.
5) Ask 3–4 questions about TOPIC 1 : Machine Learning
6) Then shift to TOPIC 2 : Deep Learning and ask 3–4 questions
7) Next, move to TOPIC 3 : NLP and ask 3–4 questions
8) Finally, cover TOPIC 4 : Computer Vision with 3–4 questions
9) After all topics, end the interview politely

** IMPORTANT **
STYLE RULES:
- Respond ONLY in **Urdu script**. Never use English words or phrases or any other language.
- ALWAYS ask only one question at a time. NEVER combine two questions in a single message.
- When user asks to repeat, do so politely and clearly in Urdu
- When you do not understand user response, ask them to clarify politely in Urdu
- Do NOT assume candidate experience or add context not present in the question.
- Do NOT use "have you ever heard of", "can you tell us".
- Make questions sound professional and conversational
- Show explicit topic transitions like "Now let's move to the next topic, Deep Learning."
- Do not show your thinking process
- Keep each question brief (2–3 sentences max)
- Stay strictly on interview topics and follow the topic order above
- If the candidate says they don't know the answer, then ask a different but related question from the same topic before moving on.
"""

interview_prompt_en = """
You are a technical interviewer. Your role is to assess the candidate's knowledge in various technical topics for the position of associate Data Scientist.

Interview Flow:
1) Start with a warm greeting in English
2) Ask 2-3 questions about the candidate’s background, education,projects and experience
3) For each technical topic, ONLY ask questions from the provided document. Do not invent or paraphrase new questions.
4) Ask 2–3 questions about TOPIC 1 : Machine Learning
5) Then shift to TOPIC 2 : Deep Learning and ask 2–3 questions
6) Next, move to TOPIC 3 : NLP and ask 2–3 questions
7) Finally, cover TOPIC 4 : Computer Vision with 2–3 questions
8) After all topics, end the interview politely

STYLE RULES:
- Stay strictly on interview topics and follow the topic order above
- ALWAYS ask 2-3 questions for each topic before moving to the next topic.
- Do NOT tell the answer or explain concepts
- Keep it conversational and natural
- Try to ask follow-up questions based on the candidate's answers
- Do not show your thinking process
- Keep each question brief (2–3 sentences max)
- Use natural, clear English only
- If the candidate says they don't know the answer, then ask a different but related question from the same topic before moving on.
"""

# ---- HELPERS ----
def is_topic_heading(line: str) -> bool:
    topics = ["TOPIC 1 : Machine Learning", "TOPIC 2 : Deep Learning", "TOPIC 3 : NLP", "TOPIC 4: Computer Vision"]
    return line.strip() in topics

def is_question(line: str) -> bool:
    return re.match(r'^(\d+\.|\.?\d+)', line) is not None

def parse_pdf(pdf_path):
    with pdfplumber.open(pdf_path) as pdf:
        text = "\n".join(page.extract_text() for page in pdf.pages if page.extract_text())
    
    lines = [line.strip() for line in text.split("\n") if line.strip()]
    
    topics = {}
    current_topic = None
    
    for line in lines:
        if is_topic_heading(line):
            current_topic = line.strip()
            topics[current_topic] = []
        elif is_question(line) and current_topic:
            topics[current_topic].append(line.strip())
    
    return topics

def build_faiss_index_with_metadata(topics_dict, model_name="paraphrase-multilingual-MiniLM-L12-v2"):
    model = SentenceTransformer(model_name)

    all_questions = []
    metadata = []

    for topic, questions in topics_dict.items():
        for q in questions:
            all_questions.append(q)
            metadata.append({"topic": topic, "question": q})

    embeddings = model.encode(all_questions, convert_to_numpy=True)
    faiss.normalize_L2(embeddings)

    dim = embeddings.shape[1]
    index = faiss.IndexFlatIP(dim)
    index.add(embeddings)
    print("Metadata:", metadata)
    print(f"✅ Unified FAISS index built with {index.ntotal} questions")
    return index, model, metadata

def save_index_and_metadata(index, metadata, index_path, json_path):
    faiss.write_index(index, index_path)
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(metadata, f, ensure_ascii=False, indent=4)
    print(f"💾 Saved FAISS index -> {index_path}, metadata -> {json_path}")

def load_index_and_metadata(index_path, json_path):
    index = faiss.read_index(index_path)
    with open(json_path, "r", encoding="utf-8") as f:
        metadata = json.load(f)
    return index, metadata

def query_faiss(query, model, index, questions, top_n=3):
    """Retrieve top-N similar questions from the unified index"""
    q_emb = model.encode([query], convert_to_numpy=True)
    faiss.normalize_L2(q_emb)
    
    D, I = index.search(q_emb, top_n)
    results = [(questions[i], float(D[0][k])) for k, i in enumerate(I[0])]
    return results

def query_groq(user_input, context="", max_tokens=512, temperature=0.1, conversation_history=None):
    try:
        url = "https://api.groq.com/openai/v1/chat/completions"

        goodbye_words = ["khuda hafiz", "bye", "goodbye", "khudahafiz", "alvida"]
        user_said_goodbye = any(phrase in user_input.lower() for phrase in goodbye_words)

        tools = [
            {
                "type": "function",
                "function": {
                    "name": "end_conversation",
                    "description": (
                        "ONLY call this function if the user's message contains EXACTLY these goodbye words: "
                        "'khuda hafiz', 'bye', 'goodbye', or 'alvida'. Do NOT call this for greetings or conversation."
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {},
                        "required": []
                    }
                }
            }
        ]

        if conversation_history is None:
            conversation_history = [{"role": "system", "content": interview_prompt}]

        conversation_history.append({
            "role": "user",
            "content": f"""
Candidate answer: "{user_input}"

Relevant interview questions from knowledge base:
{context}

Keep it conversational. It should look like a natural conversation, not a scripted interview. Follow the instruction and flow.
"""
        })

        payload = {
            "model": groq_model,
            "messages": conversation_history,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "stream": False,
        }

        headers = {"Authorization": f"Bearer {groq_api_key}", "Content-Type": "application/json"}
        response = requests.post(url, headers=headers, json=payload)

        if response.status_code == 200:
            result = response.json()
            choice = result["choices"][0]["message"]["content"]
            conversation_history.append({"role": "assistant", "content": choice})
            return choice.strip(), conversation_history
        else:
            print(f"Error calling Groq API: {response.status_code}")
            print(response.text)
            return "Sorry, I'm having trouble processing your answer right now.", conversation_history

    except Exception as e:
        print(f"Exception in query_groq: {str(e)}")
        return "Sorry, there was an error processing your answer.", conversation_history

if __name__ == "__main__":

    print("Enter the language of the interview (Press 1 for English, 2 for Urdu):")
    language_choice = input().strip()
    if language_choice == "1":
        interview_prompt = interview_prompt_en
        pdf_path = "interview-english1.pdf"
    elif language_choice == "2":
        interview_prompt = interview_prompt_ur
        pdf_path = "interview-english1.pdf"
    else:
        print("Invalid choice. Defaulting to English.")
        interview_prompt = interview_prompt_en

    topics_dict = parse_pdf(pdf_path)
    index, model, metadata = build_faiss_index_with_metadata(topics_dict)
    save_index_and_metadata(index, metadata, index_path, json_path)

    print("\n🤖 AI: Hello! I will be your technical interviewer today. Let's begin.")

    conversation_history = [
    {"role": "system", "content": interview_prompt}
]
    last_answer = "Let's start the interview."

    while True:
        # Always use the first topic the AI should start with; FAISS context is optional
        # You can include context from all questions to help AI pick questions from correct topics
        similar_qs = query_faiss(last_answer, model, index, metadata, top_n=5) 
        print(similar_qs) # you can ignore topic here
        context = "\n".join([f"- {q}" for q, _ in similar_qs])

        print("🔄 Thinking...", end="\r")
        ai_response, conversation_history = query_groq(
            last_answer,
            context,
            conversation_history=conversation_history
        )
        print(f"\n🤖 AI: {ai_response}")

        # Get candidate input
        user_input = input("\n👤 You: ").strip()
        if user_input.lower() in ["bye", "exit", "quit"]:
            print("🤖 AI: Thank you for your time. Interview finished!")
            break
        last_answer = user_input
