from fastapi import FastAPI, HTTPException, Form
from pydantic import BaseModel
from typing import Dict, Any, List
import pathlib, subprocess, shutil, json, csv, ast, importlib.util
from datetime import datetime

# --- Config (match your paths) ---
CLONED_REPOS_DIR = pathlib.Path("/home/aliza-ashfaq/Desktop/interview/cloned_repos")
CSV_PATH = pathlib.Path("ml_interview_questions_Q1_to_Q10.csv")
ASSESSMENTS_JSON = pathlib.Path("/home/aliza-ashfaq/Desktop/interview/all_assessments.json")

CLONED_REPOS_DIR.mkdir(parents=True, exist_ok=True)

# --- Minimal helpers (self-contained) ---
def clone_repo(repo_url: str, branch: str, dest_dir: pathlib.Path, force_reclone: bool = True) -> pathlib.Path:
    repo_name = repo_url.rstrip("/").split("/")[-1]
    if repo_name.endswith(".git"): repo_name = repo_name[:-4]
    target = dest_dir / repo_name
    if force_reclone and target.exists():
        shutil.rmtree(target)
    try:
        subprocess.check_call(
            ["git", "clone", "--depth", "1", "--branch", branch or "main", repo_url, str(target)],
            stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT
        )
    except subprocess.CalledProcessError:
        raise HTTPException(status_code=400, detail="Failed to clone repository. Check URL/branch.")
    return target

def extract_mapping_for_candidate(candidate_id: str) -> Dict[str, Any]:
    """Extract mapping from candidate's individual assessment_data.json file"""
    # Sanitize candidate_id the same way as in login_api.py
    safe_candidate_id = "".join(c for c in candidate_id if c.isalnum() or c in "-_.") or "candidate"
    
    # Path to candidate's assessment file
    assessment_file = pathlib.Path("tests") / safe_candidate_id / "assessment_data.json"
    
    if not assessment_file.exists():
        return {}
    
    try:
        with open(assessment_file, "r", encoding="utf-8") as f:
            data = json.load(f)
        
        # Look for the candidate's assessment in their file
        for a in data.get("assessments", []):
            if a.get("candidate_id") == candidate_id:
                out = {}
                for pdf_q, details in a.get("questions", {}).items():
                    if isinstance(details, dict):
                        if "csv_ids" in details and isinstance(details["csv_ids"], list):
                            out[pdf_q] = details["csv_ids"]
                        elif "csv_id" in details:
                            out[pdf_q] = details["csv_id"]
                    else:
                        out[pdf_q] = details
                return out
    except Exception as e:
        print(f"Error reading assessment file for {candidate_id}: {e}")
    
    return {}

def detect_functions_in_file(py_file: pathlib.Path) -> List[str]:
    try:
        src = py_file.read_text(encoding="utf-8")
        tree = ast.parse(src)
        return [n.name for n in ast.walk(tree) if isinstance(n, ast.FunctionDef)]
    except Exception:
        return []

def test_function_against_csv(candidate_file: pathlib.Path, function_name: str, test_cases: List[List[str]]):
    details = {"total_tests": len(test_cases), "passed": 0, "passed_cases": [], "failed": 0, "failed_cases": []}
    try:
        spec = importlib.util.spec_from_file_location("candidate", candidate_file)
        mod = importlib.util.module_from_spec(spec)
        assert spec.loader is not None
        spec.loader.exec_module(mod)
        func = getattr(mod, function_name)
        for input_data, expected_output in test_cases:
            try:
                inp = json.loads(input_data)
                eo = expected_output.strip()
                if eo.upper() == "TRUE": expected = True
                elif eo.upper() == "FALSE": expected = False
                else: expected = json.loads(eo)
                if isinstance(inp, dict): got = func(**inp)
                elif isinstance(inp, (list, tuple)): got = func(*inp)
                else: got = func(inp)
                if got == expected: 
                    details["passed"] += 1
                    details["passed_cases"].append({"input": input_data, "expected": expected_output, "actual": repr(got)})
                else:
                    details["failed"] += 1
                    details["failed_cases"].append({"input": input_data, "expected": expected_output, "actual": repr(got)})
            except Exception as e:
                details["failed"] += 1
                details["failed_cases"].append({"input": input_data, "expected": expected_output, "actual": f"Exception: {e}"})
        return details["failed"] == 0, details
    except Exception as e:
        details["failed"] = details["total_tests"]
        details["error"] = f"Could not run '{function_name}' in {candidate_file.name}: {e}"
        return False, details

def load_question_bank(csv_path: pathlib.Path) -> Dict[str, Dict[str, Any]]:
    out: Dict[str, Dict[str, Any]] = {}
    with open(csv_path, newline="", encoding="utf-8") as f:
        r = csv.DictReader(f)
        for row in r:
            qid = row["question ID"].strip()
            out.setdefault(qid, {"question": row["question"].strip(), "test_cases": []})
            out[qid]["test_cases"].append([row["input"], row["expected"]])
    return out

def run_tests_from_mapping(repo_path: pathlib.Path, mapping: Dict[str, Any], qbank: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    py_files = sorted(repo_path.glob("Q*.py"))
    results = {"total_files": len(py_files), "files_tested": 0, "files_passed": 0, "files_failed": 0, "questions": {}}
    for py in py_files:
        pdf_q = py.stem  # e.g., "Q2"
        csv_ids = mapping.get(pdf_q)
        if not csv_ids:
            results["questions"][pdf_q] = {"status": "skipped", "reason": "No CSV ID mapping found"}
            continue
        csv_ids = csv_ids if isinstance(csv_ids, list) else [csv_ids]

        fns = detect_functions_in_file(py)
        if not fns:
            results["questions"][pdf_q] = {"status": "error", "reason": "No functions found in file", "csv_ids": csv_ids}
            results["files_tested"] += 1; results["files_failed"] += 1
            continue

        function_name = fns[0]
        combined = {"total_tests": 0, "passed": 0, "passed_cases": [], "failed": 0, "failed_cases": []}
        all_ok = True
        for cid in csv_ids:
            qb = qbank.get(cid)
            if not qb:  # skip missing bank entries but still count file
                continue
            ok, det = test_function_against_csv(py, function_name, qb["test_cases"])
            for k in ("total_tests", "passed", "failed"):
                combined[k] += det.get(k, 0)
            combined["failed_cases"].extend(det.get("failed_cases", []))
            combined["passed_cases"].extend(det.get("passed_cases", []))
            if not ok: all_ok = False

        results["files_tested"] += 1
        results["files_passed"] += 1 if all_ok else 0
        results["files_failed"] += 0 if all_ok else 1
        results["questions"][pdf_q] = {
            "status": "passed" if all_ok else "failed",
            "csv_ids": csv_ids,
            "function_name": function_name,
            "test_details": combined
        }
    return results